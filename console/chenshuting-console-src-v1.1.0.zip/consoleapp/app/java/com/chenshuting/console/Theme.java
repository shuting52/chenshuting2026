package com.chenshuting.console;

import android.graphics.Color;

/** 深色玻璃拟态主题配色（与陈淑婷工具箱视觉统一）。 */
public final class Theme {
    public static final int BG = Color.parseColor("#0A0407");
    public static final int BAR = Color.parseColor("#12080B");
    public static final int CARD = Color.parseColor("#14FFE9C9");
    public static final int CARD2 = Color.parseColor("#0DFFFFFF");
    public static final int STROKE = Color.parseColor("#33E0A85A");
    public static final int GOLD = Color.parseColor("#E0A85A");
    public static final int GOLD_LIGHT = Color.parseColor("#F0C876");
    public static final int TEXT = Color.parseColor("#F5EDE3");
    public static final int SUB = Color.parseColor("#A6978C");
    public static final int OK = Color.parseColor("#63C48B");
    public static final int WARN = Color.parseColor("#E8B65C");
    public static final int ERR = Color.parseColor("#E0655F");
    public static final int BTN_TXT = Color.parseColor("#241206");

    private Theme() {
    }
}
