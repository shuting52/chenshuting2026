package com.chenshuting.console;

import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONObject;

/** 弹窗页：四类弹窗（本体通用 / 更新 / 置顶 / 我的页）的样式编辑器 + 实时预览 + 云端发布。
 *  配置落 data/dialogs.json，本体启动后自动同步生效。 */
public final class PageDialog extends Page {

    /** 预设色板。 */
    private static final String[] PALETTE = {
            "#F5C044", "#C8871A", "#FFF3D6", "#F5EDE3", "#A6978C", "#FFFFFF",
            "#1A0F14", "#241419", "#0E0A12", "#3A2405", "#EF4444", "#22C55E",
            "#3B82F6", "#8B5CF6", "#EC4899", "#14B8A6", "#E0A85A", "#66E0A85A"};

    private final JSONObject scenes;
    private int sel = 0;
    private LinearLayout editor;
    private LinearLayout chipsRow;
    private TextView stageSub;

    public PageDialog(MainActivity a) {
        super(a);
        scenes = Skin.defaults();
    }

    @Override
    protected void build() {
        Tutorial.add(body, ctx, "弹窗样式页 · 怎么用", new String[]{
                "选场景：顶部四个标签分别对应「本体通用弹窗 / 更新弹窗 / 置顶弹窗 / 我的页弹窗」，点一下即切换编辑对象。",
                "调参数：宽度比例、圆角、内间距、描边粗细决定弹窗外形；标题/正文字号与颜色决定文字观感；金龙、极光、光斑三个开关可单独关掉特效。",
                "选颜色：点色板里的色块即可套用，颜色值会同步写进输入框；也可以手动填 #RRGGBB 或 #AARRGGBB（带透明度）。",
                "看效果：点「预览当前弹窗」，会按你当前的设置真实弹出一个样例弹窗，确认满意再发布。",
                "发布生效：点「发布到线上」，配置写入仓库 data/dialogs.json，工具箱下次启动自动拉取换肤；用户无需更新 APK。",
                "备份与还原：点「从线上读取」可拉回当前线上配置继续改；点「恢复默认」把当前场景还原为出厂样式。",
                "注意：更新弹窗默认强制不可关闭，「确定按钮文案」就是它的主按钮文字；置顶与我的页弹窗独立配色，便于区分使用场景。"});

        LinearLayout bar = Ui.row(ctx);
        TextView b1 = Ui.btn(ctx, "预览当前弹窗", true);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogPreview.sample(act, scene(sel), sel);
            }
        });
        bar.addView(b1);

        TextView b2 = Ui.btn(ctx, "发布到线上", false);
        LinearLayout.LayoutParams blp = lpWrap();
        blp.leftMargin = Ui.dp(ctx, 8);
        bar.addView(b2, blp);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publish();
            }
        });
        Ui.add(body, bar, 4);

        LinearLayout bar2 = Ui.row(ctx);
        TextView b3 = Ui.btn(ctx, "从线上读取", false);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pull();
            }
        });
        bar2.addView(b3);

        TextView b4 = Ui.btn(ctx, "恢复默认", false);
        LinearLayout.LayoutParams b4lp = lpWrap();
        b4lp.leftMargin = Ui.dp(ctx, 8);
        bar2.addView(b4, b4lp);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject d = Skin.defaults().optJSONObject(Skin.SCENES[sel]);
                try {
                    scenes.put(Skin.SCENES[sel], d);
                } catch (Throwable ignored) {
                }
                rebuildEditor();
                info("已恢复「" + Skin.SCENE_LABEL[sel] + "」出厂样式，记得点发布");
            }
        });

        TextView b5 = Ui.btn(ctx, "全部预览", false);
        LinearLayout.LayoutParams b5lp = lpWrap();
        b5lp.leftMargin = Ui.dp(ctx, 8);
        bar2.addView(b5, b5lp);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogPreview.sample(act, scene(sel), sel);
            }
        });
        Ui.add(body, bar2, 8);

        LinearLayout stage = Ui.card(ctx);
        TextView st = Ui.section(ctx, "选择要编辑的弹窗");
        stage.addView(st);
        stageSub = Ui.sub(ctx, "当前：" + Skin.SCENE_LABEL[0] + " · " + Skin.SCENE_DESC[0]);
        Ui.add(stage, stageSub, 6);

        chipsRow = Ui.col(ctx);
        for (int i = 0; i < Skin.SCENES.length; i++) {
            final int k = i;
            TextView chip = Ui.btn(ctx, Skin.SCENE_LABEL[i], i == sel);
            chip.setClickable(true);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sel = k;
                    rebuildChips();
                    rebuildEditor();
                }
            });
            LinearLayout.LayoutParams lp = lpMatch();
            lp.topMargin = Ui.dp(ctx, 8);
            chipsRow.addView(chip, lp);
        }
        stage.addView(chipsRow);
        Ui.add(body, stage, 10);

        editor = Ui.col(ctx);
        Ui.add(body, editor, 0);
        rebuildEditor();

        // 首次进入时静默拉取线上配置
        pull(false);
    }

    @Override
    protected void onShow() {
        // 每次进入该页时若未编辑过则刷新一次
    }

    private JSONObject scene(int i) {
        JSONObject s = scenes.optJSONObject(Skin.SCENES[i]);
        if (s == null) {
            s = Skin.defaults().optJSONObject(Skin.SCENES[i]);
            try {
                scenes.put(Skin.SCENES[i], s);
            } catch (Throwable ignored) {
            }
        }
        return s;
    }

    private void rebuildChips() {
        for (int i = 0; i < chipsRow.getChildCount(); i++) {
            TextView chip = (TextView) chipsRow.getChildAt(i);
            boolean on = i == sel;
            chip.setTextColor(on ? Theme.BTN_TXT : Theme.TEXT);
            chip.setBackground(on ? Ui.grad(ctx, 20) : Ui.bg(ctx, Theme.CARD2, 20, 1, Theme.STROKE));
        }
        stageSub.setText("当前：" + Skin.SCENE_LABEL[sel] + " · " + Skin.SCENE_DESC[sel]);
    }

    private void rebuildEditor() {
        editor.removeAllViews();
        final JSONObject s = scene(sel);
        if (stageSub != null) {
            stageSub.setText("当前：" + Skin.SCENE_LABEL[sel] + " · " + Skin.SCENE_DESC[sel]);
        }

        LinearLayout sizeCard = Ui.card(ctx);
        sizeCard.addView(Ui.section(ctx, "外形 · " + Skin.SCENE_LABEL[sel]));
        sizeCard.addView(Ui.sub(ctx, "控制弹窗宽度、圆角、内边距与描边，左侧数值实时跟随"));
        seek(sizeCard, s, "widthRatio", "宽度占屏比", 0.5f, 1.0f, 0.01f, false);
        seek(sizeCard, s, "radiusDp", "圆角(dp)", 0, 48, 1, true);
        seek(sizeCard, s, "padDp", "卡片内边距(dp)", 6, 36, 1, true);
        seek(sizeCard, s, "strokeWidthDp", "描边粗细(dp)", 0, 4, 0.2f, false);
        seek(sizeCard, s, "maxHeightRatio", "内容最大高度占比", 0.4f, 0.85f, 0.01f, false);
        seek(sizeCard, s, "dimAmount", "背景压暗程度", 0, 0.9f, 0.02f, false);
        option(sizeCard, s, "bgStyle", "背景类型", new String[]{"glass", "solid"},
                new String[]{"玻璃磨砂", "实色卡片"});
        option(sizeCard, s, "position", "弹出位置", new String[]{"center", "bottom"},
                new String[]{"屏幕居中", "底部弹出"});
        option(sizeCard, s, "enterAnim", "入场动画", new String[]{"overshoot", "fade", "slideUp"},
                new String[]{"弹性放大", "淡入", "上滑"});
        colorRow(sizeCard, s, "bgColor", "卡片底色");
        colorRow(sizeCard, s, "strokeColor", "描边 / 高光色");
        Ui.add(editor, sizeCard, 10);

        LinearLayout textCard = Ui.card(ctx);
        textCard.addView(Ui.section(ctx, "文字 · " + Skin.SCENE_LABEL[sel]));
        text(textCard, s, "okText", "主按钮文案");
        seek(textCard, s, "titleSizeSp", "标题字号(sp)", 12, 26, 0.5f, false);
        seek(textCard, s, "bodySizeSp", "正文字号(sp)", 10, 20, 0.5f, false);
        colorRow(textCard, s, "titleColor", "标题颜色");
        colorRow(textCard, s, "bodyColor", "正文颜色");
        colorRow(textCard, s, "btnPrimaryColor", "按钮底色");
        colorRow(textCard, s, "btnPrimaryTextColor", "按钮文字色");
        Ui.add(editor, textCard, 10);

        LinearLayout fxCard = Ui.card(ctx);
        fxCard.addView(Ui.section(ctx, "特效开关"));
        fxCard.addView(Ui.sub(ctx, "关掉可显著降低低端机负担（金龙与漂浮特效较吃性能）"));
        switchRow(fxCard, s, "dragon", "金龙绕边框");
        switchRow(fxCard, s, "aurora", "极光柔光背板");
        switchRow(fxCard, s, "decor", "漂浮金币彩带");
        Ui.add(editor, fxCard, 10);

        LinearLayout pub = Ui.card(ctx);
        pub.addView(Ui.section(ctx, "发布"));
        TextView tip = Ui.sub(ctx, "预览 · 发布 · 还原，三步走；发布后本体下次启动自动生效");
        pub.addView(tip);

        LinearLayout row = Ui.row(ctx);
        TextView p = Ui.btn(ctx, "预览当前弹窗", true);
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogPreview.sample(act, scene(sel), sel);
            }
        });
        row.addView(p);
        TextView q = Ui.btn(ctx, "发布到线上", false);
        LinearLayout.LayoutParams qlp = lpWrap();
        qlp.leftMargin = Ui.dp(ctx, 8);
        row.addView(q, qlp);
        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publish();
            }
        });
        Ui.add(pub, row, 10);
        Ui.add(editor, pub, 10);

        LinearLayout all = Ui.card(ctx);
        all.addView(Ui.section(ctx, "四类弹窗速览"));
        for (int i = 0; i < Skin.SCENES.length; i++) {
            LinearLayout kv = Ui.kv(ctx, Skin.SCENE_LABEL[i], "宽 " + pct(scene(i), "widthRatio")
                    + " · 圆角 " + Skin.i(scene(i), "radiusDp", 28) + "dp · "
                    + Skin.str(scene(i), "okText", "我知道了"));
            final int k = i;
            kv.setClickable(true);
            kv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DialogPreview.sample(act, scene(k), k);
                }
            });
            Ui.add(all, kv, 8);
        }
        Ui.add(editor, all, 10);
    }

    private String pct(JSONObject s, String k) {
        return Math.round(Skin.f(s, k, 0.9f) * 100) + "%";
    }

    // ---------------- 控件工厂 ----------------

    private void seek(LinearLayout card, final JSONObject s, final String key, String label,
                      float min, float max, final float step, final boolean integer) {
        LinearLayout head = Ui.row(ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        final TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        head.addView(name, nlp);
        final TextView val = Ui.tv(ctx, fmt(Skin.f(s, key, min), integer), 12.5f, Theme.GOLD_LIGHT, true);
        head.addView(val);
        Ui.add(card, head, 12);

        SeekBar sb = new SeekBar(ctx);
        int steps = Math.max(1, Math.round((max - min) / step));
        sb.setMax(steps);
        sb.setProgress(Math.max(0, Math.min(steps, Math.round((Skin.f(s, key, min) - min) / step))));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                float v = min + progress * step;
                if (integer) v = Math.round(v);
                v = (float) (Math.round(v * 1000.0) / 1000.0);
                try {
                    s.put(key, v);
                } catch (Throwable ignored) {
                }
                val.setText(fmt(v, integer));
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        card.addView(sb);
    }

    private String fmt(float v, boolean integer) {
        if (integer) return String.valueOf(Math.round(v));
        if (Math.abs(v) >= 1f && v == Math.round(v)) return String.valueOf(Math.round(v));
        return String.valueOf(v);
    }

    private void text(LinearLayout card, final JSONObject s, final String key, String label) {
        card.addView(Ui.sub(ctx, label));
        final EditText e = Ui.input(ctx, "如：我知道了 / 立即更新 / 关闭", false, Skin.str(s, key, ""));
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence cs, int a, int b, int c) {
                try {
                    s.put(key, cs.toString());
                } catch (Throwable ignored) {
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable ed) {
            }
        });
        Ui.add(card, e, 6);
    }

    private void colorRow(LinearLayout card, final JSONObject s, final String key, String label) {
        LinearLayout head = Ui.row(ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        head.addView(name, nlp);

        final EditText e = Ui.input(ctx, "#RRGGBB", false, Skin.str(s, key, "#FFFFFF"));
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(Ui.dp(ctx, 120),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        head.addView(e, elp);
        final View swatch = new View(ctx);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(Ui.dp(ctx, 22), Ui.dp(ctx, 22));
        slp.leftMargin = Ui.dp(ctx, 8);
        head.addView(swatch, slp);
        swatch.setBackground(Ui.bg(ctx, Skin.color(Skin.str(s, key, "#FFFFFF"), 0xFFFFFFFF), 6, 1, Theme.STROKE));
        Ui.add(card, head, 12);

        LinearLayout pal = Ui.row(ctx);
        for (final String col : PALETTE) {
            TextView c = Ui.tv(ctx, "", 10f, Theme.TEXT, false);
            c.setBackground(Ui.bg(ctx, Skin.color(col, 0xFFFFFFFF), 8, 1, Theme.STROKE));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(ctx, 22), Ui.dp(ctx, 22));
            lp.rightMargin = Ui.dp(ctx, 6);
            lp.topMargin = Ui.dp(ctx, 6);
            c.setClickable(true);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    e.setText(col);
                    try {
                        s.put(key, col);
                    } catch (Throwable ignored) {
                    }
                    swatch.setBackground(Ui.bg(ctx, Skin.color(col, 0xFFFFFFFF), 6, 1, Theme.STROKE));
                }
            });
            pal.addView(c, lp);
        }
        Ui.add(card, pal, 4);

        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence cs, int a, int b, int c) {
                String t = cs.toString();
                try {
                    s.put(key, t);
                } catch (Throwable ignored) {
                }
                if (t.startsWith("#") && (t.length() == 7 || t.length() == 9)) {
                    swatch.setBackground(Ui.bg(ctx, Skin.color(t, 0xFFFFFFFF), 6, 1, Theme.STROKE));
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable ed) {
            }
        });
    }

    private void switchRow(LinearLayout card, final JSONObject s, final String key, String label) {
        LinearLayout row = Ui.row(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(name, nlp);
        final TextView sw = Ui.btn(ctx, Skin.bool(s, key, true) ? "已开启" : "已关闭", Skin.bool(s, key, true));
        sw.setClickable(true);
        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean nv = !Skin.bool(s, key, true);
                try {
                    s.put(key, nv);
                } catch (Throwable ignored) {
                }
                sw.setText(nv ? "已开启" : "已关闭");
                sw.setTextColor(nv ? Theme.BTN_TXT : Theme.TEXT);
                sw.setBackground(nv ? Ui.grad(ctx, 20) : Ui.bg(ctx, Theme.CARD2, 20, 1, Theme.STROKE));
            }
        });
        row.addView(sw);
        Ui.add(card, row, 10);
    }

    /** 选项行：值写入 key，显示可读名。 */
    private void option(LinearLayout card, final JSONObject s, final String key, String label,
                        final String[] values, final String[] names) {
        LinearLayout head = Ui.row(ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        head.addView(name, nlp);
        Ui.add(card, head, 12);

        LinearLayout row = Ui.row(ctx);
        final TextView[] cs = new TextView[values.length];
        for (int i = 0; i < values.length; i++) {
            final String v = values[i];
            final TextView chip = Ui.btn(ctx, names[i], v.equals(Skin.str(s, key, values[0])));
            chip.setClickable(true);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v2) {
                    try {
                        s.put(key, v);
                    } catch (Throwable ignored) {
                    }
                    for (TextView t : cs) {
                        boolean on = t.getText().toString().equals(v) || false;
                        t.setTextColor(Theme.TEXT);
                        t.setBackground(Ui.bg(ctx, Theme.CARD2, 20, 1, Theme.STROKE));
                    }
                    chip.setTextColor(Theme.BTN_TXT);
                    chip.setBackground(Ui.grad(ctx, 20));
                }
            });
            cs[i] = chip;
            LinearLayout.LayoutParams lp = lpWrap();
            if (i > 0) lp.leftMargin = Ui.dp(ctx, 8);
            row.addView(chip, lp);
        }
        card.addView(row);
    }

    // ---------------- 数据操作 ----------------

    private void pull() {
        pull(true);
    }

    private void pull(final boolean toast) {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject remote = Skin.load(ctx);
                java.util.Iterator<String> it = remote.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    scenes.put(k, remote.optJSONObject(k));
                }
                return "已拉取线上弹窗配置";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err == null) {
                    rebuildEditor();
                    if (toast) info(result);
                } else if (toast) {
                    info("读取失败：" + err.getMessage());
                }
            }
        });
    }

    // ---------------- 布局参数助手 ----------------

    private LinearLayout.LayoutParams lpMatch() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams lpWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void publish() {
        final JSONObject payload;
        try {
            payload = Skin.wrap(ctx, scenes);
        } catch (Throwable t) {
            info("配置组装失败：" + t.getMessage());
            return;
        }
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                String text = Repo.pretty(payload);
                Repo.writeText(ctx, Skin.PATH, text, "console: 更新弹窗样式配置");
                // 登记进内容清单，工具箱端才会自动拉取（否则文件在仓库里但 App 读不到）
                Repo.manifestTouch(ctx, Skin.PATH, text.getBytes("UTF-8"));
                return "发布成功：已写入 dialogs.json 并登记内容清单，工具箱联网拉取后生效";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err == null) {
                    info(result);
                    log("弹窗皮肤已发布：" + Skin.PATH);
                } else {
                    info("发布失败：" + err.getMessage());
                }
            }
        });
    }
}
