package com.chenshuting.console;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 轻量 UI 工厂：纯代码构建深色玻璃拟态界面，避免 XML 布局依赖。 */
public final class Ui {

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static TextView tv(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    public static TextView title(Context c, CharSequence s) {
        return tv(c, s, 17f, Theme.TEXT, true);
    }

    public static TextView section(Context c, CharSequence s) {
        TextView t = tv(c, s, 13f, Theme.GOLD, true);
        t.setPadding(0, dp(c, 6), 0, dp(c, 6));
        return t;
    }

    public static TextView sub(Context c, CharSequence s) {
        return tv(c, s, 12f, Theme.SUB, false);
    }

    public static TextView btn(Context c, CharSequence s, boolean primary) {
        TextView t = tv(c, s, 14f, primary ? Theme.BTN_TXT : Theme.GOLD_LIGHT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        t.setBackground(primary ? grad(c, 10) : bg(c, Theme.CARD, 10, 1, Theme.STROKE));
        t.setClickable(true);
        return t;
    }

    public static TextView chip(Context c, CharSequence s, int color) {
        TextView t = tv(c, s, 11f, color, false);
        t.setPadding(dp(c, 8), dp(c, 3), dp(c, 8), dp(c, 3));
        GradientDrawable g = bg(c, Theme.CARD2, 20, 1, Theme.STROKE);
        t.setBackground(g);
        return t;
    }

    public static EditText input(Context c, String hint, boolean multi, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(Theme.SUB);
        e.setTextColor(Theme.TEXT);
        e.setTextSize(14f);
        e.setBackground(bg(c, Theme.CARD2, 10, 1, Theme.STROKE));
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP | Gravity.START);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT);
            e.setSingleLine(true);
        }
        if (value != null) e.setText(value);
        return e;
    }

    public static EditText inputPwd(Context c, String hint, String value) {
        EditText e = input(c, hint, false, value);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(bg(c, Theme.CARD, 16, 1, Theme.STROKE));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static View line(Context c) {
        View v = new View(c);
        v.setBackgroundColor(Theme.STROKE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
        p.topMargin = dp(c, 8);
        p.bottomMargin = dp(c, 8);
        v.setLayoutParams(p);
        return v;
    }

    public static View gap(Context c, int h) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, h)));
        return v;
    }

    public static GradientDrawable bg(Context c, int fill, int radiusDp, int strokeW, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeW > 0) g.setStroke(dp(c, strokeW), strokeColor);
        return g;
    }

    public static GradientDrawable grad(Context c, int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Theme.GOLD_LIGHT, Theme.GOLD});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static void add(ViewGroup parent, View child, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(parent.getContext(), topDp);
        parent.addView(child, p);
    }

    public static LinearLayout kv(Context c, String k, String v) {
        LinearLayout r = row(c);
        TextView kk = tv(c, k, 12f, Theme.SUB, false);
        kk.setMinWidth(dp(c, 74));
        TextView vv = tv(c, v == null ? "" : v, 13f, Theme.TEXT, false);
        vv.setPadding(dp(c, 8), 0, 0, 0);
        r.addView(kk);
        r.addView(vv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }

    public static ScrollView scroller(Context c, View child) {
        ScrollView s = new ScrollView(c);
        s.setFillViewport(true);
        s.setBackgroundColor(Theme.BG);
        s.addView(child, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return s;
    }

    public static LinearLayout page(Context c) {
        LinearLayout l = col(c);
        int p = dp(c, 14);
        l.setPadding(p, p, p, dp(c, 28));
        return l;
    }

    public static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    /** 后台执行 + 主线程回调。 */
    public interface Job {
        String run() throws Exception;
    }

    public interface Done {
        void done(String result, Throwable err);
    }

    public static void run(Activity a, final Job job, final Done done) {
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override
            public void run() {
                String res = null;
                Throwable err = null;
                try {
                    res = job.run();
                } catch (Throwable t) {
                    err = t;
                }
                final String r = res;
                final Throwable e = err;
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (done != null) done.done(r, e);
                    }
                });
            }
        }, "console-job").start();
    }
}
