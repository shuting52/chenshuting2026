package com.chenshuting.console;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 仓库业务层：内容清单维护、内容文件发布、版本与公告发布。 */
public final class Repo {

    public static final String P_VERSION = "version.json";
    public static final String P_MANIFEST = "data/manifest.json";
    public static final String P_NOTICE = "data/announcements.json";
    public static final String D_DATA = "data";
    public static final String D_PROMPTS = "data/prompts";
    public static final String D_SKILLS = "data/skills";
    public static final String D_FILES = "files";

    /** 默认仓库配置与控制台版本。 */
    public static final String DEF_REPO = Prefs.DEF_REPO;
    public static final String DEF_BRANCH = Prefs.DEF_BRANCH;
    public static final String APP_VER = "1.0.0";

    /** App 端内容层四个数据文件（远端路径 data/xxx.json）。 */
    public static final String[] CONTENT_FILES = {"apps.json", "prompts.json", "skills.json", "resources.json"};

    private Repo() {
    }

    // ---------------- 基础读写 ----------------

    public static String repo(Context c) {
        return Prefs.repo(c);
    }

    public static String branch(Context c) {
        return Prefs.branch(c);
    }

    public static String token(Context c) {
        return Prefs.token(c);
    }

    private static void need(Gh.R r, String what) throws Exception {
        if (r.ok()) return;
        String msg = r.body == null ? "" : r.body.replace('\n', ' ').trim();
        if (msg.length() > 160) msg = msg.substring(0, 160);
        throw new Exception(what + "失败（HTTP " + r.code + "）：" + msg);
    }

    public static String readText(Context c, String path) throws Exception {
        return Gh.getText(repo(c), branch(c), path, token(c));
    }

    public static byte[] readBytes(Context c, String path) throws Exception {
        return Gh.getBytes(repo(c), branch(c), path, token(c));
    }

    public static JSONObject readJson(Context c, String path) throws Exception {
        String t = readText(c, path);
        if (t == null || t.trim().length() == 0) return null;
        try {
            return new JSONObject(t);
        } catch (Throwable e) {
            throw new Exception(path + " 不是合法 JSON：" + e.getMessage());
        }
    }

    public static void writeText(Context c, String path, String text, String msg) throws Exception {
        need(Gh.putText(repo(c), branch(c), path, text, msg, token(c)), "写入 " + path + " ");
    }

    public static void writeBytes(Context c, String path, byte[] data, String msg) throws Exception {
        need(Gh.putFile(repo(c), branch(c), path, data, msg, token(c)), "上传 " + path + " ");
    }

    public static void remove(Context c, String path, String msg) throws Exception {
        need(Gh.deleteFile(repo(c), branch(c), path, msg, token(c)), "删除 " + path + " ");
    }

    public static String jsdelivr(Context c, String path) {
        return "https://cdn.jsdelivr.net/gh/" + repo(c) + "@" + branch(c) + "/" + path;
    }

    /** 仓库可读性自检。 */
    public static Gh.R repoCheck(Context c) {
        return Gh.repo(repo(c), token(c));
    }

    public static String pretty(JSONObject o) {
        try {
            return o.toString(2);
        } catch (Throwable t) {
            return o.toString();
        }
    }

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(new Date());
    }

    // ---------------- 内容清单 ----------------

    public static JSONObject manifest(Context c) throws Exception {
        JSONObject m = readJson(c, P_MANIFEST);
        if (m == null) {
            m = new JSONObject();
            m.put("version", 0);
            m.put("updated", today());
            m.put("note", "由淑婷控制台自动维护");
            m.put("files", new JSONArray());
        }
        return m;
    }

    /** 更新（或新增）清单中某个内容文件的 sha256 / size 记录，并自增清单版本号。 */
    public static void manifestTouch(Context c, String localPath, byte[] data) throws Exception {
        JSONObject m = manifest(c);
        String manifestPath = localPath.startsWith("data/") ? localPath : "data/" + localPath;
        JSONArray files = m.optJSONArray("files");
        if (files == null) files = new JSONArray();
        JSONArray out = new JSONArray();
        for (int i = 0; i < files.length(); i++) {
            JSONObject f = files.optJSONObject(i);
            if (f == null) continue;
            if (manifestPath.equals(f.optString("path", ""))) continue;
            out.put(f);
        }
        JSONObject e = new JSONObject();
        e.put("path", manifestPath);
        e.put("sha256", Gh.sha256(data));
        e.put("size", data.length);
        out.put(e);
        m.put("version", m.optInt("version", 0) + 1);
        m.put("updated", today());
        m.put("note", "由淑婷控制台自动维护：公告 announcements.json 走独立实时通道，不登记在本清单");
        m.put("files", out);
        writeText(c, P_MANIFEST, pretty(m), "chore: 更新内容清单 v" + m.optInt("version", 0));
    }

    /** 从清单中移除某个内容文件记录。 */
    public static void manifestRemove(Context c, String localPath) throws Exception {
        JSONObject m = manifest(c);
        String manifestPath = localPath.startsWith("data/") ? localPath : "data/" + localPath;
        JSONArray files = m.optJSONArray("files");
        if (files == null) return;
        JSONArray out = new JSONArray();
        for (int i = 0; i < files.length(); i++) {
            JSONObject f = files.optJSONObject(i);
            if (f == null) continue;
            if (manifestPath.equals(f.optString("path", ""))) continue;
            out.put(f);
        }
        m.put("version", m.optInt("version", 0) + 1);
        m.put("updated", today());
        m.put("files", out);
        writeText(c, P_MANIFEST, pretty(m), "chore: 移除内容记录 " + localPath);
    }

    /** 全量重建清单：扫描 data/ 全部内容文件，下载计算 sha256 后写回。 */
    public static String rebuildManifest(Context c) throws Exception {
        List<String> paths = new ArrayList<String>();
        collect(c, D_DATA, paths, 0);
        JSONArray files = new JSONArray();
        List<String> skipped = new ArrayList<String>();
        for (String p : paths) {
            String local = p.startsWith("data/") ? p.substring(5) : p;
            if (local.equals("manifest.json") || local.equals("announcements.json")) continue;
            if (!isContent(local)) {
                skipped.add(local);
                continue;
            }
            byte[] d = readBytes(c, p);
            if (d == null) continue;
            JSONObject e = new JSONObject();
            e.put("path", p);
            e.put("sha256", Gh.sha256(d));
            e.put("size", d.length);
            files.put(e);
        }
        JSONObject m = new JSONObject();
        m.put("version", manifest(c).optInt("version", 0) + 1);
        m.put("updated", today());
        m.put("note", "由淑婷控制台自动维护：公告 announcements.json 走独立实时通道，不登记在本清单");
        m.put("files", files);
        writeText(c, P_MANIFEST, pretty(m), "chore: 重建内容清单（" + files.length() + " 个文件）");
        StringBuilder sb = new StringBuilder("清单已重建：登记 " + files.length() + " 个文件");
        if (skipped.size() > 0) sb.append("，白名单外 " + skipped.size() + " 个文件未登记");
        return sb.toString();
    }

    private static boolean isContent(String local) {
        for (String n : CONTENT_FILES) {
            if (local.equals(n)) return true;
        }
        return local.startsWith("prompts/") || local.startsWith("skills/");
    }

    private static void collect(Context c, String dir, List<String> out, int depth) throws Exception {
        if (depth > 2) return;
        JSONArray arr = Gh.list(repo(c), branch(c), dir, token(c));
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String type = o.optString("type", "");
            String path = o.optString("path", "");
            if (path.length() == 0) continue;
            if ("dir".equals(type)) collect(c, path, out, depth + 1);
            else out.add(path);
        }
    }

    // ---------------- 版本与公告 ----------------

    public static JSONObject version(Context c) throws Exception {
        return readJson(c, P_VERSION);
    }

    /** 发布版本信息：写入 version.json（apkUrl 指向仓库内 apk 的 jsDelivr 直链）。 */
    public static void publishVersion(Context c, int code, String name, String changelog, String apkPath)
            throws Exception {
        JSONObject v = new JSONObject();
        v.put("versionCode", code);
        v.put("versionName", name);
        v.put("changelog", changelog);
        v.put("apkUrl", jsdelivr(c, apkPath));
        writeText(c, P_VERSION, pretty(v), "release: v" + name + " (" + code + ")");
    }

    /** 发布公告（独立实时通道，约 1 分钟生效）。 */
    public static void publishNotice(Context c, JSONObject notice) throws Exception {
        writeText(c, P_NOTICE, pretty(notice), "chore: 更新公告");
    }

    /** 列仓库根目录文件（用于找旧版本 apk）。 */
    public static List<String> rootApks(Context c) {
        List<String> out = new ArrayList<String>();
        JSONArray arr = Gh.list(repo(c), branch(c), "", token(c));
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String type = o.optString("type", "");
            String name = o.optString("name", "");
            if ("file".equals(type) && name.toLowerCase(Locale.ROOT).endsWith(".apk")) out.add(name);
        }
        return out;
    }
}
