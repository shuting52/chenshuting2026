package com.chenshuting.console;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;

/** GitHub Contents API 客户端：读写仓库文件、列目录、账号校验。 */
public final class Gh {

    public static final String API = "https://api.github.com";

    public static class R {
        public int code;
        public String body = "";

        public boolean ok() {
            return code >= 200 && code < 300;
        }

        public JSONObject json() {
            try {
                return new JSONObject(body);
            } catch (Throwable t) {
                return null;
            }
        }
    }

    private Gh() {
    }

    public static String enc(String p) {
        StringBuilder sb = new StringBuilder();
        String[] segs = p.split("/");
        for (int i = 0; i < segs.length; i++) {
            if (i > 0) sb.append('/');
            try {
                sb.append(URLEncoder.encode(segs[i], "UTF-8").replace("+", "%20"));
            } catch (Throwable t) {
                sb.append(segs[i]);
            }
        }
        return sb.toString();
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        } finally {
            in.close();
        }
        return new String(bo.toByteArray(), "UTF-8");
    }

    private static R req(String method, String url, String token, String body, int readTimeout) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(readTimeout);
            conn.setRequestMethod(method);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("Accept", "application/vnd.github+json");
            conn.setRequestProperty("User-Agent", "ShutingConsole");
            if (token != null && token.length() > 0) {
                conn.setRequestProperty("Authorization", "Bearer " + token);
            }
            if (body != null) {
                byte[] b = body.getBytes("UTF-8");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setFixedLengthStreamingMode(b.length);
                OutputStream o = conn.getOutputStream();
                try {
                    o.write(b);
                } finally {
                    o.close();
                }
            }
            int code = conn.getResponseCode();
            InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            R r = new R();
            r.code = code;
            r.body = readAll(in);
            return r;
        } catch (Throwable t) {
            R r = new R();
            r.code = -1;
            r.body = String.valueOf(t);
            return r;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String contentsUrl(String repo, String path, String branch) {
        String u = API + "/repos/" + repo + "/contents/" + enc(path);
        if (branch != null && branch.length() > 0) u += "?ref=" + enc(branch);
        return u;
    }

    /** 账号校验（Token 是否有效）。 */
    public static R user(String token) {
        return req("GET", API + "/user", token, null, 20000);
    }

    /** 仓库可读性校验（owner/repo）。 */
    public static R repo(String ownerRepo, String token) {
        return req("GET", API + "/repos/" + ownerRepo, token, null, 20000);
    }

    /** 读取仓库文件元信息与内容，文件不存在返回 null。 */
    public static JSONObject getFile(String repo, String branch, String path, String token) {
        R r = req("GET", contentsUrl(repo, path, branch), token, null, 30000);
        if (!r.ok()) return null;
        return r.json();
    }

    /** 读取仓库文件原始字节，不存在或失败返回 null。 */
    public static byte[] getBytes(String repo, String branch, String path, String token) {
        JSONObject o = getFile(repo, branch, path, token);
        if (o == null) return null;
        String b64 = o.optString("content", "");
        if (b64.length() == 0) return null;
        try {
            return Base64.decode(b64.replace("\n", "").replace("\r", ""), Base64.DEFAULT);
        } catch (Throwable t) {
            return null;
        }
    }

    public static String getText(String repo, String branch, String path, String token) {
        byte[] b = getBytes(repo, branch, path, token);
        if (b == null) return null;
        try {
            return new String(b, "UTF-8");
        } catch (Throwable t) {
            return null;
        }
    }

    public static String getSha(String repo, String branch, String path, String token) {
        JSONObject o = getFile(repo, branch, path, token);
        return o == null ? null : o.optString("sha", "");
    }

    /** 写入文件（存在则覆盖，自动取 sha）。 */
    public static R putFile(String repo, String branch, String path, byte[] data, String message, String token) {
        try {
            JSONObject body = new JSONObject();
            body.put("message", message);
            body.put("branch", branch);
            body.put("content", Base64.encodeToString(data, Base64.NO_WRAP));
            String sha = getSha(repo, branch, path, token);
            if (sha != null && sha.length() > 0) body.put("sha", sha);
            return req("PUT", contentsUrl(repo, path, branch), token, body.toString(), 120000);
        } catch (Throwable t) {
            R r = new R();
            r.code = -1;
            r.body = String.valueOf(t);
            return r;
        }
    }

    public static R putText(String repo, String branch, String path, String text, String message, String token) {
        try {
            return putFile(repo, branch, path, text.getBytes("UTF-8"), message, token);
        } catch (Throwable t) {
            R r = new R();
            r.code = -1;
            r.body = String.valueOf(t);
            return r;
        }
    }

    /** 删除仓库文件。 */
    public static R deleteFile(String repo, String branch, String path, String message, String token) {
        try {
            String sha = getSha(repo, branch, path, token);
            if (sha == null || sha.length() == 0) {
                R r = new R();
                r.code = 404;
                r.body = "file not found: " + path;
                return r;
            }
            JSONObject body = new JSONObject();
            body.put("message", message);
            body.put("branch", branch);
            body.put("sha", sha);
            return req("DELETE", contentsUrl(repo, path, branch), token, body.toString(), 60000);
        } catch (Throwable t) {
            R r = new R();
            r.code = -1;
            r.body = String.valueOf(t);
            return r;
        }
    }

    /** 列目录（非目录或失败返回空数组）。 */
    public static JSONArray list(String repo, String branch, String dir, String token) {
        R r = req("GET", contentsUrl(repo, dir, branch), token, null, 30000);
        if (!r.ok()) return new JSONArray();
        try {
            String b = r.body.trim();
            if (b.startsWith("[")) return new JSONArray(b);
        } catch (Throwable ignored) {
        }
        return new JSONArray();
    }

    public static String sha256(byte[] d) {
        return hex("SHA-256", d);
    }

    public static String sha1(byte[] d) {
        return hex("SHA-1", d);
    }

    private static String hex(String alg, byte[] d) {
        try {
            MessageDigest md = MessageDigest.getInstance(alg);
            byte[] h = md.digest(d);
            StringBuilder sb = new StringBuilder();
            for (byte b : h) {
                String s = Integer.toHexString(b & 0xFF);
                if (s.length() == 1) sb.append('0');
                sb.append(s);
            }
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }
}
