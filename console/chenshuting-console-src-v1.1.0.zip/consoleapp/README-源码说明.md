# 淑婷控制台 · 源码包 v1.1.0（脱敏）

> 本包为公开版源码，**不含签名私钥、不含任何 GitHub 令牌**。

## 目录
- `app/`：Android 源码（java / res / AndroidManifest.xml）
- `build.sh`：手工构建链（aapt2 → javac → R8 → zipalign → apksigner）
- `proguard-rules.pro`：R8 规则

## 构建
```bash
export KS_PATH=/path/to/your-release.jks   # 自行准备的签名库
export KS_PASS=你的签名库口令
export KS_ALIAS=chenshuting
bash build.sh          # 产物：output/淑婷控制台-v1.1.0.apk
```

## 令牌约定（重要）
- `Prefs.java` 中保留 `__TOKEN__` 源码占位，构建期由 `$TEMP/.tok_use` 注入、构建结束自动还原；
- **公开分发包务必不要内置真实令牌**：令牌随 APK 进公开仓库会被 GitHub 密钥扫描自动吊销；
- 对外发布包请保持占位符（App 内「设置」页手动粘贴令牌即可），内置令牌版仅限本机安装。

## v1.1.0 功能
1. 图标三态：内置图标 / 填网址自动识别站点图标 / 上传本地图片
2. 弹窗样式编辑器：通用 / 更新 / 置顶 / 我的 四场景，实时预览，发布即生效（`data/dialogs.json`）
3. 全功能页「怎么用」分步教程
4. 图标直链带时间戳破 CDN 缓存
