#!/bin/bash
# 淑婷控制台 · 原生 Android 应用构建脚本（无 Gradle 手工构建链）
set -e

BASE=/home/marvis/Marvis/User/E1C17F57EF41062A257B7919E35DD954/workspace/conv_7a5a8b4be3f44d249153773980beb71b
TEMP=$BASE/temp
W=$TEMP/consoleapp
OUT=$BASE/output
TOOLS=$TEMP/apkbuild/tools

export JAVA_HOME=$TOOLS/jdk-17.0.20.1+1
export PATH=$JAVA_HOME/bin:$PATH
BT=$TOOLS/android-sdk/build-tools/34.0.0
AJAR=$TOOLS/android-sdk/platforms/android-34/android.jar

echo "=== [1/8] 清理构建目录 ==="
rm -rf $W/build
mkdir -p $W/build/gen $W/build/classes $W/build/dex

cd $W/app

# Token 注入：源码保留 __TOKEN__ 占位，构建时用 temp/.tok_use 替换，构建结束（含失败）自动还原
PREFS=java/com/chenshuting/console/Prefs.java
cp $PREFS $PREFS.bak
trap 'mv -f $PREFS.bak $PREFS 2>/dev/null || true' EXIT
if [ -f $TEMP/.tok_use ]; then
  TOK=$(tr -d '\n\r ' < $TEMP/.tok_use)   # 可选：本地安装包才注入令牌，切勿随公开包发布
  if [ -n "$TOK" ]; then
    sed -i "s/__TOKEN__/$TOK/" $PREFS
    echo "  token 已注入（${#TOK} 字符）"
  fi
fi

echo "=== [2/8] aapt2 compile 资源 ==="
$BT/aapt2 compile --dir res -o $W/build/res.zip

echo "=== [3/8] aapt2 link 生成资源 APK ==="
$BT/aapt2 link -o $W/build/base.apk \
  -I $AJAR \
  --manifest AndroidManifest.xml \
  -R $W/build/res.zip \
  --auto-add-overlay \
  --java $W/build/gen \
  --min-sdk-version 21 --target-sdk-version 34 \
  --version-code 2 --version-name 1.1.0

echo "=== [4/8] javac 编译 Java 源码 ==="
javac -encoding UTF-8 -nowarn -cp $AJAR --release 8 -d $W/build/classes \
  $(find java -name '*.java') \
  $W/build/gen/com/chenshuting/console/R.java

echo "=== [5/8] R8 收缩 + 优化，生成 classes.dex ==="
R8JAR=$TOOLS/android-sdk/cmdline-tools/latest/lib/r8.jar
java -cp $R8JAR com.android.tools.r8.R8 \
  --release --lib $AJAR --min-api 21 \
  --output $W/build/dex \
  --pg-conf $W/proguard-rules.pro \
  $(find $W/build/classes -name '*.class')
ls -l $W/build/dex

echo "=== [6/8] 合并 dex 进 APK ==="
python3 - "$W/build/base.apk" "$W/build/dex" <<'PY'
import sys, os, glob, zipfile
apk, dexdir = sys.argv[1], sys.argv[2]
dexs = sorted(glob.glob(os.path.join(dexdir, 'classes*.dex')))
assert dexs, 'no dex produced'
with zipfile.ZipFile(apk, 'a', zipfile.ZIP_STORED) as z:
    for p in dexs:
        z.write(p, os.path.basename(p))
print('dex merged into', apk, '->', [os.path.basename(p) for p in dexs])
PY

echo "=== [7/8] zipalign 对齐 ==="
$BT/zipalign -f -p 4 $W/build/base.apk $W/build/aligned.apk

echo "=== [8/8] 正式签名（RSA2048 / v1+v2） ==="
KS=${KS_PATH:-/path/to/your-release.jks}   # 自行提供签名库路径（本源码包不含私钥）
mkdir -p $OUT
APK=$OUT/淑婷控制台-v1.1.0.apk
$BT/apksigner sign \
  --ks "$KS" --ks-key-alias ${KS_ALIAS:-chenshuting} \
  --ks-pass pass:${KS_PASS:?请先 export KS_PASS=你的签名库口令} --key-pass pass:${KS_PASS} \
  --v1-signing-enabled true --v2-signing-enabled true --v4-signing-enabled false \
  --out "$APK" $W/build/aligned.apk

echo "=== 校验 ==="
$BT/apksigner verify --print-certs "$APK" | head -8
echo "--- badging ---"
$BT/aapt2 dump badging "$APK" | head -12
ls -lh "$APK"
