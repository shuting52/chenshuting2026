package com.chenshuting.console;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** 轻量 UI 工厂：纯代码构建「少女拟态」界面（软塑卡片 + 双向柔和阴影 + 玫瑰粉主色）。 */
public final class Ui {

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static TextView tv(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    public static TextView title(Context c, CharSequence s) {
        return tv(c, s, 17f, Theme.TEXT, true);
    }

    public static TextView section(Context c, CharSequence s) {
        TextView t = tv(c, s, 13f, Theme.GOLD, true);
        t.setPadding(0, dp(c, 6), 0, dp(c, 6));
        return t;
    }

    public static TextView sub(Context c, CharSequence s) {
        return tv(c, s, 12f, Theme.SUB, false);
    }

    // ---------------- 拟态视觉内核 ----------------

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    private static GradientDrawable round(Context c, int fill, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    /** 拟态凸起：亮侧（左上）/ 暗侧（右下）双向阴影包夹主体，形成软塑感。 */
    public static Drawable soft(Context c, int fill, float radiusDp) {
        float r = radiusDp;
        GradientDrawable big = round(c, withAlpha(Theme.SHADOW_DARK, 0x3D), r + 2f);
        GradientDrawable near = round(c, withAlpha(Theme.SHADOW_DARK, 0x66), r + 0.5f);
        GradientDrawable hi = round(c, withAlpha(Theme.SHADOW_LIGHT, 0xD9), r);
        GradientDrawable body = round(c, fill, r);
        LayerDrawable ld = new LayerDrawable(new Drawable[]{big, near, hi, body});
        int b = dp(c, 4);
        int n = dp(c, 2);
        ld.setLayerInset(0, 0, 0, -b, -b);   // 大暗影：向右下溢出
        ld.setLayerInset(1, 0, 0, -n, -n);   // 近暗影：紧贴右下
        ld.setLayerInset(2, -n, -n, 0, 0);   // 高光：向左上溢出
        ld.setLayerInset(3, 0, 0, 0, 0);     // 主体
        return ld;
    }

    /** 拟态凹槽：用于输入框等「按进去」的控件。 */
    public static Drawable inset(Context c, int fill, float radiusDp) {
        GradientDrawable body = round(c, fill, radiusDp);
        GradientDrawable ring = round(c, Color.TRANSPARENT, radiusDp);
        ring.setStroke(dp(c, 1), withAlpha(Theme.SHADOW_DARK, 0x59));
        GradientDrawable inner = round(c, Color.TRANSPARENT, radiusDp - 1f);
        inner.setStroke(dp(c, 1), withAlpha(Theme.SHADOW_LIGHT, 0xCC));
        LayerDrawable ld = new LayerDrawable(new Drawable[]{body, ring, inner});
        int n = dp(c, 2);
        ld.setLayerInset(2, n, n, 0, 0);
        return ld;
    }

    /** 页面底：奶油粉 → 淡紫的斜向渐变。 */
    public static GradientDrawable softBg(Context c) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Theme.BG_TOP, Theme.BG_BOTTOM});
        return g;
    }

    public static TextView btn(Context c, CharSequence s, boolean primary) {
        TextView t = tv(c, s, 14f, primary ? Theme.BTN_TXT : Theme.GOLD, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        if (primary) {
            t.setBackground(grad(c, 12));
            t.setShadowLayer(6f, 0f, dp(c, 2), withAlpha(Theme.GOLD, 0x4D));
        } else {
            t.setBackground(soft(c, Theme.CARD, 12f));
        }
        t.setClickable(true);
        return t;
    }

    public static TextView chip(Context c, CharSequence s, int color) {
        TextView t = tv(c, s, 11f, color, false);
        t.setPadding(dp(c, 8), dp(c, 3), dp(c, 8), dp(c, 3));
        t.setBackground(soft(c, Theme.CARD2, 20f));
        return t;
    }

    public static EditText input(Context c, String hint, boolean multi, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(Theme.SUB);
        e.setTextColor(Theme.TEXT);
        e.setTextSize(14f);
        e.setBackground(inset(c, Theme.CARD2, 12f));
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP | Gravity.START);
        } else {
            e.setInputType(InputType.TYPE_CLASS_TEXT);
            e.setSingleLine(true);
        }
        if (value != null) e.setText(value);
        return e;
    }

    /** 代码风格多行输入（等宽字体、偏大行距），用于 JSON 源码编辑。 */
    public static EditText codeInput(Context c, String value) {
        EditText e = input(c, "在此粘贴或编辑 JSON 代码", true, value);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setTypeface(android.graphics.Typeface.MONOSPACE);
        e.setTextSize(12f);
        e.setHorizontallyScrolling(false);
        e.setMinLines(10);
        e.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
        return e;
    }

    public static EditText inputPwd(Context c, String hint, String value) {
        EditText e = input(c, hint, false, value);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setBackground(soft(c, Theme.CARD, 20f));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    /** 新拟态对话框容器：无标题栏、透明窗、88% 屏宽，内容由调用方用 card 包裹。 */
    public static android.app.Dialog dialog(Context c) {
        android.app.Dialog d = new android.app.Dialog(c);
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        android.view.Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            int width = Math.round(c.getResources().getDisplayMetrics().widthPixels * 0.88f);
            w.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        return d;
    }

    /** 新拟态开关：玫瑰粉轨道 + 白色滑块，替代系统默认蓝色。 */
    public static android.widget.Switch switchBtn(Context c) {
        android.widget.Switch s = new android.widget.Switch(c);
        s.setTrackTintList(android.content.res.ColorStateList.valueOf(withAlpha(Theme.GOLD, 0x66)));
        s.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.GOLD_LIGHT));
        return s;
    }

    public static View line(Context c) {
        View v = new View(c);
        v.setBackgroundColor(Theme.STROKE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
        p.topMargin = dp(c, 8);
        p.bottomMargin = dp(c, 8);
        v.setLayoutParams(p);
        return v;
    }

    public static View gap(Context c, int h) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, h)));
        return v;
    }

    public static GradientDrawable bg(Context c, int fill, int radiusDp, int strokeW, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeW > 0) g.setStroke(dp(c, strokeW), strokeColor);
        return g;
    }

    public static GradientDrawable grad(Context c, int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Theme.GOLD_LIGHT, Theme.GOLD});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static void add(ViewGroup parent, View child, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(parent.getContext(), topDp);
        parent.addView(child, p);
    }

    public static LinearLayout kv(Context c, String k, String v) {
        LinearLayout r = row(c);
        TextView kk = tv(c, k, 12f, Theme.SUB, false);
        kk.setMinWidth(dp(c, 74));
        TextView vv = tv(c, v == null ? "" : v, 13f, Theme.TEXT, false);
        vv.setPadding(dp(c, 8), 0, 0, 0);
        r.addView(kk);
        r.addView(vv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }

    public static ScrollView scroller(Context c, View child) {
        ScrollView s = new ScrollView(c);
        s.setFillViewport(true);
        s.setBackgroundColor(Color.TRANSPARENT);
        s.addView(child, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return s;
    }

    public static LinearLayout page(Context c) {
        LinearLayout l = col(c);
        int p = dp(c, 14);
        l.setPadding(p, p, p, dp(c, 28));
        return l;
    }

    public static void toast(Context c, String s) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show();
    }

    /** 后台执行 + 主线程回调。 */
    public interface Job {
        String run() throws Exception;
    }

    public interface Done {
        void done(String result, Throwable err);
    }

    public static void run(Activity a, final Job job, final Done done) {
        final Handler h = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() {
            @Override
            public void run() {
                String res = null;
                Throwable err = null;
                try {
                    res = job.run();
                } catch (Throwable t) {
                    err = t;
                }
                final String r = res;
                final Throwable e = err;
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (done != null) done.done(r, e);
                    }
                });
            }
        }, "console-job").start();
    }
}
