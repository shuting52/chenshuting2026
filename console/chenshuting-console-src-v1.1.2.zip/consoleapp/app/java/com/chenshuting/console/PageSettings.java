package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;

/** 设置：仓库信息、Token（含 401 体检）、连接自检、清单重建、日志。 */
public class PageSettings extends Page {

    public static final String TOKEN_PAGE = "https://github.com/settings/tokens";

    private EditText inRepo;
    private EditText inBranch;
    private EditText inToken;
    private Switch swRaw;
    private TextView status;
    private TextView tokenNow;

    public PageSettings(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "设置"));
        body.addView(Ui.sub(ctx, "控制台通过 GitHub Contents API 直接读写仓库，改动提交后由 App 端自动拉取。"));

        Tutorial.add(body, ctx, "设置页 · 怎么用", new String[]{
                "填仓库与分支|仓库按 owner/repo 填写（默认 shuting52/chenshuting2026），分支默认 main。",
                "填访问令牌|GitHub Personal Access Token，需 repo 权限；只保存在本机，不会上传任何服务器。",
                "令牌体检|粘贴令牌后点「仅校验令牌」：会先做本地形状检查（位数/前缀/空白），再联网核验，401 会直接告诉你属于哪一类原因。",
                "保存并测试连接|点「保存并测试连接」：提示「连接正常」即表示仓库与令牌可用。",
                "遇到 401 怎么办|点「去 GitHub 生成新令牌」重新签发（勾选 repo），回到本页粘贴 → 校验通过 → 保存；旧令牌已失效就不用再试。",
                "重建内容清单|内容文件有增减后点「重建内容清单」，否则工具箱读不到新文件。",
                "查看日志|操作报错时在「最近操作日志」里看具体返回码与原因，便于定位。"});

        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "仓库"));
        c1.addView(Ui.sub(ctx, "仓库（owner/repo）"));
        inRepo = Ui.input(ctx, Repo.DEF_REPO, false, Repo.repo(ctx));
        Ui.add(c1, inRepo, 4);
        c1.addView(Ui.sub(ctx, "分支"));
        inBranch = Ui.input(ctx, Repo.DEF_BRANCH, false, Repo.branch(ctx));
        Ui.add(c1, inBranch, 4);
        Ui.add(body, c1, 12);

        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "访问令牌"));
        c2.addView(Ui.sub(ctx, "GitHub Personal Access Token（需 repo 权限，仅保存在本机）"));
        inToken = Ui.input(ctx, "ghp_ 或 github_pat_ ...", false, Repo.token(ctx));
        inToken.setHint("ghp_ 或 github_pat_ ...");
        Ui.add(c2, inToken, 4);
        tokenNow = Ui.tv(ctx, tokenHint(Repo.token(ctx)), 12f, Theme.SUB, false);
        Ui.add(c2, tokenNow, 6);

        LinearLayout row1 = Ui.row(ctx);
        TextView check = Ui.btn(ctx, "仅校验令牌", true);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkToken();
            }
        });
        row1.addView(check);
        TextView gen = Ui.btn(ctx, "去 GitHub 生成新令牌", false);
        LinearLayout.LayoutParams glp = wrap();
        glp.leftMargin = Ui.dp(ctx, 8);
        row1.addView(gen, glp);
        gen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                act.openUrl(TOKEN_PAGE);
            }
        });
        Ui.add(c2, row1, 10);

        LinearLayout row2 = Ui.row(ctx);
        TextView clrToken = Ui.btn(ctx, "清除本机令牌", false);
        clrToken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmClearToken();
            }
        });
        row2.addView(clrToken);
        Ui.add(c2, row2, 8);

        Ui.add(c2, Ui.sub(ctx, "401 的四种常见成因：① 令牌已过期或在 GitHub 上被删除；"
                + "② 复制不完整（少一位/带空格）；③ 令牌被打进公开包，被 GitHub 密钥扫描自动吊销；"
                + "④ 令牌没有 repo 权限或已被改成细粒度但未授权本仓库。"
                + "校验结果会直接指明属于哪一类，按提示处理后即可恢复发布。"), 8);
        Ui.add(body, c2, 12);

        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "自检与维护"));
        TextView save = Ui.btn(ctx, "保存并测试连接", true);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAndTest();
            }
        });
        Ui.add(c3, save, 8);
        TextView rebuild = Ui.btn(ctx, "按仓库现有 data/ 文件重建内容清单", false);
        rebuild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmRebuild();
            }
        });
        Ui.add(c3, rebuild, 8);
        Ui.add(c3, Ui.sub(ctx, "清单 manifest.json 决定 App 端下载哪些内容文件；本地发布已自动维护，此按钮用于修复不一致。"), 6);

        swRaw = Ui.switchBtn(ctx);
        swRaw.setText("显示接口原始错误信息");
        swRaw.setTextColor(Theme.TEXT);
        swRaw.setTextSize(13f);
        swRaw.setChecked(Prefs.verbose(ctx));
        Ui.add(c3, swRaw, 10);
        Ui.add(body, c3, 12);

        LinearLayout c4 = Ui.card(ctx);
        c4.addView(Ui.section(ctx, "操作日志"));
        c4.addView(Ui.tv(ctx, orNone(Prefs.logs(ctx)), 12f, Theme.SUB, false));
        TextView clr = Ui.btn(ctx, "清空日志", false);
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.clearLogs(ctx);
                rebuild();
                Ui.toast(ctx, "日志已清空");
            }
        });
        Ui.add(c4, clr, 10);
        Ui.add(body, c4, 12);

        status = Ui.tv(ctx, "版本 " + Repo.APP_VER + " · " + Repo.today(), 12f, Theme.SUB, false);
        Ui.add(body, status, 10);
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private String tokenHint(String t) {
        if (t == null || t.length() == 0) return "当前：未配置（发布类操作会返回 401）";
        String shape = Gh.tokenShape(t);
        String base = "当前：" + Prefs.mask(t) + " · 共 " + t.length() + " 位";
        return shape.length() == 0 ? base + " · 形状正常" : base + " · " + shape;
    }

    private static String orNone(String s) {
        return s == null || s.length() == 0 ? "暂无记录" : (s.length() > 900 ? s.substring(0, 900) + "…" : s);
    }

    /** 令牌体检：本地形状检查 + 联网核验 + 权限检查。 */
    private void checkToken() {
        final String t = inToken.getText().toString().trim();
        String shape = Gh.tokenShape(t);
        if (shape.length() > 0) {
            String msg = "令牌未通过本地检查：" + shape + "。请重新复制完整令牌（ghp_ 开头共 40 位）后再校验。";
            act.setText(status, msg);
            log("令牌体检未通过：" + shape);
            act.badge("令牌格式异常", Theme.ERR);
            return;
        }
        act.setText(status, "正在校验令牌…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                Gh.R u = Gh.user(t);
                if (u.code == 401) {
                    return "令牌无效（HTTP 401 Bad credentials）：GitHub 明确拒绝了该令牌，说明它已失效——"
                            + "已被删除/过期，或原令牌曾暴露在公开仓库里被自动吊销。请点「去 GitHub 生成新令牌」"
                            + "重新签发（勾选 repo 权限）后粘贴回来。";
                }
                if (u.code == 403) return "令牌被拒绝（HTTP 403）：" + Repo.explain(403, u.msg());
                if (u.code < 0) return "网络不可达，无法核验令牌：" + u.msg();
                if (!u.ok()) return "校验失败：" + Repo.explain(u.code, u.msg());
                JSONObject j = u.json();
                String login = j == null ? "" : j.optString("login", "");
                StringBuilder sb = new StringBuilder("令牌有效：账号 " + login);
                if (u.scopes != null && u.scopes.length() > 0) sb.append(" · 权限范围 " + u.scopes);
                if (!Gh.hasRepoScope(u))
                    sb.append("。注意：该令牌未包含 repo 权限，读私有仓库会返回 404，写文件会返回 403——"
                            + "请重新签发时勾选 repo。");
                else sb.append("。权限满足仓库读写要求，可以直接保存。");
                if (u.rateLeft != null && u.rateLeft.length() > 0) sb.append(" 剩余额度 " + u.rateLeft + "。");
                return sb.toString();
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "校验失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result);
                log("令牌体检：" + result);
                boolean bad = result.startsWith("令牌无效") || result.startsWith("令牌被拒绝")
                        || result.startsWith("校验失败") || result.startsWith("网络不可达");
                act.badge(bad ? "令牌不可用" : "令牌可用", bad ? Theme.ERR : Theme.OK);
            }
        });
    }

    private void confirmClearToken() {
        new AlertDialog.Builder(act)
                .setTitle("清除本机令牌？")
                .setMessage("将从本机删除保存的 GitHub 令牌。清除后所有发布类操作都会因缺少凭据而返回 401，"
                        + "直到重新粘贴新令牌。仓库里的文件与已发布内容不受影响。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认清除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Prefs.setToken(ctx, "");
                        log("已清除本机令牌");
                        rebuild();
                        Ui.toast(ctx, "本机令牌已清除");
                    }
                })
                .show();
    }

    private void saveAndTest() {
        final String t = inToken.getText().toString().trim();
        Prefs.setRepo(ctx, inRepo.getText().toString().trim());
        Prefs.setBranch(ctx, inBranch.getText().toString().trim());
        Prefs.setToken(ctx, t);
        Prefs.setVerbose(ctx, swRaw.isChecked());
        String shape = Gh.tokenShape(t);
        if (shape.length() > 0) {
            act.setText(status, "已保存，但令牌未通过本地检查：" + shape);
            act.badge("令牌格式异常", Theme.ERR);
            log("保存设置：令牌形状异常（" + shape + "）");
            return;
        }
        act.setText(status, "正在测试连接…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                Gh.R u = Gh.user(Repo.token(ctx));
                if (!u.ok()) return "账号校验失败：" + Repo.explain(u.code, u.msg());
                JSONObject j = u.json();
                String login = j == null ? "" : j.optString("login", "");
                Gh.R repo = Repo.repoCheck(ctx);
                if (!repo.ok()) return "仓库不可读（" + Repo.repo(ctx) + "）：" + Repo.explain(repo.code, repo.msg());
                List<String> apks = Repo.rootApks(ctx);
                return "连接正常：账号 " + login + "，仓库可读写，根目录 APK " + apks.size() + " 个";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "测试失败：" + err.getMessage());
                    act.badge("连接异常", Theme.ERR);
                    return;
                }
                act.setText(status, result);
                log("自检：" + result);
                act.badge(result.startsWith("连接正常") ? "连接正常" : "连接异常",
                        result.startsWith("连接正常") ? Theme.OK : Theme.ERR);
                rebuild();
            }
        });
    }

    private void confirmRebuild() {
        new AlertDialog.Builder(act)
                .setTitle("确认重建清单")
                .setMessage("将按仓库 data/ 目录下现有内容文件重新生成 manifest.json，"
                        + "并更新清单版本号，触发 App 端重新同步。\n\n发布流程之外的一般情况下无需手动执行。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认重建", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        act.setText(status, "正在重建内容清单…");
                        Ui.run(act, new Ui.Job() {
                            @Override
                            public String run() throws Exception {
                                return Repo.rebuildManifest(ctx);
                            }
                        }, new Ui.Done() {
                            @Override
                            public void done(String result, Throwable err) {
                                if (err != null) {
                                    act.setText(status, "重建失败：" + err.getMessage());
                                    return;
                                }
                                act.setText(status, result + " · " + Repo.today());
                                log("清单重建：" + result);
                                act.badge("清单已重建", Theme.OK);
                            }
                        });
                    }
                })
                .show();
    }
}
