package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONObject;

/** 弹窗页：四类弹窗（本体通用 / 更新 / 置顶 / 我的页）的样式编辑器 + 实时预览 + 代码输入 / 上传 + 云端发布。
 *  配置落 data/dialogs.json，本体启动后自动同步生效。 */
public final class PageDialog extends Page {

    /* 颜色一律用 #RRGGBB 代码输入（已按要求移除取色器与预设色板），改完即时生效。 */

    private final JSONObject scenes;
    private int sel = 0;
    private LinearLayout editor;
    private LinearLayout chipsRow;
    private TextView stageSub;

    /** 内嵌实时预览容器：编辑器每 0.5 秒按当前配置重建一次，做到「改一下、看一眼」。 */
    private LinearLayout previewSlot;
    private final Runnable previewTick = new Runnable() {
        @Override
        public void run() {
            if (previewSlot == null || previewSlot.getParent() == null) return;
            DialogPreview.inline(previewSlot, scene(sel), sel);
            previewSlot.postDelayed(this, 500);
        }
    };

    public PageDialog(MainActivity a) {
        super(a);
        scenes = Skin.defaults();
    }

    @Override
    protected void build() {
        Tutorial.add(body, ctx, "弹窗样式页 · 怎么用", new String[]{
                "选场景：顶部三个标签分别对应「本体通用弹窗 / 更新弹窗 / 我的页弹窗」，点一下即切换编辑对象。",
                "调参数：宽度比例、圆角、内间距、描边粗细决定弹窗外形；标题/正文字号与颜色决定文字观感；金龙、极光、光斑三个开关可单独关掉特效。",
                "选颜色：取色器已移除，颜色一律以代码形式填写（#RRGGBB 或 #AARRGGBB 带透明度），输入即生效。",
                "看效果：编辑区顶部的「实时预览」随参数改动即时刷新；点「预览当前弹窗」可再弹出真实样例弹窗核对。",
                "代码输入：点「编辑 JSON 代码」可直接改源码，粘贴别人给的整套皮肤后点「校验并应用」，解析失败会原样保留旧配置。",
                "上传导入：点「上传 JSON 文件」选手机里的 dialogs.json 导入；也可以「复制当前配置」发给别人，或「从剪贴板导入」粘贴回来。",
                "发布生效：点「发布到线上」，配置写入仓库 data/dialogs.json，工具箱下次启动自动拉取换肤；用户无需更新 APK。",
                "备份与还原：点「从线上读取」可拉回当前线上配置继续改；点「恢复默认」把当前场景还原为出厂样式。",
                "注意：更新弹窗默认强制不可关闭，「确定按钮文案」就是它的主按钮文字；我的页弹窗独立配色，便于区分使用场景。"});

        LinearLayout bar = Ui.row(ctx);
        TextView b1 = Ui.btn(ctx, "预览当前弹窗", true);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogPreview.sample(act, scene(sel), sel);
            }
        });
        bar.addView(b1);

        TextView b2 = Ui.btn(ctx, "发布到线上", false);
        LinearLayout.LayoutParams blp = lpWrap();
        blp.leftMargin = Ui.dp(ctx, 8);
        bar.addView(b2, blp);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publish();
            }
        });
        Ui.add(body, bar, 4);

        LinearLayout bar2 = Ui.row(ctx);
        TextView b3 = Ui.btn(ctx, "从线上读取", false);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pull();
            }
        });
        bar2.addView(b3);

        TextView b4 = Ui.btn(ctx, "恢复默认", false);
        LinearLayout.LayoutParams b4lp = lpWrap();
        b4lp.leftMargin = Ui.dp(ctx, 8);
        bar2.addView(b4, b4lp);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject d = Skin.defaults().optJSONObject(Skin.SCENES[sel]);
                try {
                    scenes.put(Skin.SCENES[sel], d);
                } catch (Throwable ignored) {
                }
                rebuildEditor();
                info("已恢复「" + Skin.SCENE_LABEL[sel] + "」出厂样式，记得点发布");
            }
        });

        TextView b5 = Ui.btn(ctx, "全部预览", false);
        LinearLayout.LayoutParams b5lp = lpWrap();
        b5lp.leftMargin = Ui.dp(ctx, 8);
        bar2.addView(b5, b5lp);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogPreview.sample(act, scene(sel), sel);
            }
        });
        Ui.add(body, bar2, 8);

        LinearLayout bar3 = Ui.row(ctx);
        TextView b6 = Ui.btn(ctx, "编辑 JSON 代码", true);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCode();
            }
        });
        bar3.addView(b6);

        TextView b7 = Ui.btn(ctx, "上传 JSON 文件", false);
        LinearLayout.LayoutParams b7lp = lpWrap();
        b7lp.leftMargin = Ui.dp(ctx, 8);
        bar3.addView(b7, b7lp);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upload();
            }
        });
        Ui.add(body, bar3, 4);

        LinearLayout bar5 = Ui.row(ctx);
        TextView b10 = Ui.btn(ctx, "编辑 CSS 代码", true);
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCss();
            }
        });
        bar5.addView(b10);
        Ui.add(body, bar5, 4);
        Ui.add(body, Ui.sub(ctx, "CSS 代码随当前场景存入 dialogs.json 的 css 字段，本体端弹窗渲染时套用（可放 Uiverse.io 风格的动效代码）。"), 2);

        LinearLayout bar4 = Ui.row(ctx);
        TextView b8 = Ui.btn(ctx, "复制当前配置", false);
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyJson();
            }
        });
        bar4.addView(b8);

        TextView b9 = Ui.btn(ctx, "从剪贴板导入", false);
        LinearLayout.LayoutParams b9lp = lpWrap();
        b9lp.leftMargin = Ui.dp(ctx, 8);
        bar4.addView(b9, b9lp);
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pasteJson();
            }
        });
        Ui.add(body, bar4, 8);

        LinearLayout stage = Ui.card(ctx);
        TextView st = Ui.section(ctx, "选择要编辑的弹窗");
        stage.addView(st);
        stageSub = Ui.sub(ctx, "当前：" + Skin.SCENE_LABEL[0] + " · " + Skin.SCENE_DESC[0]);
        Ui.add(stage, stageSub, 6);

        chipsRow = Ui.col(ctx);
        for (int i = 0; i < Skin.SCENES.length; i++) {
            final int k = i;
            TextView chip = Ui.btn(ctx, Skin.SCENE_LABEL[i], i == sel);
            chip.setClickable(true);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sel = k;
                    rebuildChips();
                    rebuildEditor();
                }
            });
            LinearLayout.LayoutParams lp = lpMatch();
            lp.topMargin = Ui.dp(ctx, 8);
            chipsRow.addView(chip, lp);
        }
        stage.addView(chipsRow);
        Ui.add(body, stage, 10);

        editor = Ui.col(ctx);
        Ui.add(body, editor, 0);
        rebuildEditor();

        // 首次进入时静默拉取线上配置
        pull(false);
    }

    @Override
    protected void onShow() {
        // 每次进入该页时若未编辑过则刷新一次
    }

    private JSONObject scene(int i) {
        JSONObject s = scenes.optJSONObject(Skin.SCENES[i]);
        if (s == null) {
            s = Skin.defaults().optJSONObject(Skin.SCENES[i]);
            try {
                scenes.put(Skin.SCENES[i], s);
            } catch (Throwable ignored) {
            }
        }
        return s;
    }

    private void rebuildChips() {
        for (int i = 0; i < chipsRow.getChildCount(); i++) {
            TextView chip = (TextView) chipsRow.getChildAt(i);
            boolean on = i == sel;
            chip.setTextColor(on ? Theme.BTN_TXT : Theme.TEXT);
            chip.setBackground(on ? Ui.grad(ctx, 20) : Ui.bg(ctx, Theme.CARD2, 20, 1, Theme.STROKE));
        }
        stageSub.setText("当前：" + Skin.SCENE_LABEL[sel] + " · " + Skin.SCENE_DESC[sel]);
    }

    private void rebuildEditor() {
        editor.removeAllViews();
        final JSONObject s = scene(sel);
        if (stageSub != null) {
            stageSub.setText("当前：" + Skin.SCENE_LABEL[sel] + " · " + Skin.SCENE_DESC[sel]);
        }

        // 实时预览：内嵌在编辑区顶部，随下方参数改动自动重建（不再依赖点击弹出的虚拟预览）
        LinearLayout pvCard = Ui.card(ctx);
        pvCard.addView(Ui.section(ctx, "实时预览 · " + Skin.SCENE_LABEL[sel]));
        pvCard.addView(Ui.sub(ctx, "下方任意参数改动都会即时反映到这张卡片上"));
        previewSlot = new LinearLayout(ctx);
        previewSlot.setOrientation(LinearLayout.VERTICAL);
        previewSlot.setGravity(Gravity.CENTER_HORIZONTAL);
        Ui.add(pvCard, previewSlot, 6);
        Ui.add(editor, pvCard, 10);
        previewSlot.post(previewTick);

        LinearLayout sizeCard = Ui.card(ctx);
        sizeCard.addView(Ui.section(ctx, "外形 · " + Skin.SCENE_LABEL[sel]));
        sizeCard.addView(Ui.sub(ctx, "控制弹窗宽度、圆角、内边距与描边，左侧数值实时跟随"));
        seek(sizeCard, s, "widthRatio", "宽度占屏比", 0.5f, 1.0f, 0.01f, false);
        seek(sizeCard, s, "radiusDp", "圆角(dp)", 0, 48, 1, true);
        seek(sizeCard, s, "padDp", "卡片内边距(dp)", 6, 36, 1, true);
        seek(sizeCard, s, "strokeWidthDp", "描边粗细(dp)", 0, 4, 0.2f, false);
        seek(sizeCard, s, "maxHeightRatio", "内容最大高度占比", 0.4f, 0.85f, 0.01f, false);
        seek(sizeCard, s, "dimAmount", "背景压暗程度", 0, 0.9f, 0.02f, false);
        option(sizeCard, s, "bgStyle", "背景类型", new String[]{"glass", "solid"},
                new String[]{"玻璃磨砂", "实色卡片"});
        option(sizeCard, s, "position", "弹出位置", new String[]{"center", "bottom"},
                new String[]{"屏幕居中", "底部弹出"});
        option(sizeCard, s, "enterAnim", "入场动画", new String[]{"overshoot", "fade", "slideUp"},
                new String[]{"弹性放大", "淡入", "上滑"});
        colorRow(sizeCard, s, "bgColor", "卡片底色");
        colorRow(sizeCard, s, "strokeColor", "描边 / 高光色");
        Ui.add(editor, sizeCard, 10);

        LinearLayout textCard = Ui.card(ctx);
        textCard.addView(Ui.section(ctx, "文字 · " + Skin.SCENE_LABEL[sel]));
        text(textCard, s, "okText", "主按钮文案");
        seek(textCard, s, "titleSizeSp", "标题字号(sp)", 12, 26, 0.5f, false);
        seek(textCard, s, "bodySizeSp", "正文字号(sp)", 10, 20, 0.5f, false);
        colorRow(textCard, s, "titleColor", "标题颜色");
        colorRow(textCard, s, "bodyColor", "正文颜色");
        colorRow(textCard, s, "btnPrimaryColor", "按钮底色");
        colorRow(textCard, s, "btnPrimaryTextColor", "按钮文字色");
        Ui.add(editor, textCard, 10);

        LinearLayout fxCard = Ui.card(ctx);
        fxCard.addView(Ui.section(ctx, "特效开关"));
        fxCard.addView(Ui.sub(ctx, "关掉可显著降低低端机负担（金龙与漂浮特效较吃性能）"));
        switchRow(fxCard, s, "dragon", "金龙绕边框");
        switchRow(fxCard, s, "aurora", "极光柔光背板");
        switchRow(fxCard, s, "decor", "漂浮金币彩带");
        Ui.add(editor, fxCard, 10);

        LinearLayout pub = Ui.card(ctx);
        pub.addView(Ui.section(ctx, "发布"));
        TextView tip = Ui.sub(ctx, "预览 · 发布 · 还原，三步走；发布后本体下次启动自动生效");
        pub.addView(tip);

        LinearLayout row = Ui.row(ctx);
        TextView p = Ui.btn(ctx, "预览当前弹窗", true);
        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogPreview.sample(act, scene(sel), sel);
            }
        });
        row.addView(p);
        TextView q = Ui.btn(ctx, "发布到线上", false);
        LinearLayout.LayoutParams qlp = lpWrap();
        qlp.leftMargin = Ui.dp(ctx, 8);
        row.addView(q, qlp);
        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publish();
            }
        });
        Ui.add(pub, row, 10);
        Ui.add(editor, pub, 10);

        LinearLayout all = Ui.card(ctx);
        all.addView(Ui.section(ctx, "三类弹窗速览"));
        for (int i = 0; i < Skin.SCENES.length; i++) {
            LinearLayout kv = Ui.kv(ctx, Skin.SCENE_LABEL[i], "宽 " + pct(scene(i), "widthRatio")
                    + " · 圆角 " + Skin.i(scene(i), "radiusDp", 28) + "dp · "
                    + Skin.str(scene(i), "okText", "我知道了"));
            final int k = i;
            kv.setClickable(true);
            kv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DialogPreview.sample(act, scene(k), k);
                }
            });
            Ui.add(all, kv, 8);
        }
        Ui.add(editor, all, 10);
    }

    private String pct(JSONObject s, String k) {
        return Math.round(Skin.f(s, k, 0.9f) * 100) + "%";
    }

    // ---------------- 控件工厂 ----------------

    private void seek(LinearLayout card, final JSONObject s, final String key, String label,
                      float min, float max, final float step, final boolean integer) {
        LinearLayout head = Ui.row(ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        final TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        head.addView(name, nlp);
        final TextView val = Ui.tv(ctx, fmt(Skin.f(s, key, min), integer), 12.5f, Theme.GOLD_LIGHT, true);
        head.addView(val);
        Ui.add(card, head, 12);

        SeekBar sb = new SeekBar(ctx);
        // 新拟态着色：玫瑰粉轨道/滑块，替代系统默认蓝色
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Theme.GOLD));
        sb.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Theme.STROKE));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Theme.GOLD_LIGHT));
        int steps = Math.max(1, Math.round((max - min) / step));
        sb.setMax(steps);
        sb.setProgress(Math.max(0, Math.min(steps, Math.round((Skin.f(s, key, min) - min) / step))));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                float v = min + progress * step;
                if (integer) v = Math.round(v);
                v = (float) (Math.round(v * 1000.0) / 1000.0);
                try {
                    s.put(key, v);
                } catch (Throwable ignored) {
                }
                val.setText(fmt(v, integer));
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        card.addView(sb);
    }

    private String fmt(float v, boolean integer) {
        if (integer) return String.valueOf(Math.round(v));
        if (Math.abs(v) >= 1f && v == Math.round(v)) return String.valueOf(Math.round(v));
        return String.valueOf(v);
    }

    private void text(LinearLayout card, final JSONObject s, final String key, String label) {
        card.addView(Ui.sub(ctx, label));
        final EditText e = Ui.input(ctx, "如：我知道了 / 立即更新 / 关闭", false, Skin.str(s, key, ""));
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence cs, int a, int b, int c) {
                try {
                    s.put(key, cs.toString());
                } catch (Throwable ignored) {
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable ed) {
            }
        });
        Ui.add(card, e, 6);
    }

    private void colorRow(LinearLayout card, final JSONObject s, final String key, String label) {
        LinearLayout head = Ui.row(ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        head.addView(name, nlp);

        final EditText e = Ui.input(ctx, "#RRGGBB", false, Skin.str(s, key, "#FFFFFF"));
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(Ui.dp(ctx, 120),
                LinearLayout.LayoutParams.WRAP_CONTENT);
        head.addView(e, elp);
        final View swatch = new View(ctx);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(Ui.dp(ctx, 22), Ui.dp(ctx, 22));
        slp.leftMargin = Ui.dp(ctx, 8);
        head.addView(swatch, slp);
        swatch.setBackground(Ui.bg(ctx, Skin.color(Skin.str(s, key, "#FFFFFF"), 0xFFFFFFFF), 6, 1, Theme.STROKE));
        Ui.add(card, head, 12);

        // 取色器已按需求移除：颜色一律以 #RRGGBB 代码形式输入，改完即时作用于右侧实时预览

        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence cs, int a, int b, int c) {
                String t = cs.toString();
                try {
                    s.put(key, t);
                } catch (Throwable ignored) {
                }
                if (t.startsWith("#") && (t.length() == 7 || t.length() == 9)) {
                    swatch.setBackground(Ui.bg(ctx, Skin.color(t, 0xFFFFFFFF), 6, 1, Theme.STROKE));
                }
            }

            @Override
            public void afterTextChanged(android.text.Editable ed) {
            }
        });
    }

    private void switchRow(LinearLayout card, final JSONObject s, final String key, String label) {
        LinearLayout row = Ui.row(ctx);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(name, nlp);
        final TextView sw = Ui.btn(ctx, Skin.bool(s, key, true) ? "已开启" : "已关闭", Skin.bool(s, key, true));
        sw.setClickable(true);
        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean nv = !Skin.bool(s, key, true);
                try {
                    s.put(key, nv);
                } catch (Throwable ignored) {
                }
                sw.setText(nv ? "已开启" : "已关闭");
                sw.setTextColor(nv ? Theme.BTN_TXT : Theme.TEXT);
                sw.setBackground(nv ? Ui.grad(ctx, 20) : Ui.bg(ctx, Theme.CARD2, 20, 1, Theme.STROKE));
            }
        });
        row.addView(sw);
        Ui.add(card, row, 10);
    }

    /** 选项行：值写入 key，显示可读名。 */
    private void option(LinearLayout card, final JSONObject s, final String key, String label,
                        final String[] values, final String[] names) {
        LinearLayout head = Ui.row(ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = Ui.tv(ctx, label, 12.5f, Theme.TEXT, false);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        head.addView(name, nlp);
        Ui.add(card, head, 12);

        LinearLayout row = Ui.row(ctx);
        final TextView[] cs = new TextView[values.length];
        for (int i = 0; i < values.length; i++) {
            final String v = values[i];
            final TextView chip = Ui.btn(ctx, names[i], v.equals(Skin.str(s, key, values[0])));
            chip.setClickable(true);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v2) {
                    try {
                        s.put(key, v);
                    } catch (Throwable ignored) {
                    }
                    for (TextView t : cs) {
                        boolean on = t.getText().toString().equals(v) || false;
                        t.setTextColor(Theme.TEXT);
                        t.setBackground(Ui.bg(ctx, Theme.CARD2, 20, 1, Theme.STROKE));
                    }
                    chip.setTextColor(Theme.BTN_TXT);
                    chip.setBackground(Ui.grad(ctx, 20));
                }
            });
            cs[i] = chip;
            LinearLayout.LayoutParams lp = lpWrap();
            if (i > 0) lp.leftMargin = Ui.dp(ctx, 8);
            row.addView(chip, lp);
        }
        card.addView(row);
    }

    // ---------------- 代码输入 / 上传导入 ----------------

    /** 直接编辑 JSON 代码：默认给当前选中场景，也可一键切换成整套四场景。 */
    private void openCode() {
        final EditText et = Ui.codeInput(ctx, prettyScene(sel));
        new AlertDialog.Builder(act)
                .setTitle("编辑 JSON 代码 · " + Skin.SCENE_LABEL[sel])
                .setView(wrapCode(et))
                .setPositiveButton("校验并应用", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        applyJson(et.getText().toString(), "代码输入");
                    }
                })
                .setNeutralButton("改成整套", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        openCodeAll();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 整套（四个场景）JSON 编辑。 */
    private void openCodeAll() {
        final EditText et = Ui.codeInput(ctx, prettyAll());
        new AlertDialog.Builder(act)
                .setTitle("编辑 JSON 代码 · 整套配置")
                .setView(wrapCode(et))
                .setPositiveButton("校验并应用", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        applyJson(et.getText().toString(), "代码输入");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 编辑当前场景的 CSS 代码（存 scenes.<scene>.css，随发布写入 dialogs.json）。
     *  采用自定义拟态对话框：输入框限高 + 底部固定按钮行，保证「校验并应用 / 取消」始终可见。 */
    private void openCss() {
        final EditText et = Ui.codeInput(ctx, Skin.str(scene(sel), "css", ""));
        et.setMinLines(8);
        et.setMaxLines(14);

        // 输入框固定限高（约 42% 屏高），超出内部滚动，避免把按钮挤出屏幕
        android.widget.ScrollView sv = new android.widget.ScrollView(ctx);
        sv.setFillViewport(false);
        int h = Math.round(ctx.getResources().getDisplayMetrics().heightPixels * 0.42f);
        sv.addView(et, new android.widget.ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, h));

        LinearLayout box = Ui.col(ctx);
        box.setBackground(Ui.soft(ctx, Theme.CARD, 20f));
        int pad = Ui.dp(ctx, 16);
        box.setPadding(pad, pad, pad, pad);
        box.addView(Ui.title(ctx, "编辑 CSS 代码 · " + Skin.SCENE_LABEL[sel]));
        TextView tip = Ui.sub(ctx, "CSS 随当前场景存进 dialogs.json 的 css 字段，本体端弹窗渲染时套用。"
                + "原生预览不套用 CSS，以 App 内实际效果为准。点「校验并应用」会先检查括号配对，通过后写入当前场景。");
        Ui.add(box, tip, 6);
        Ui.add(box, sv, 10);

        LinearLayout row = Ui.row(ctx);
        TextView ok = Ui.btn(ctx, "校验并应用", true);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = et.getText().toString().trim();
                String err = cssCheck(t);
                if (err != null) {
                    info("CSS 校验未通过：" + err);
                    return;
                }
                try {
                    if (t.length() == 0) scene(sel).remove("css");
                    else scene(sel).put("css", t);
                    info("CSS 已保存到「" + Skin.SCENE_LABEL[sel] + "」，记得发布");
                } catch (Throwable ex) {
                    info("保存失败：" + ex.getMessage());
                }
            }
        });
        row.addView(ok);
        TextView cancel = Ui.btn(ctx, "取消", false);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        clp.leftMargin = Ui.dp(ctx, 8);
        row.addView(cancel, clp);
        Ui.add(box, row, 12);

        final android.app.Dialog dlg = Ui.dialog(ctx);
        dlg.setContentView(box);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dlg.dismiss();
            }
        });
        dlg.show();
    }

    /** 简易 CSS 校验：仅检查 {} () [] 配对与引号是否闭合，避免明显语法错误直接入库。 */
    private String cssCheck(String t) {
        int round = 0, curly = 0, square = 0;
        boolean inStr = false;
        char strQ = 0;
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (inStr) {
                if (c == '\\') {
                    i++;
                } else if (c == strQ) {
                    inStr = false;
                }
                continue;
            }
            if (c == '"' || c == '\'') {
                inStr = true;
                strQ = c;
            } else if (c == '(') {
                round++;
            } else if (c == ')') {
                round--;
            } else if (c == '{') {
                curly++;
            } else if (c == '}') {
                curly--;
            } else if (c == '[') {
                square++;
            } else if (c == ']') {
                square--;
            }
            if (round < 0 || curly < 0 || square < 0) {
                return "存在多余的右括号";
            }
        }
        if (inStr) return "引号未闭合";
        if (round != 0) return "圆括号 () 数量不配对";
        if (curly != 0) return "花括号 {} 数量不配对";
        if (square != 0) return "方括号 [] 数量不配对";
        return null;
    }

    private LinearLayout wrapCode(EditText et) {
        LinearLayout box = Ui.col(ctx);
        int pad = Ui.dp(ctx, 12);
        box.setPadding(pad, pad, pad, pad / 2);
        box.addView(et, lpMatch());
        return box;
    }

    private String prettyScene(int i) {
        try {
            return Repo.pretty(scene(i));
        } catch (Throwable t) {
            return "{}";
        }
    }

    private String prettyAll() {
        try {
            return Repo.pretty(Skin.wrap(ctx, scenes));
        } catch (Throwable t) {
            return "{}";
        }
    }

    /** 上传本地 dialogs.json 导入。 */
    private void upload() {
        new AlertDialog.Builder(act)
                .setTitle("上传 JSON 文件")
                .setMessage("选择手机里的 dialogs.json（或任何含 common / update / top / mine 场景的 JSON）。"
                        + "确认后直接套用到编辑器，检查预览无误再点「发布到线上」；导入本身不会自动发布。")
                .setPositiveButton("选择文件", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        pick();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void pick() {
        act.pickFile("application/json", "dialogs.json", new MainActivity.PickCb() {
            @Override
            public void onPicked(String name, byte[] data) {
                String s;
                try {
                    s = new String(data, "UTF-8");
                } catch (Throwable t) {
                    s = new String(data);
                }
                applyJson(s, "上传文件 " + name);
            }

            @Override
            public void onFailed(String reason) {
                info("导入未完成：" + reason);
            }
        });
    }

    /** 复制整套配置到剪贴板，便于分享给他人。 */
    private void copyJson() {
        try {
            String s = prettyAll();
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null) {
                info("本机不支持剪贴板");
                return;
            }
            cm.setPrimaryClip(ClipData.newPlainText("dialogs.json", s));
            info("已复制整套配置（" + s.length() + " 字符），可直接粘贴给别人");
        } catch (Throwable t) {
            info("复制失败：" + t.getMessage());
        }
    }

    /** 从剪贴板粘贴 JSON 导入。 */
    private void pasteJson() {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip() == null) {
                info("剪贴板里没有可导入的内容");
                return;
            }
            ClipData.Item it = cm.getPrimaryClip().getItemAt(0);
            CharSequence cs = it == null ? null : it.coerceToText(ctx);
            if (cs == null || cs.length() == 0) {
                info("剪贴板里没有文本");
                return;
            }
            applyJson(cs.toString(), "剪贴板");
        } catch (Throwable t) {
            info("读取剪贴板失败：" + t.getMessage());
        }
    }

    /** 校验并套用一段 JSON：支持整套（scenes 包装或直接四场景）与单场景两种写法。 */
    private void applyJson(String text, String from) {
        if (text == null || text.trim().length() == 0) {
            info("内容为空，未做修改（原配置已保留）");
            return;
        }
        final JSONObject obj;
        try {
            obj = new JSONObject(text.trim());
        } catch (Throwable t) {
            info("JSON 解析失败，原配置已保留：" + t.getMessage());
            return;
        }
        JSONObject bag = obj.optJSONObject("scenes");
        if (bag == null) bag = obj;

        JSONObject picked = new JSONObject();
        int hit = 0;
        for (int i = 0; i < Skin.SCENES.length; i++) {
            JSONObject one = bag.optJSONObject(Skin.SCENES[i]);
            if (one != null) {
                try {
                    picked.put(Skin.SCENES[i], one);
                    hit++;
                } catch (Throwable ignored) {
                }
            }
        }
        if (hit == 0) {
            // 没有场景键名：按当前选中场景理解
            try {
                picked.put(Skin.SCENES[sel], obj);
            } catch (Throwable t) {
                info("应用失败：" + t.getMessage());
                return;
            }
        }

        try {
            JSONObject merged = Skin.merge(picked);
            int n = 0;
            for (int i = 0; i < Skin.SCENES.length; i++) {
                String k = Skin.SCENES[i];
                if (!picked.has(k)) continue;
                JSONObject one = merged.optJSONObject(k);
                if (one == null) continue;
                scenes.put(k, one);
                n++;
            }
            rebuildEditor();
            info("已应用" + from + "的 " + n + " 个场景，确认预览后点「发布到线上」生效");
            log("弹窗配置导入：" + from + " → " + n + " 个场景");
        } catch (Throwable t) {
            info("应用失败：" + t.getMessage());
        }
    }

    // ---------------- 数据操作 ----------------

    private void pull() {
        pull(true);
    }

    private void pull(final boolean toast) {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject remote = Skin.load(ctx);
                java.util.Iterator<String> it = remote.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    scenes.put(k, remote.optJSONObject(k));
                }
                return "已拉取线上弹窗配置";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err == null) {
                    rebuildEditor();
                    if (toast) info(result);
                } else if (toast) {
                    info("读取失败：" + err.getMessage());
                }
            }
        });
    }

    // ---------------- 布局参数助手 ----------------

    private LinearLayout.LayoutParams lpMatch() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams lpWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void publish() {
        final JSONObject payload;
        try {
            payload = Skin.wrap(ctx, scenes);
        } catch (Throwable t) {
            info("配置组装失败：" + t.getMessage());
            return;
        }
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                String text = Repo.pretty(payload);
                Repo.writeText(ctx, Skin.PATH, text, "console: 更新弹窗样式配置");
                // 登记进内容清单，工具箱端才会自动拉取（否则文件在仓库里但 App 读不到）
                Repo.manifestTouch(ctx, Skin.PATH, text.getBytes("UTF-8"));
                return "发布成功：已写入 dialogs.json 并登记内容清单，工具箱联网拉取后生效";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err == null) {
                    info(result);
                    log("弹窗皮肤已发布：" + Skin.PATH);
                } else {
                    info("发布失败：" + err.getMessage());
                }
            }
        });
    }
}
