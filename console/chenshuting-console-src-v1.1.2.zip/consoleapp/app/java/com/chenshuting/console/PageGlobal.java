package com.chenshuting.console;

import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONObject;

/** 本体全局：官方网址 / 置顶弹窗文字 / 应用名 / 图标 / 首页布局，以及控制台自身的图·视频背景。
 *  配置写入仓库 data/config.json，本体 1 分钟内自动拉取生效，用户无需更新 APK。 */
public class PageGlobal extends Page {

    private static final String PATH = "data/config.json";

    private EditText inName;
    private EditText inIcon;
    private EditText inUrl;
    private EditText inTitle;
    private EditText inSub;
    private EditText inLayout;
    private EditText inHint;
    private Switch swSplash;
    private EditText inBgImage;
    private EditText inBgColor;
    private EditText inSpTitle;
    private EditText inSpSub;
    private EditText inSpBtn;
    private EditText inSplashJson;
    private EditText inSplash;
    private TextView bgNow;
    private TextView status;

    public PageGlobal(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "本体全局"));
        body.addView(Ui.sub(ctx, "改完点「发布到本体」，工具箱 1 分钟内自动同步：官网入口、置顶文案、应用名与图标、首页布局全部无需发版。"));

        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "品牌"));
        c1.addView(Ui.sub(ctx, "应用显示名（顶栏 / 关于页）"));
        inName = Ui.input(ctx, "陈淑婷工具箱", false, "");
        Ui.add(c1, inName, 4);
        c1.addView(Ui.sub(ctx, "应用图标：可填图片地址，或点下面按钮从「内置图标 / 网址识别 / 本地上传」三选一"));
        inIcon = Ui.input(ctx, "https://…/logo.png", false, "");
        Ui.add(c1, inIcon, 4);
        TextView bIcon = Ui.btn(ctx, "选择图标（支持自定义上传）", false);
        Ui.add(c1, bIcon, 6);
        bIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IconPicker.show(act, inIcon.getText().toString(), new IconPicker.OnPick() {
                    @Override
                    public void pick(String value, String note) {
                        inIcon.setText(value);
                        info("已选择图标：" + note);
                    }
                });
            }
        });
        Ui.add(body, c1, 12);

        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "首页"));
        c2.addView(Ui.sub(ctx, "官方网站地址：留空时首页入口点击会提示未配置"));
        inUrl = Ui.input(ctx, "https://example.com", false, "");
        Ui.add(c2, inUrl, 4);
        c2.addView(Ui.sub(ctx, "官方网站卡片标题 / 副标题"));
        inTitle = Ui.input(ctx, "官方网站", false, "");
        Ui.add(c2, inTitle, 4);
        inSub = Ui.input(ctx, "点击进入官方网站", false, "");
        Ui.add(c2, inSub, 4);
        c2.addView(Ui.sub(ctx, "首页布局：card=卡片（默认）/ compact=紧凑"));
        inLayout = Ui.input(ctx, "card", false, "");
        Ui.add(c2, inLayout, 4);
        Ui.add(body, c2, 12);

        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "更新弹窗提示文字"));
        c3.addView(Ui.sub(ctx, "更新弹窗点「立即更新」后的提示语，改完实时同步到本体"));
        inHint = Ui.input(ctx, "请在浏览器中下载安装", false, "");
        Ui.add(c3, inHint, 4);
        Ui.add(body, c3, 12);

        LinearLayout c5 = Ui.card(ctx);
        c5.addView(Ui.section(ctx, "开屏界面（背景 / 文字 / 动效）"));
        c5.addView(Ui.sub(ctx, "本体启动时展示的开屏页：可随时增删背景、文字与动效。动效支持自由输入 JSON / CSS 代码，"
                + "发布后随 config.json 同步，本体 1 分钟内生效。"));

        LinearLayout rEn = Ui.row(ctx);
        rEn.setGravity(Gravity.CENTER_VERTICAL);
        TextView enName = Ui.tv(ctx, "启用开屏", 13f, Theme.TEXT, true);
        LinearLayout.LayoutParams enlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        rEn.addView(enName, enlp);
        swSplash = Ui.switchBtn(ctx);
        swSplash.setChecked(true);
        rEn.addView(swSplash);
        Ui.add(c5, rEn, 6);

        c5.addView(Ui.sub(ctx, "开屏背景：图片地址（可留空；留空则用纯色 / 默认粉紫渐变）"));
        inBgImage = Ui.input(ctx, "https://…/splash_bg.png（可留空）", false, "");
        Ui.add(c5, inBgImage, 4);
        c5.addView(Ui.sub(ctx, "开屏背景纯色（#RRGGBB，图片为空时生效，可留空）"));
        inBgColor = Ui.input(ctx, "#FDF3F9（可留空）", false, "");
        Ui.add(c5, inBgColor, 4);

        c5.addView(Ui.sub(ctx, "开屏文字：标题 / 副标题 / 按钮文案（留空则不显示对应元素）"));
        inSpTitle = Ui.input(ctx, "陈淑婷工具箱", false, "");
        Ui.add(c5, inSpTitle, 4);
        inSpSub = Ui.input(ctx, "白嫖怪互联网净土", false, "");
        Ui.add(c5, inSpSub, 4);
        inSpBtn = Ui.input(ctx, "开始使用", false, "");
        Ui.add(c5, inSpBtn, 4);

        c5.addView(Ui.sub(ctx, "动效 JSON（自由输入代码，如 {\"loader\":\"ring\",\"duration\":1200}，可留空）"));
        inSplashJson = Ui.input(ctx, "{ }", true, "");
        inSplashJson.setTypeface(android.graphics.Typeface.MONOSPACE);
        inSplashJson.setTextSize(11f);
        inSplashJson.setMinLines(4);
        Ui.add(c5, inSplashJson, 4);

        c5.addView(Ui.sub(ctx, "动效 / 按钮 CSS（Uiverse.io 风格 loader 旋转与渐变边框，留空则用内置默认）"));
        inSplash = Ui.input(ctx, "/* 开屏 CSS 代码 */", true, "");
        inSplash.setTypeface(android.graphics.Typeface.MONOSPACE);
        inSplash.setTextSize(11f);
        inSplash.setMinLines(10);
        Ui.add(c5, inSplash, 4);
        LinearLayout r5 = Ui.row(ctx);
        TextView bDef = Ui.btn(ctx, "填入默认开屏样式", false);
        bDef.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String css = readDefaultSplash();
                inSplash.setText(css);
                info("已填入默认开屏样式（loader 旋转 + 按钮渐变边框）");
            }
        });
        r5.addView(bDef);
        TextView bClrS = Ui.btn(ctx, "清空", false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = Ui.dp(ctx, 8);
        r5.addView(bClrS, slp);
        bClrS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inSplash.setText("");
            }
        });
        Ui.add(c5, r5, 6);
        Ui.add(body, c5, 12);

        LinearLayout c4 = Ui.card(ctx);
        c4.addView(Ui.section(ctx, "控制台背景（图 / 视频）"));
        c4.addView(Ui.sub(ctx, "界面主题：新拟态（默认）；可用下面的图片 / 视频覆盖为自定义背景"));
        bgNow = Ui.tv(ctx, bgText(), 12f, Theme.SUB, false);
        Ui.add(c4, bgNow, 6);
        LinearLayout r1 = Ui.row(ctx);
        TextView bImg = Ui.btn(ctx, "上传图片背景", false);
        bImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bg.pickImage(act, new Runnable() {
                    @Override
                    public void run() {
                        info("图片背景已应用，界面已刷新");
                        act.recreate();
                    }
                });
            }
        });
        r1.addView(bImg);
        TextView bVid = Ui.btn(ctx, "上传视频背景", false);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        vlp.leftMargin = Ui.dp(ctx, 8);
        r1.addView(bVid, vlp);
        bVid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bg.pickVideo(act, new Runnable() {
                    @Override
                    public void run() {
                        info("视频背景已应用（带声音），界面已刷新");
                        act.recreate();
                    }
                });
            }
        });
        Ui.add(c4, r1, 6);
        TextView bClr = Ui.btn(ctx, "取消背景", false);
        Ui.add(c4, bClr, 6);
        bClr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bg.clear(ctx);
                info("已取消自定义背景");
                act.recreate();
            }
        });
        Ui.add(body, c4, 12);

        LinearLayout bar = Ui.row(ctx);
        TextView pull = Ui.btn(ctx, "从线上读取", false);
        pull.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                load();
            }
        });
        bar.addView(pull);
        TextView push = Ui.btn(ctx, "发布到本体", true);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        plp.leftMargin = Ui.dp(ctx, 8);
        bar.addView(push, plp);
        push.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publish();
            }
        });
        Ui.add(body, bar, 8);

        status = Ui.tv(ctx, "待发布", 12f, Theme.SUB, false);
        Ui.add(body, status, 8);

        load();
    }

    private String bgText() {
        if (!Bg.has(ctx)) return "当前未设置自定义背景";
        return "当前背景：" + ("video".equals(Bg.type(ctx)) ? "视频" : "图片") + "（" + Bg.name(ctx) + "）";
    }

    private void load() {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                return Repo.readText(ctx, PATH);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "读取失败：" + (err.getMessage() == null ? "" : err.getMessage()));
                    return;
                }
                try {
                    JSONObject o = new JSONObject(result == null ? "{}" : result);
                    act.setText(inName, o.optString("appName", ""));
                    act.setText(inIcon, o.optString("iconUrl", ""));
                    act.setText(inUrl, o.optString("officialUrl", ""));
                    act.setText(inLayout, o.optString("homeLayout", "card"));
                    JSONObject t = o.optJSONObject("texts");
                    if (t != null) {
                        act.setText(inTitle, t.optString("official_title", ""));
                        act.setText(inSub, t.optString("official_sub", ""));
                        act.setText(inHint, t.optString("update_hint", ""));
                    }
                    act.setText(status, "已读取线上配置");
                    JSONObject sp = o.optJSONObject("splash");
                    if (sp != null) {
                        swSplash.setChecked(sp.optBoolean("enabled", true));
                        inBgImage.setText(sp.optString("bgImage", ""));
                        inBgColor.setText(sp.optString("bgColor", ""));
                        inSpTitle.setText(sp.optString("title", ""));
                        inSpSub.setText(sp.optString("subtitle", ""));
                        inSpBtn.setText(sp.optString("btnText", ""));
                        inSplashJson.setText(sp.optString("json", ""));
                        inSplash.setText(sp.optString("css", ""));
                    } else {
                        // 旧版字段兜底：只有 splashCss 时仅回填 CSS
                        act.setText(inSplash, o.optString("splashCss", ""));
                    }
                } catch (Throwable e) {
                    act.setText(status, "线上配置解析失败：" + e.getMessage());
                }
            }
        });
    }

    private void publish() {
        final JSONObject o = new JSONObject();
        try {
            put(o, "appName", inName);
            put(o, "iconUrl", inIcon);
            put(o, "officialUrl", inUrl);
            String layout = inLayout.getText().toString().trim();
            o.put("homeLayout", layout.length() == 0 ? "card" : layout);
            JSONObject sp = new JSONObject();
            sp.put("enabled", swSplash.isChecked());
            sp.put("bgImage", inBgImage.getText().toString().trim());
            sp.put("bgColor", inBgColor.getText().toString().trim());
            sp.put("title", inSpTitle.getText().toString().trim());
            sp.put("subtitle", inSpSub.getText().toString().trim());
            sp.put("btnText", inSpBtn.getText().toString().trim());
            sp.put("json", inSplashJson.getText().toString().trim());
            sp.put("css", inSplash.getText().toString().trim());
            o.put("splash", sp);
            // 兼容旧字段：老版本本体仍可读到开屏 CSS
            o.put("splashCss", inSplash.getText().toString().trim());
            JSONObject t = new JSONObject();
            putText(t, "official_title", inTitle, "官方网站");
            putText(t, "official_sub", inSub, "点击进入官方网站");
            putText(t, "update_hint", inHint, "请在浏览器中下载安装，安装后重新打开即可");
            o.put("texts", t);
        } catch (Throwable e) {
            info("配置组装失败：" + e.getMessage());
            return;
        }
        act.setText(status, "开始发布…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                Repo.writeText(ctx, PATH, Repo.pretty(o), "config: 本体全局配置更新");
                return Repo.readText(ctx, PATH);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + (err.getMessage() == null ? "" : err.getMessage()));
                    return;
                }
                act.setText(status, "已发布，本体 1 分钟内同步生效");
                act.badge("本体配置已发布", Theme.OK);
                log("本体全局配置发布完成");
            }
        });
    }

    private static void put(JSONObject o, String key, EditText e) throws Exception {
        o.put(key, e.getText().toString().trim());
    }

    private static void putText(JSONObject o, String key, EditText e, String def) throws Exception {
        String v = e.getText().toString().trim();
        o.put(key, v.length() == 0 ? def : v);
    }

    /** 读取内置默认开屏样式（res/raw/splash_default.css）。 */
    private String readDefaultSplash() {
        try {
            java.io.InputStream in = ctx.getResources().openRawResource(R.raw.splash_default);
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }
}
