package com.chenshuting.console;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** 淑婷控制台主界面：五页签 + 本地文件选择通道。 */
public class MainActivity extends Activity {

    private static final int REQ_PICK = 1001;

    private FrameLayout container;
    private Page[] pages;
    private TextView[] tabs;
    private TextView headBadge;

    private PickCb pendingPick;
    private String pendingPickName;

    /** 本地文件选择回调。 */
    public interface PickCb {
        void onPicked(String name, byte[] data);

        void onFailed(String reason);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Theme.BAR);

        final FrameLayout shell = new FrameLayout(this);
        LinearLayout root = Ui.col(this);
        // 设置了图 / 视频背景时页面底色透明，让背景透出来
        root.setBackground(Bg.has(this) ? null : Ui.softBg(this));

        LinearLayout head = Ui.row(this);
        int h = Ui.dp(this, 14);
        head.setPadding(h, Ui.dp(this, 12), h, Ui.dp(this, 12));
        head.setBackgroundColor(Theme.BAR);
        TextView title = Ui.tv(this, "淑婷控制台", 18f, Theme.GOLD_LIGHT, true);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        headBadge = Ui.chip(this, "v1.1.2", Theme.SUB);
        head.addView(headBadge);
        root.addView(head, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        container = new FrameLayout(this);
        root.addView(container, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bar = Ui.row(this);
        bar.setBackgroundColor(Theme.BAR);
        bar.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        shell.addView(root, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        Bg.attach(this, shell);
        setContentView(shell);

        pages = new Page[]{new PageOverview(this), new PagePublish(this), new PageContent(this),
                new PageDialog(this), new PageGlobal(this), new PageNotice(this), new PageSettings(this)};
        String[] names = {"总览", "发布", "内容", "弹窗", "本体", "公告", "设置"};
        tabs = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = Ui.tv(this, names[i], 13f, Theme.SUB, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switchTo(k);
                }
            });
            tabs[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        switchTo(0);
    }

    private void switchTo(int k) {
        container.removeAllViews();
        container.addView(pages[k].view(), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        for (int i = 0; i < tabs.length; i++) {
            boolean on = i == k;
            tabs[i].setTextColor(on ? Theme.GOLD_LIGHT : Theme.SUB);
            tabs[i].setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            tabs[i].setBackground(on ? Ui.soft(this, Theme.CARD, 10f) : null);
        }
        try {
            pages[k].onShow();
        } catch (Throwable ignored) {
        }
    }

    /** 头部状态徽标（连接状态提示）。 */
    public void badge(final String text, final int color) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                headBadge.setText(text);
                headBadge.setTextColor(color);
            }
        });
    }

    /** 主线程更新任意文本控件。 */
    public void setText(final TextView t, final String s) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                t.setText(s);
            }
        });
    }

    /** 唤起系统文件选择器，选中后回读字节。 */
    public void pickFile(String mime, String hintName, PickCb cb) {
        pendingPick = cb;
        pendingPickName = hintName;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime == null || mime.length() == 0 ? "*/*" : mime);
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Throwable t) {
            pendingPick = null;
            if (cb != null) cb.onFailed("无法打开文件选择器：" + t.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK) return;
        final PickCb cb = pendingPick;
        pendingPick = null;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (cb != null) cb.onFailed("已取消选择");
            return;
        }
        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = pendingPickName;
                try {
                    byte[] bytes = read(uri);
                    if (bytes == null || bytes.length == 0) {
                        final PickCb c1 = cb;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (c1 != null) c1.onFailed("文件读取为空");
                            }
                        });
                        return;
                    }
                    final String n = name;
                    final byte[] d = bytes;
                    final PickCb c2 = cb;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (c2 != null) c2.onPicked(n, d);
                        }
                    });
                } catch (final Throwable t) {
                    final PickCb c3 = cb;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (c3 != null) c3.onFailed("读取失败：" + t.getMessage());
                        }
                    });
                }
            }
        }, "pick-read").start();
    }

    private byte[] read(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) return null;
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        } finally {
            in.close();
        }
        return bo.toByteArray();
    }

    public void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Throwable t) {
            info("无法打开链接：" + url);
        }
    }

    private void info(String s) {
        Ui.toast(this, s);
    }
}
