package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 公告：欢迎语 + 滚动动态 + 实时时钟/农历 + 跑马灯特效 + 24 小时时段轮播，走独立实时通道。 */
public class PageNotice extends Page {

    /** 默认 24 小时时段问候（覆盖全天）。 */
    private static final String[][] DEF_SCHEDULE = {
            {"00:00", "04:59", "夜深了，早点休息，晚安好梦。"},
            {"05:00", "07:59", "清晨好，新的一天从早安开始！"},
            {"08:00", "10:59", "早上八点，记得吃早餐哟，上班的路上注意安全。"},
            {"11:00", "12:59", "中午好，记得按时吃午饭，歇一歇。"},
            {"13:00", "16:59", "下午好，喝口水活动一下，工作更高效。"},
            {"17:00", "18:59", "傍晚好，下班路上注意安全，辛苦了。"},
            {"19:00", "21:59", "晚上好，晚饭吃了吗？放松一下吧。"},
            {"22:00", "23:59", "夜深了，早点休息，明天继续加油！"}
    };

    private Switch swEnabled;
    private EditText inWelcome;
    private LinearLayout itemsHost;
    private TextView status;
    private final List<EditText> itemInputs = new ArrayList<EditText>();

    private Switch swClock;
    private Switch swMarquee;
    private LinearLayout scheduleHost;
    private final List<ScheduleRow> scheduleRows = new ArrayList<ScheduleRow>();

    /** 时段行：开始 / 结束 / 文案。 */
    private static class ScheduleRow {
        EditText inStart;
        EditText inEnd;
        EditText inText;
    }

    public PageNotice(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "公告"));
        Tutorial.add(body, ctx, "公告页 · 怎么用", new String[]{
                "开关：顶部总开关关掉后，App 首页不再显示跑马灯（配置仍保留，随时可再开）。",
                "欢迎语：单独一行，显示在跑马灯最前面，适合放节日问候或版本提示。",
                "动态条：每条一行，支持多行新增/删除，顺序即滚动顺序；建议每条不超过 30 字，念起来更顺。",
                "发布：点发布即写仓库 data/announcements.json，这是独立通道，约 1 分钟生效，不影响内容清单。",
                "验证：发布后杀掉 App 重开首页，跑马灯应能看到新内容；若没变，检查是否误关了总开关。"});
        body.addView(Ui.sub(ctx, "App 首页跑马灯：欢迎语 + 若干条滚动动态。"));
        Ui.add(body, Ui.sub(ctx, "本通道独立于内容清单，发布后约 1 分钟生效。"), 2);

        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "开关"));
        swEnabled = Ui.switchBtn(ctx);
        swEnabled.setText("启用滚动动态");
        swEnabled.setTextColor(Theme.TEXT);
        swEnabled.setTextSize(13f);
        swEnabled.setChecked(true);
        c1.addView(swEnabled);
        Ui.add(body, c1, 12);

        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "欢迎语"));
        inWelcome = Ui.input(ctx, "欢迎语", true, "");
        Ui.add(c2, inWelcome, 4);
        Ui.add(body, c2, 10);

        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "滚动动态"));
        itemsHost = Ui.col(ctx);
        c3.addView(itemsHost);
        TextView add = Ui.btn(ctx, "添加一条", false);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> cur = currentItems();
                cur.add("");
                fillItems(cur);
            }
        });
        Ui.add(c3, add, 8);
        Ui.add(body, c3, 10);

        LinearLayout c4 = Ui.card(ctx);
        c4.addView(Ui.section(ctx, "时间与农历显示"));
        swClock = Ui.switchBtn(ctx);
        swClock.setText("显示 时:分:秒 / 日期 / 星期 / 农历");
        swClock.setTextColor(Theme.TEXT);
        swClock.setTextSize(13f);
        swClock.setChecked(true);
        c4.addView(swClock);
        c4.addView(Ui.sub(ctx, "开启后公告栏叠加实时时钟（时:分:秒）、日期、星期与农历/阴历，由 App 端实时计算显示。"));
        Ui.add(body, c4, 10);

        LinearLayout c5 = Ui.card(ctx);
        c5.addView(Ui.section(ctx, "跑马灯特效"));
        swMarquee = Ui.switchBtn(ctx);
        swMarquee.setText("开启跑马灯文字特效");
        swMarquee.setTextColor(Theme.TEXT);
        swMarquee.setTextSize(13f);
        swMarquee.setChecked(true);
        c5.addView(swMarquee);
        c5.addView(Ui.sub(ctx, "开启后动态与问候语以跑马灯（横向循环滚动）呈现；关闭则静态展示。"));
        Ui.add(body, c5, 10);

        LinearLayout c6 = Ui.card(ctx);
        c6.addView(Ui.section(ctx, "24 小时时段问候（轮播）"));
        c6.addView(Ui.sub(ctx, "按时间区间全天轮播问候语：App 端按当前时间匹配第一条生效时段展示；未命中时段时回退到下方滚动动态。"));
        scheduleHost = Ui.col(ctx);
        c6.addView(scheduleHost);
        LinearLayout r6 = Ui.row(ctx);
        TextView addS = Ui.btn(ctx, "添加时段", false);
        addS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addScheduleRow("", "", "");
            }
        });
        r6.addView(addS);
        TextView defS = Ui.btn(ctx, "填入默认时段", false);
        defS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fillSchedule(defaultSchedule());
            }
        });
        r6.addView(defS, mar());
        Ui.add(c6, r6, 8);
        Ui.add(body, c6, 10);

        TextView pub = Ui.btn(ctx, "发布公告", true);
        pub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmPublish();
            }
        });
        Ui.add(body, pub, 12);

        status = Ui.tv(ctx, "正在读取线上公告…", 12f, Theme.SUB, false);
        Ui.add(body, status, 10);
        load();
    }

    private void load() {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                return Repo.readText(ctx, Repo.P_NOTICE);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "读取失败：" + err.getMessage());
                    return;
                }
                boolean enabled = true;
                String welcome = "";
                List<String> items = new ArrayList<String>();
                boolean clock = true;
                boolean marquee = true;
                List<JSONObject> schedule = new ArrayList<JSONObject>();
                try {
                    if (result != null && result.trim().length() > 0) {
                        JSONObject o = new JSONObject(result);
                        enabled = o.optBoolean("enabled", true);
                        welcome = o.optString("welcome", "");
                        clock = o.optBoolean("clock", true);
                        marquee = o.optBoolean("marquee", true);
                        JSONArray arr = o.optJSONArray("items");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) items.add(arr.optString(i, ""));
                        }
                        JSONArray sch = o.optJSONArray("schedule");
                        if (sch != null) {
                            for (int i = 0; i < sch.length(); i++) {
                                JSONObject s = sch.optJSONObject(i);
                                if (s != null) schedule.add(s);
                            }
                        }
                    }
                } catch (Throwable ignored) {
                }
                if (result == null) {
                    act.setText(status, "线上暂无公告文件，发布后将自动创建");
                } else {
                    act.setText(status, "已载入线上公告 · " + Repo.today());
                }
                swEnabled.setChecked(enabled);
                inWelcome.setText(welcome);
                swClock.setChecked(clock);
                swMarquee.setChecked(marquee);
                fillItems(items);
                fillSchedule(schedule.isEmpty() ? defaultSchedule() : schedule);
            }
        });
    }

    private void fillItems(List<String> items) {
        itemsHost.removeAllViews();
        itemInputs.clear();
        for (int i = 0; i < items.size(); i++) {
            final EditText e = Ui.input(ctx, "第 " + (i + 1) + " 条动态", false, items.get(i));
            itemInputs.add(e);
            LinearLayout r = Ui.row(ctx);
            r.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView del = Ui.btn(ctx, "删除", false);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dp.leftMargin = Ui.dp(ctx, 8);
            del.setLayoutParams(dp);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    List<String> cur = currentItems();
                    int idx = itemInputs.indexOf(e);
                    if (idx >= 0 && idx < cur.size()) cur.remove(idx);
                    fillItems(cur);
                }
            });
            r.addView(del);
            Ui.add(itemsHost, r, 6);
        }
        if (items.isEmpty()) {
            itemsHost.addView(Ui.sub(ctx, "暂无动态条目，点「添加一条」新增"));
        }
    }

    // ---------------- 时段问候 ----------------

    private static List<JSONObject> defaultSchedule() {
        List<JSONObject> out = new ArrayList<JSONObject>();
        for (String[] row : DEF_SCHEDULE) {
            try {
                JSONObject o = new JSONObject();
                o.put("start", row[0]);
                o.put("end", row[1]);
                o.put("text", row[2]);
                out.add(o);
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    /** 按线上时段渲染全部行；rows 为空时显示引导。 */
    private void fillSchedule(List<JSONObject> rows) {
        scheduleHost.removeAllViews();
        scheduleRows.clear();
        for (JSONObject r : rows) {
            addScheduleRow(r.optString("start", ""), r.optString("end", ""), r.optString("text", ""));
        }
        if (rows.isEmpty()) {
            scheduleHost.addView(Ui.sub(ctx, "暂无时段，点「添加时段」新增；点「填入默认时段」可一键铺满 24 小时"));
        }
    }

    private void addScheduleRow(final String start, final String end, final String text) {
        final ScheduleRow row = new ScheduleRow();
        row.inStart = Ui.input(ctx, "开始 如 08:00", false, start);
        row.inEnd = Ui.input(ctx, "结束 如 10:59", false, end);
        row.inText = Ui.input(ctx, "该时段问候语", false, text);
        scheduleRows.add(row);
        LinearLayout card = Ui.card(ctx);
        LinearLayout r1 = Ui.row(ctx);
        r1.addView(row.inStart, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ep.leftMargin = Ui.dp(ctx, 6);
        r1.addView(row.inEnd, ep);
        card.addView(r1);
        LinearLayout r2 = Ui.row(ctx);
        r2.addView(row.inText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView del = Ui.btn(ctx, "删除", false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dp.leftMargin = Ui.dp(ctx, 8);
        del.setLayoutParams(dp);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scheduleRows.remove(row);
                fillSchedule(currentSchedule());
            }
        });
        r2.addView(del);
        card.addView(r2);
        Ui.add(scheduleHost, card, 8);
    }

    /** 收集已填完整的时段（跳过空行）。 */
    private List<JSONObject> currentSchedule() {
        List<JSONObject> out = new ArrayList<JSONObject>();
        for (ScheduleRow r : scheduleRows) {
            String st = r.inStart.getText().toString().trim();
            String en = r.inEnd.getText().toString().trim();
            String tx = r.inText.getText().toString().trim();
            if (st.length() == 0 || en.length() == 0 || tx.length() == 0) continue;
            try {
                JSONObject o = new JSONObject();
                o.put("start", st);
                o.put("end", en);
                o.put("text", tx);
                out.add(o);
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    private static boolean timeOk(String t) {
        return t != null && t.matches("^([01]\\d|2[0-3]):[0-5]\\d$");
    }

    private LinearLayout.LayoutParams mar() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Ui.dp(ctx, 8);
        return lp;
    }

    private List<String> currentItems() {
        List<String> out = new ArrayList<String>();
        for (EditText e : itemInputs) out.add(e.getText().toString().trim());
        return out;
    }

    private void confirmPublish() {
        final boolean enabled = swEnabled.isChecked();
        final String welcome = inWelcome.getText().toString().trim();
        final List<String> items = new ArrayList<String>();
        for (String s : currentItems()) {
            if (s.length() > 0) items.add(s);
        }
        final List<JSONObject> schedule = currentSchedule();
        for (JSONObject s : schedule) {
            if (!timeOk(s.optString("start", "")) || !timeOk(s.optString("end", ""))) {
                info("时段时间格式应为 HH:mm（如 08:00），请检查后重试");
                return;
            }
        }
        if (welcome.length() == 0 && items.isEmpty() && schedule.isEmpty()) {
            info("欢迎语、动态与时段问候不能同时为空");
            return;
        }
        String preview = "启用：" + (enabled ? "是" : "否")
                + "\n动态条数：" + items.size()
                + "\n时钟/农历：" + (swClock.isChecked() ? "开" : "关")
                + "\n跑马灯特效：" + (swMarquee.isChecked() ? "开" : "关")
                + "\n时段问候：" + schedule.size() + " 段"
                + "\n欢迎语：" + (welcome.length() > 40 ? welcome.substring(0, 40) + "…" : welcome);
        new AlertDialog.Builder(act)
                .setTitle("确认发布公告")
                .setMessage(preview + "\n\n发布后约 1 分钟内在 App 首页公告栏生效。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认发布", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        doPublish(enabled, welcome, items, schedule);
                    }
                })
                .show();
    }

    private void doPublish(final boolean enabled, final String welcome, final List<String> items,
                           final List<JSONObject> schedule) {
        act.setText(status, "正在发布公告…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject o = new JSONObject();
                o.put("enabled", enabled);
                o.put("welcome", welcome);
                o.put("clock", swClock.isChecked());
                o.put("marquee", swMarquee.isChecked());
                JSONArray arr = new JSONArray();
                for (String s : items) arr.put(s);
                o.put("items", arr);
                JSONArray sch = new JSONArray();
                for (JSONObject s : schedule) sch.put(s);
                o.put("schedule", sch);
                Repo.publishNotice(ctx, o);
                return "公告已发布（" + items.size() + " 条动态 · " + schedule.size() + " 段问候）";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + err.getMessage());
                    log("公告发布失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result + " · " + Repo.today());
                log("公告已发布（" + items.size() + " 条动态 · " + schedule.size() + " 段问候）");
                act.badge("公告已更新", Theme.OK);
            }
        });
    }
}
