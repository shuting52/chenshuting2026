package com.chenshuting.console;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;

import org.json.JSONObject;

/** 弹窗皮肤配置中心：远端 data/dialogs.json 的读写、默认值与渲染参数解析。
 *  场景键：common（本体所有弹窗）/ update（更新弹窗）/ mine（我的弹窗）。置顶弹窗（top）功能已按需求移除。 */
public final class Skin {

    public static final String PATH = "data/dialogs.json";

    public static final String[] SCENES = {"common", "update", "mine"};
    public static final String[] SCENE_LABEL = {"本体通用弹窗", "更新弹窗", "我的页弹窗"};
    public static final String[] SCENE_DESC = {
            "首页、分类、提示词、Skill、软件等页面点的普通提示/确认弹窗",
            "版本更新弹窗（强制型，无右上角关闭）",
            "「我的」页面内各条目点击后的弹窗"};
    /** 场景示例：预览时的标题/正文，便于所见即所得。 */
    public static final String[] SCENE_SAMPLE_TITLE = {"操作成功", "发现新版本 v1.6.4", "关于淑婷工具箱"};
    public static final String[] SCENE_SAMPLE_BODY = {
            "这是一条演示文案，用来核对弹窗配色、圆角与按钮样式。",
            "更新内容：\n· 弹窗样式支持云端换肤\n· 图标支持上传与自动识别",
            "作者：陈淑婷 · 版本 1.6.4"};

    public static final String[] FIELDS = {
            "widthRatio", "radiusDp", "padDp", "bgStyle", "bgColor", "strokeWidthDp", "strokeColor",
            "titleColor", "titleSizeSp", "bodyColor", "bodySizeSp", "okText",
            "btnPrimaryColor", "btnPrimaryTextColor", "dragon", "aurora", "decor",
            "maxHeightRatio", "position", "dimAmount", "enterAnim", "css"};

    /** 默认皮肤（与本体内置视觉一致）。 */
    public static final String DEFAULTS_JSON =
            "{\"common\":{\"widthRatio\":0.90,\"radiusDp\":28,\"padDp\":20,\"bgStyle\":\"glass\","
                    + "\"bgColor\":\"#1A0F14\",\"strokeWidthDp\":1.4,\"strokeColor\":\"#66E0A85A\","
                    + "\"titleColor\":\"#F5EDE3\",\"titleSizeSp\":17,\"bodyColor\":\"#A6978C\",\"bodySizeSp\":12.5,"
                    + "\"okText\":\"我知道了\",\"btnPrimaryColor\":\"#F5C044\",\"btnPrimaryTextColor\":\"#3A2405\","
                    + "\"dragon\":true,\"aurora\":true,\"decor\":true,\"maxHeightRatio\":0.60,"
                    + "\"position\":\"center\",\"dimAmount\":0.5,\"enterAnim\":\"overshoot\"},"
                    + "\"update\":{\"widthRatio\":0.92,\"radiusDp\":30,\"padDp\":22,\"bgStyle\":\"solid\","
                    + "\"bgColor\":\"#1A0B12\",\"strokeWidthDp\":1.6,\"strokeColor\":\"#80E0A85A\","
                    + "\"titleColor\":\"#FFF3D6\",\"titleSizeSp\":18,\"bodyColor\":\"#C9B6A6\",\"bodySizeSp\":12.5,"
                    + "\"okText\":\"立即更新\",\"btnPrimaryColor\":\"#F5C044\",\"btnPrimaryTextColor\":\"#3A2405\","
                    + "\"dragon\":true,\"aurora\":true,\"decor\":true,\"maxHeightRatio\":0.62,"
                    + "\"position\":\"center\",\"dimAmount\":0.62,\"enterAnim\":\"overshoot\"},"
                    + "\"mine\":{\"widthRatio\":0.88,\"radiusDp\":24,\"padDp\":18,\"bgStyle\":\"glass\","
                    + "\"bgColor\":\"#1A0F14\",\"strokeWidthDp\":1.2,\"strokeColor\":\"#4DE0A85A\","
                    + "\"titleColor\":\"#F5EDE3\",\"titleSizeSp\":16,\"bodyColor\":\"#A6978C\",\"bodySizeSp\":12,"
                    + "\"okText\":\"关闭\",\"btnPrimaryColor\":\"#F5C044\",\"btnPrimaryTextColor\":\"#3A2405\","
                    + "\"dragon\":true,\"aurora\":false,\"decor\":false,\"maxHeightRatio\":0.66,"
                    + "\"position\":\"center\",\"dimAmount\":0.45,\"enterAnim\":\"fade\"}}";

    private Skin() {
    }

    /** 默认场景配置。 */
    public static JSONObject defaults() {
        try {
            return new JSONObject(DEFAULTS_JSON);
        } catch (Throwable t) {
            return new JSONObject();
        }
    }

    /** 读取远端皮肤；远端缺失或字段不全时用默认值回填，保证四个场景齐全。 */
    public static JSONObject load(Context c) throws Exception {
        JSONObject remote = Repo.readJson(c, PATH);
        return merge(remote);
    }

    /** 合并默认值：以远端为准，缺字段补默认。 */
    public static JSONObject merge(JSONObject remote) {
        JSONObject def = defaults();
        JSONObject out = defaults();
        if (remote == null) return out;
        JSONObject rs = remote.optJSONObject("scenes");
        if (rs == null) rs = remote;
        for (String sc : SCENES) {
            JSONObject r = rs.optJSONObject(sc);
            if (r == null) continue;
            JSONObject d = def.optJSONObject(sc);
            JSONObject m = new JSONObject();
            for (String k : FIELDS) {
                try {
                    m.put(k, r.has(k) ? r.get(k) : d.opt(k));
                } catch (Throwable ignored) {
                }
            }
            try {
                out.put(sc, m);
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    /** 组装待上传的远端结构（带 version 与时间戳）。 */
    public static JSONObject wrap(Context c, JSONObject scenes) throws Exception {
        JSONObject o = new JSONObject();
        o.put("version", 1);
        o.put("updatedAt", Repo.today());
        o.put("scenes", scenes);
        return o;
    }

    // ---------------- 参数读取 ----------------

    public static float f(JSONObject s, String k, float def) {
        try {
            return (float) s.optDouble(k, def);
        } catch (Throwable t) {
            return def;
        }
    }

    public static int i(JSONObject s, String k, int def) {
        try {
            return s.optInt(k, def);
        } catch (Throwable t) {
            return def;
        }
    }

    public static String str(JSONObject s, String k, String def) {
        String v = s == null ? null : s.optString(k, def);
        return v == null || v.length() == 0 ? def : v;
    }

    public static boolean bool(JSONObject s, String k, boolean def) {
        return s == null ? def : s.optBoolean(k, def);
    }

    /** 颜色解析（支持 #RRGGBB / #AARRGGBB）。 */
    public static int color(String s, int def) {
        if (s == null || s.length() == 0) return def;
        try {
            String t = s.trim();
            if (!t.startsWith("#")) t = "#" + t;
            long v = Long.parseLong(t.substring(1), 16);
            if (t.length() == 7) v |= 0xFF000000L;
            return (int) v;
        } catch (Throwable ex) {
            return def;
        }
    }

    /** 卡片外观：glass 用半透明磨砂色，solid 用实色；带圆角与描边。 */
    public static GradientDrawable cardBg(Context c, JSONObject s) {
        int radius = i(s, "radiusDp", 28);
        String style = str(s, "bgStyle", "glass");
        int fill;
        if ("solid".equals(style)) {
            fill = color(str(s, "bgColor", "#1A0F14"), 0xFF1A0F14);
        } else {
            int base = color(str(s, "bgColor", "#1A0F14"), 0xFF1A0F14);
            fill = (base & 0x00FFFFFF) | 0xB3000000;
        }
        GradientDrawable g = Ui.bg(c, fill, radius, 0, 0);
        float stroke = f(s, "strokeWidthDp", 1.4f);
        if (stroke > 0f) {
            g.setStroke(Math.max(1, Ui.dp(c, stroke)), color(str(s, "strokeColor", "#66E0A85A"), 0x66E0A85A));
        }
        return g;
    }

    /** 主按钮背景（纯色/渐变二选一，预览与本体一致）。 */
    public static GradientDrawable primaryBg(Context c, JSONObject s, int radiusDp) {
        int col = color(str(s, "btnPrimaryColor", "#F5C044"), 0xFFF5C044);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(Ui.dp(c, radiusDp));
        g.setColor(col);
        return g;
    }
}
