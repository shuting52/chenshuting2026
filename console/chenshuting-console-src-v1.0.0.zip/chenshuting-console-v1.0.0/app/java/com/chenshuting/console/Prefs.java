package com.chenshuting.console;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** 控制台本地配置与操作日志。 */
public final class Prefs {

    public static final String DEF_REPO = "shuting52/chenshuting2026";
    public static final String DEF_BRANCH = "main";
    public static final String DEF_TOKEN = "__TOKEN__";

    private Prefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("console", Context.MODE_PRIVATE);
    }

    public static String repo(Context c) {
        String v = sp(c).getString("repo", DEF_REPO);
        return v == null || v.trim().length() == 0 ? DEF_REPO : v.trim();
    }

    public static void setRepo(Context c, String v) {
        sp(c).edit().putString("repo", v == null ? "" : v.trim()).apply();
    }

    public static String branch(Context c) {
        String v = sp(c).getString("branch", DEF_BRANCH);
        return v == null || v.trim().length() == 0 ? DEF_BRANCH : v.trim();
    }

    public static void setBranch(Context c, String v) {
        sp(c).edit().putString("branch", v == null ? "" : v.trim()).apply();
    }

    public static String token(Context c) {
        String v = sp(c).getString("token", DEF_TOKEN);
        return v == null ? "" : v.trim();
    }

    public static void setToken(Context c, String v) {
        sp(c).edit().putString("token", v == null ? "" : v.trim()).apply();
    }

    public static boolean autoDeleteOld(Context c) {
        return sp(c).getBoolean("del_old", true);
    }

    public static void setAutoDeleteOld(Context c, boolean v) {
        sp(c).edit().putBoolean("del_old", v).apply();
    }

    public static boolean verbose(Context c) {
        return sp(c).getBoolean("verbose", true);
    }

    public static void setVerbose(Context c, boolean v) {
        sp(c).edit().putBoolean("verbose", v).apply();
    }

    /** Token 脱敏展示：仅暴露首尾各 4 位。 */
    public static String mask(String t) {
        if (t == null || t.length() < 12) return "未配置";
        return t.substring(0, 4) + "****" + t.substring(t.length() - 4);
    }

    private static String now() {
        return new SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(new Date());
    }

    /** 追加一条操作日志（最多保留 80 条）。 */
    public static void log(Context c, String line) {
        try {
            String old = sp(c).getString("log", "");
            String entry = "[" + now() + "] " + line;
            String merged = old == null || old.length() == 0 ? entry : entry + "\n" + old;
            String[] arr = merged.split("\n");
            if (arr.length > 80) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < 80; i++) {
                    if (i > 0) sb.append('\n');
                    sb.append(arr[i]);
                }
                merged = sb.toString();
            }
            sp(c).edit().putString("log", merged).apply();
        } catch (Throwable ignored) {
        }
    }

    public static String logs(Context c) {
        String v = sp(c).getString("log", "");
        return v == null ? "" : v;
    }

    public static void clearLogs(Context c) {
        sp(c).edit().putString("log", "").apply();
    }
}
