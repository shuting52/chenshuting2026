package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;

/** 设置：仓库信息、Token、连接自检、清单重建、日志。 */
public class PageSettings extends Page {

    private EditText inRepo;
    private EditText inBranch;
    private EditText inToken;
    private Switch swRaw;
    private TextView status;

    public PageSettings(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "设置"));
        body.addView(Ui.sub(ctx, "控制台通过 GitHub Contents API 直接读写仓库，改动提交后由 App 端自动拉取。"));

        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "仓库"));
        c1.addView(Ui.sub(ctx, "仓库（owner/repo）"));
        inRepo = Ui.input(ctx, Repo.DEF_REPO, false, Repo.repo(ctx));
        Ui.add(c1, inRepo, 4);
        c1.addView(Ui.sub(ctx, "分支"));
        inBranch = Ui.input(ctx, Repo.DEF_BRANCH, false, Repo.branch(ctx));
        Ui.add(c1, inBranch, 4);
        Ui.add(body, c1, 12);

        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "访问令牌"));
        c2.addView(Ui.sub(ctx, "GitHub Personal Access Token（需 repo 权限，仅保存在本机）"));
        inToken = Ui.input(ctx, "ghp_ 或 github_pat_ ...", false, Repo.token(ctx));
        inToken.setHint("ghp_ 或 github_pat_ ...");
        Ui.add(c2, inToken, 4);
        c2.addView(Ui.sub(ctx, "当前：" + Prefs.mask(Repo.token(ctx))));
        Ui.add(body, c2, 12);

        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "自检与维护"));
        TextView save = Ui.btn(ctx, "保存并测试连接", true);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAndTest();
            }
        });
        Ui.add(c3, save, 8);
        TextView rebuild = Ui.btn(ctx, "按仓库现有 data/ 文件重建内容清单", false);
        rebuild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmRebuild();
            }
        });
        Ui.add(c3, rebuild, 8);
        Ui.add(c3, Ui.sub(ctx, "清单 manifest.json 决定 App 端下载哪些内容文件；本地发布已自动维护，此按钮用于修复不一致。"), 6);

        swRaw = new Switch(ctx);
        swRaw.setText("显示接口原始错误信息");
        swRaw.setTextColor(Theme.TEXT);
        swRaw.setTextSize(13f);
        swRaw.setChecked(Prefs.verbose(ctx));
        Ui.add(c3, swRaw, 10);
        Ui.add(body, c3, 12);

        LinearLayout c4 = Ui.card(ctx);
        c4.addView(Ui.section(ctx, "操作日志"));
        c4.addView(Ui.tv(ctx, orNone(Prefs.logs(ctx)), 12f, Theme.SUB, false));
        TextView clr = Ui.btn(ctx, "清空日志", false);
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Prefs.clearLogs(ctx);
                rebuild();
                Ui.toast(ctx, "日志已清空");
            }
        });
        Ui.add(c4, clr, 10);
        Ui.add(body, c4, 12);

        status = Ui.tv(ctx, "版本 " + Repo.APP_VER + " · " + Repo.today(), 12f, Theme.SUB, false);
        Ui.add(body, status, 10);
    }

    private static String orNone(String s) {
        return s == null || s.length() == 0 ? "暂无记录" : (s.length() > 900 ? s.substring(0, 900) + "…" : s);
    }

    private static String head(String s) {
        if (s == null) return "";
        String t = s.replace('\n', ' ').trim();
        return t.length() > 120 ? t.substring(0, 120) : t;
    }

    private void saveAndTest() {
        Prefs.setRepo(ctx, inRepo.getText().toString().trim());
        Prefs.setBranch(ctx, inBranch.getText().toString().trim());
        Prefs.setToken(ctx, inToken.getText().toString().trim());
        Prefs.setVerbose(ctx, swRaw.isChecked());
        act.setText(status, "正在测试连接…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                Gh.R u = Gh.user(Repo.token(ctx));
                if (!u.ok()) return "账号校验失败：HTTP " + u.code + " " + head(u.body);
                JSONObject j = u.json();
                String login = j == null ? "" : j.optString("login", "");
                Gh.R repo = Repo.repoCheck(ctx);
                if (!repo.ok()) return "仓库不可读（" + Repo.repo(ctx) + "）：HTTP " + repo.code + " " + head(repo.body);
                List<String> apks = Repo.rootApks(ctx);
                return "连接正常：账号 " + login + "，仓库可读写，根目录 APK " + apks.size() + " 个";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "测试失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result);
                log("自检：" + result);
                rebuild();
            }
        });
    }

    private void confirmRebuild() {
        new AlertDialog.Builder(act)
                .setTitle("确认重建清单")
                .setMessage("将按仓库 data/ 目录下现有内容文件重新生成 manifest.json，"
                        + "并更新清单版本号，触发 App 端重新同步。\n\n发布流程之外的一般情况下无需手动执行。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认重建", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        act.setText(status, "正在重建内容清单…");
                        Ui.run(act, new Ui.Job() {
                            @Override
                            public String run() throws Exception {
                                                        return Repo.rebuildManifest(ctx);
                            }
                        }, new Ui.Done() {
                            @Override
                            public void done(String result, Throwable err) {
                                if (err != null) {
                                    act.setText(status, "重建失败：" + err.getMessage());
                                    return;
                                }
                                act.setText(status, result + " · " + Repo.today());
                                log("清单重建：" + result);
                                act.badge("清单已重建", Theme.OK);
                            }
                        });
                    }
                })
                .show();
    }
}
