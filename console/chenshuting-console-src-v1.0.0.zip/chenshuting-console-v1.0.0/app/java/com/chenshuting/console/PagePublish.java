package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.List;

/** 版本发布：上传安装包 → 写 version.json → 清理旧包 → 复验。 */
public class PagePublish extends Page {

    private EditText inCode;
    private EditText inName;
    private EditText inLog;
    private TextView apkInfo;
    private TextView status;
    private Switch swDel;

    private byte[] apkData;
    private String apkName;
    private int onlineCode = -1;
    private String onlineName = "";

    public PagePublish(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "版本发布"));
        body.addView(Ui.sub(ctx, "流程：上传 APK → 写入 version.json → 清理旧包 → 复验线上数据"));
        Ui.add(body, Ui.sub(ctx, "App 端下次启动/回前台时读到新版本号即弹出更新提示。"), 2);

        // 版本信息
        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "版本信息"));
        c1.addView(Ui.sub(ctx, "versionCode（整数，必须大于线上）"));
        inCode = Ui.input(ctx, "如 23", false, "");
        inCode.setInputType(InputType.TYPE_CLASS_NUMBER);
        Ui.add(c1, inCode, 4);
        c1.addView(Ui.sub(ctx, "versionName（如 1.6.4）"));
        inName = Ui.input(ctx, "如 1.6.4", false, "");
        Ui.add(c1, inName, 4);
        TextView auto = Ui.btn(ctx, "按线上版本自动 +1", false);
        auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onlineCode <= 0) {
                    info("尚未读取到线上版本，请先点右上「总览」刷新");
                    return;
                }
                inCode.setText(String.valueOf(onlineCode + 1));
                inName.setText(bumpName(onlineName));
            }
        });
        Ui.add(c1, auto, 8);
        c1.addView(Ui.sub(ctx, "更新说明（弹窗内展示，支持换行）"));
        inLog = Ui.input(ctx, "更新内容:\n· 新增…\n· 修复…", true, "");
        Ui.add(c1, inLog, 4);
        Ui.add(body, c1, 12);

        // 安装包
        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "安装包"));
        TextView pick = Ui.btn(ctx, "选择本地 APK 文件", false);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                act.pickFile("application/vnd.android.package-archive", "chenshuting.apk", new MainActivity.PickCb() {
                    @Override
                    public void onPicked(String name, byte[] data) {
                        apkName = name;
                        apkData = data;
                        act.setText(apkInfo, "已选择：" + name + "（" + size(data.length) + "）");
                    }

                    @Override
                    public void onFailed(String reason) {
                        info(reason);
                    }
                });
            }
        });
        Ui.add(c2, pick, 6);
        apkInfo = Ui.sub(ctx, "未选择文件（将上传到仓库根目录，命名为 chenshuting-v版本名.apk）");
        Ui.add(c2, apkInfo, 6);
        Ui.add(body, c2, 10);

        // 选项
        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "发布选项"));
        swDel = new Switch(ctx);
        swDel.setText("发布后清理历史 chenshuting-v*.apk 旧包");
        swDel.setTextColor(Theme.TEXT);
        swDel.setTextSize(13f);
        swDel.setChecked(Prefs.autoDeleteOld(ctx));
        c3.addView(swDel);
        c3.addView(Ui.sub(ctx, "App 端固定从 version.json 的 apkUrl 取包，旧包可安全清理。"));
        Ui.add(body, c3, 10);

        TextView go = Ui.btn(ctx, "一键发布新版本", true);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmPublish();
            }
        });
        Ui.add(body, go, 12);

        status = Ui.tv(ctx, "待发布", 12f, Theme.SUB, false);
        Ui.add(body, status, 10);
        loadOnline();
    }

    private void loadOnline() {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject v = Repo.version(ctx);
                if (v != null) {
                    onlineCode = v.optInt("versionCode", -1);
                    onlineName = v.optString("versionName", "");
                }
                return null;
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (onlineCode > 0) {
                    act.setText(status, "线上版本：" + onlineName + "（" + onlineCode + "）");
                    if (inCode.getText().toString().trim().length() == 0) {
                        inCode.setText(String.valueOf(onlineCode + 1));
                        inName.setText(bumpName(onlineName));
                    }
                } else if (err != null) {
                    act.setText(status, "读取线上版本失败：" + err.getMessage());
                }
            }
        });
    }

    private void confirmPublish() {
        final int code;
        final String name = inName.getText().toString().trim();
        final String log = inLog.getText().toString().trim();
        try {
            code = Integer.parseInt(inCode.getText().toString().trim());
        } catch (Throwable t) {
            info("versionCode 必须是整数");
            return;
        }
        if (code <= 0) {
            info("versionCode 必须大于 0");
            return;
        }
        if (name.length() == 0) {
            info("请填写 versionName");
            return;
        }
        if (log.length() == 0) {
            info("请填写更新说明");
            return;
        }
        final boolean delOld = swDel.isChecked();
        String apkPath = apkPathOf(name);
        String msg = "即将执行发布：\n\n"
                + "· 上传安装包：" + (apkData == null ? "（未选择，跳过上传）" : apkPath + "，" + size(apkData.length))
                + "\n· 覆盖 version.json：" + code + " / " + name
                + "\n· 清理旧安装包：" + (delOld ? "是" : "否")
                + "\n\nApp 端将向所有在线用户推送该版本更新弹窗。";
        new AlertDialog.Builder(act)
                .setTitle("确认发布")
                .setMessage(msg)
                .setNegativeButton("取消", null)
                .setPositiveButton("确认发布", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        doPublish(code, name, log, delOld);
                    }
                })
                .show();
    }

    private void doPublish(final int code, final String name, final String log, final boolean delOld) {
        Prefs.setAutoDeleteOld(ctx, delOld);
        final String apkPath = apkPathOf(name);
        final byte[] data = apkData;
        act.setText(status, "开始发布…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                StringBuilder sb = new StringBuilder();
                if (data != null && data.length > 0) {
                    act.setText(status, "① 上传安装包（" + size(data.length) + "，约需 10-60 秒）…");
                    Repo.writeBytes(ctx, apkPath, data, "release: 上传 v" + name + " 安装包");
                    sb.append("① 安装包已上传：").append(apkPath).append(" (").append(size(data.length)).append(")\n");
                } else {
                    sb.append("① 未提供安装包，跳过上传\n");
                }
                act.setText(status, "② 写入 version.json…");
                Repo.publishVersion(ctx, code, name, log, apkPath);
                sb.append("② version.json 已更新：").append(code).append(" / ").append(name).append("\n");

                if (delOld) {
                    act.setText(status, "③ 清理旧安装包…");
                    List<String> apks = Repo.rootApks(ctx);
                    int n = 0;
                    for (String a : apks) {
                        if (a.equals(apkPath)) continue;
                        if (!a.startsWith("chenshuting-v") || !a.endsWith(".apk")) continue;
                        Repo.remove(ctx, a, "chore: 清理旧包 " + a);
                        n++;
                    }
                    sb.append("③ 已清理旧包 ").append(n).append(" 个\n");
                } else {
                    sb.append("③ 保留旧包\n");
                }

                act.setText(status, "④ 复验线上数据…");
                JSONObject v = Repo.version(ctx);
                boolean okCode = v != null && v.optInt("versionCode", 0) == code;
                boolean okName = v != null && name.equals(v.optString("versionName", ""));
                String url = v == null ? "" : v.optString("apkUrl", "");
                boolean apkThere = false;
                for (String a : Repo.rootApks(ctx)) {
                    if (a.equals(apkPath)) apkThere = true;
                }
                sb.append("④ 复验：版本号").append(okCode ? "√" : "×")
                        .append(" 版本名").append(okName ? "√" : "×")
                        .append(" 安装包").append(apkThere ? "√" : (data == null ? "（未上传）" : "×")).append("\n");
                sb.append("直链：").append(url);
                return sb.toString();
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + err.getMessage());
                    log("发布失败 v" + name + "：" + err.getMessage());
                    act.badge("发布失败", Theme.ERR);
                    return;
                }
                act.setText(status, "发布完成\n" + result);
                log("发布 v" + name + " (" + code + ") 完成");
                act.badge("已发布 v" + name, Theme.OK);
                apkData = null;
                apkName = null;
                act.setText(apkInfo, "已发布，安装包已上传至仓库");
            }
        });
    }

    private String apkPathOf(String versionName) {
        return "chenshuting-v" + versionName + ".apk";
    }

    private static String bumpName(String name) {
        if (name == null || name.trim().length() == 0) return "";
        String[] p = name.trim().split("\\.");
        try {
            int last = Integer.parseInt(p[p.length - 1]);
            p[p.length - 1] = String.valueOf(last + 1);
        } catch (Throwable t) {
            return name + ".1";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < p.length; i++) {
            if (i > 0) sb.append('.');
            sb.append(p[i]);
        }
        return sb.toString();
    }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return new DecimalFormat("0.0").format(b / 1024.0) + " KB";
        return new DecimalFormat("0.00").format(b / 1048576.0) + " MB";
    }
}
