package com.chenshuting.console;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/** 总览：连接状态、线上版本、内容清单、公告与操作日志。 */
public class PageOverview extends Page {

    private LinearLayout host;
    private TextView info;
    private Snap snap;

    public PageOverview(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "总览"));
        info = Ui.sub(ctx, "正在读取仓库状态…");
        Ui.add(body, info, 4);

        TextView refresh = Ui.btn(ctx, "刷新全部", true);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshAll();
            }
        });
        Ui.add(body, refresh, 10);

        host = Ui.col(ctx);
        Ui.add(body, host, 10);
        refreshAll();
    }

    private void refreshAll() {
        act.setText(info, "正在读取仓库状态…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                Snap s = new Snap();
                Gh.R u = Gh.user(Repo.token(ctx));
                if (u.ok()) {
                    JSONObject j = u.json();
                    s.user = j == null ? "已授权" : j.optString("login", "已授权");
                } else {
                    s.userErr = "HTTP " + u.code + " " + shortOf(u.body);
                }
                s.ver = Repo.version(ctx);
                s.man = Repo.manifest(ctx);
                s.notice = Repo.readJson(ctx, Repo.P_NOTICE);
                s.apks = Repo.rootApks(ctx);
                s.log = Prefs.logs(ctx);
                snap = s;
                return "ok";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                render(err);
            }
        });
    }

    private static String shortOf(String s) {
        if (s == null) return "";
        String t = s.replace('\n', ' ').trim();
        return t.length() > 120 ? t.substring(0, 120) : t;
    }

    private static class Snap {
        String user;
        String userErr;
        JSONObject ver;
        JSONObject man;
        JSONObject notice;
        List<String> apks = new ArrayList<String>();
        String log;
    }

    private void render(Throwable err) {
        if (err != null) {
            act.setText(info, "刷新失败：" + err.getMessage());
            act.badge("连接异常", Theme.ERR);
            return;
        }
        act.setText(info, "已刷新 · " + Repo.today());
        act.badge("已连接", Theme.OK);
        Snap s = snap;
        if (s == null) return;
        host.removeAllViews();

        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "仓库连接"));
        c1.addView(Ui.kv(ctx, "仓库", Repo.repo(ctx)));
        c1.addView(Ui.kv(ctx, "分支", Repo.branch(ctx)));
        c1.addView(Ui.kv(ctx, "Token", Prefs.mask(Repo.token(ctx))));
        c1.addView(Ui.kv(ctx, "账号", s.user != null ? s.user : "未校验"));
        if (s.userErr != null) c1.addView(Ui.kv(ctx, "异常", s.userErr));
        Ui.add(host, c1, 0);

        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "线上版本（更新弹窗数据源）"));
        if (s.ver == null) {
            c2.addView(Ui.sub(ctx, "仓库尚未创建 version.json，发布一次后自动生成"));
        } else {
            c2.addView(Ui.kv(ctx, "版本号", s.ver.optInt("versionCode", 0) + " / " + s.ver.optString("versionName", "")));
            String cl = s.ver.optString("changelog", "").replace('\n', ' ');
            c2.addView(Ui.kv(ctx, "更新说明", cl.length() > 90 ? cl.substring(0, 90) + "…" : cl));
            final String url = s.ver.optString("apkUrl", "");
            TextView link = Ui.tv(ctx, "下载直链（点击打开）", 13f, Theme.GOLD_LIGHT, false);
            link.setPadding(0, Ui.dp(ctx, 6), 0, 0);
            link.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    if (url.length() > 0) act.openUrl(url);
                }
            });
            c2.addView(link);
        }
        Ui.add(host, c2, 10);

        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "仓库内安装包"));
        if (s.apks.isEmpty()) {
            c3.addView(Ui.sub(ctx, "仓库根目录暂无 APK"));
        } else {
            for (String a : s.apks) c3.addView(Ui.kv(ctx, "•", a));
        }
        Ui.add(host, c3, 10);

        LinearLayout c4 = Ui.card(ctx);
        c4.addView(Ui.section(ctx, "内容清单（热更通道）"));
        JSONObject m = s.man;
        JSONArray files = m == null ? null : m.optJSONArray("files");
        int fileCount = files == null ? 0 : files.length();
        c4.addView(Ui.kv(ctx, "清单版本", String.valueOf(m == null ? 0 : m.optInt("version", 0))));
        c4.addView(Ui.kv(ctx, "更新时间", m == null ? "-" : m.optString("updated", "-")));
        c4.addView(Ui.kv(ctx, "登记文件", fileCount + " 个"));
        if (files != null && fileCount > 0) {
            int show = Math.min(fileCount, 12);
            for (int i = 0; i < show; i++) {
                JSONObject f = files.optJSONObject(i);
                if (f == null) continue;
                c4.addView(Ui.kv(ctx, "•", f.optString("path", "") + "  " + size(f.optLong("size", 0))));
            }
            if (fileCount > show) c4.addView(Ui.sub(ctx, "… 其余 " + (fileCount - show) + " 个"));
        } else {
            c4.addView(Ui.sub(ctx, "清单为空：内容文件发布后会自动登记"));
        }
        Ui.add(host, c4, 10);

        LinearLayout c5 = Ui.card(ctx);
        c5.addView(Ui.section(ctx, "公告（独立实时通道 · 约 1 分钟生效）"));
        if (s.notice == null) {
            c5.addView(Ui.sub(ctx, "仓库尚无 data/announcements.json"));
        } else {
            c5.addView(Ui.kv(ctx, "状态", s.notice.optBoolean("enabled", true) ? "开启" : "已关闭"));
            JSONArray items = s.notice.optJSONArray("items");
            c5.addView(Ui.kv(ctx, "动态条数", (items == null ? 0 : items.length()) + " 条"));
            String w = s.notice.optString("welcome", "");
            c5.addView(Ui.kv(ctx, "欢迎语", w.length() > 60 ? w.substring(0, 60) + "…" : w));
        }
        Ui.add(host, c5, 10);

        LinearLayout c6 = Ui.card(ctx);
        c6.addView(Ui.section(ctx, "操作日志"));
        c6.addView(Ui.tv(ctx, s.log == null || s.log.length() == 0 ? "暂无记录" : head(s.log, 1200),
                12f, Theme.SUB, false));
        Ui.add(host, c6, 10);
    }

    private static String head(String s, int n) {
        return s.length() > n ? s.substring(0, n) + "…" : s;
    }

    private static String size(long b) {
        if (b <= 0) return "";
        if (b < 1024) return b + " B";
        if (b < 1048576) return new DecimalFormat("0.0").format(b / 1024.0) + " KB";
        return new DecimalFormat("0.00").format(b / 1048576.0) + " MB";
    }
}
