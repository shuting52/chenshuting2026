package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 内容管理：提示词 / Skill / 软件 / 分类与卡片，发布即热更（写 data/ 并刷新内容清单）。 */
public class PageContent extends Page {

    /** 字段规格：{字段名, 填写说明, 单行 t / 多行 m}。 */
    private static final String[][] F_PROMPT = {
            {"title", "标题", "t"}, {"type", "类型（视频 / 图片）", "t"}, {"tag", "标签（如 可灵 / 即梦）", "t"},
            {"desc", "一句话简述", "t"}, {"cover", "封面路径（如 prompts/p01.png）", "t"},
            {"prompt", "提示词正文", "m"}
    };
    private static final String[][] F_SKILL = {
            {"name", "名称", "t"}, {"ver", "版本", "t"}, {"size", "体积（如 18.7 KB）", "t"},
            {"cat", "分类（如 视频 · 拉片）", "t"}, {"iconName", "图标（emoji）", "t"}, {"badge", "角标（可空）", "t"},
            {"desc", "简介", "t"}, {"url", "外链（可空）", "t"},
            {"zip", "包内路径（如 skills/cat.zip）", "t"}, {"file", "下载文件名（如 猫咪和小主人.zip）", "t"}
    };
    private static final String[][] F_APP = {
            {"name", "软件名", "t"}, {"ver", "版本", "t"}, {"size", "体积", "t"}, {"iconName", "图标（emoji）", "t"},
            {"badge", "角标（可空）", "t"}, {"desc", "简介", "t"}, {"url", "下载直链", "t"}
    };

    private static class Spec {
        String file;
        String key;
        String filePath;
        String[][] fields;
        String idPrefix;
        String assetLabel;
        String assetKind; // "zip" / "image" / null

        Spec(String file, String key, String[][] fields, String idPrefix, String assetLabel, String assetKind) {
            this.file = file;
            this.filePath = "data/" + file;
            this.key = key;
            this.fields = fields;
            this.idPrefix = idPrefix;
            this.assetLabel = assetLabel;
            this.assetKind = assetKind;
        }
    }

    private static final Spec[] SPECS = {
            new Spec("prompts.json", "prompts", F_PROMPT, "p", "上传封面图（图片）", "image"),
            new Spec("skills.json", "skills", F_SKILL, "s", "上传 Skill 压缩包（zip）", "zip"),
            new Spec("apps.json", "apps", F_APP, "a", "上传软件安装包（apk）", "zip")
    };

    private int sub = 0;
    private String currentCat;
    private TextView status;

    public PageContent(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "内容管理"));
        body.addView(Ui.sub(ctx, "发布即热更：写入仓库 data/ 目录并自动刷新内容清单版本，App 端 10 分钟内同步。"));
        Ui.add(body, subTabs(), 10);
        LinearLayout host = Ui.col(ctx);
        Ui.add(body, host, 10);
        status = Ui.tv(ctx, "", 12f, Theme.SUB, false);
        Ui.add(body, status, 10);

        if (sub <= 2) renderList(host, SPECS[sub]);
        else renderCategories(host);
    }

    private LinearLayout subTabs() {
        LinearLayout r = Ui.row(ctx);
        String[] names = {"提示词", "Skill", "软件", "分类与卡片"};
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = Ui.tv(ctx, names[i], 12f, i == sub ? Theme.GOLD_LIGHT : Theme.SUB, i == sub);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, Ui.dp(ctx, 8), 0, Ui.dp(ctx, 8));
            t.setBackground(i == sub ? Ui.bg(ctx, Theme.CARD2, 10, 1, Theme.STROKE) : null);
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sub = k;
                    currentCat = null;
                    rebuild();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = Ui.dp(ctx, 6);
            r.addView(t, lp);
        }
        return r;
    }

    // ---------------- 通用列表 ----------------

    private void renderList(final LinearLayout host, final Spec spec) {
        host.removeAllViews();
        act.setText(status, "正在读取 " + spec.filePath + " …");

        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject o = Repo.readJson(ctx, spec.filePath);
                return o == null ? null : o.toString();
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "读取失败：" + err.getMessage());
                    return;
                }
                final JSONObject root;
                try {
                    root = result == null ? new JSONObject() : new JSONObject(result);
                } catch (Throwable t) {
                    act.setText(status, "数据格式异常");
                    return;
                }
                final JSONArray arr = root.optJSONArray(spec.key) == null ? new JSONArray() : root.optJSONArray(spec.key);
                act.setText(status, "线上 " + spec.filePath + " 共 " + arr.length() + " 条 · " + Repo.today());

                LinearLayout head = Ui.card(ctx);
                head.addView(Ui.kv(ctx, "文件", spec.filePath));
                head.addView(Ui.kv(ctx, "条目", arr.length() + " 条"));
                TextView add = Ui.btn(ctx, "新增一条", true);
                add.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openEditor(spec, root, null, arr.length());
                    }
                });
                Ui.add(head, add, 8);
                Ui.add(host, head, 0);

                for (int i = 0; i < arr.length(); i++) {
                    final int idx = i;
                    final JSONObject it = arr.optJSONObject(i);
                    if (it == null) continue;
                    LinearLayout card = Ui.card(ctx);
                    String title = it.optString("title", it.optString("name", "(未命名)"));
                    LinearLayout r1 = Ui.row(ctx);
                    r1.addView(Ui.tv(ctx, title, 15f, Theme.TEXT, true),
                            new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    String badge = it.optString("badge", "");
                    if (badge.length() > 0) r1.addView(Ui.chip(ctx, badge, Theme.WARN));
                    card.addView(r1);
                    String line2 = it.optString("tag", it.optString("cat", ""));
                    String ver = it.optString("ver", "");
                    if (ver.length() > 0) line2 = (line2.length() > 0 ? line2 + " · " : "") + "v" + ver;
                    String sz = it.optString("size", "");
                    if (sz.length() > 0) line2 = (line2.length() > 0 ? line2 + " · " : "") + sz;
                    if (line2.length() > 0) card.addView(Ui.sub(ctx, line2));
                    String desc = it.optString("desc", it.optString("url", ""));
                    if (desc.length() > 0) card.addView(Ui.sub(ctx, desc.length() > 70 ? desc.substring(0, 70) + "…" : desc));

                    LinearLayout ops = Ui.row(ctx);
                    TextView edit = Ui.btn(ctx, "编辑", false);
                    edit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openEditor(spec, root, it, idx);
                        }
                    });
                    ops.addView(edit);
                    TextView del = Ui.btn(ctx, "删除", false);
                    LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    dlp.leftMargin = Ui.dp(ctx, 8);
                    del.setLayoutParams(dlp);
                    del.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            confirmDelete(spec, root, it, idx);
                        }
                    });
                    ops.addView(del);
                    Ui.add(card, ops, 10);
                    Ui.add(host, card, 10);
                }
            }
        });
    }

    // ---------------- 编辑对话框 ----------------

    private void openEditor(final Spec spec, final JSONObject root, final JSONObject origin, final int index) {
        final boolean isNew = origin == null;
        final String id = isNew ? (spec.idPrefix + System.currentTimeMillis()) : origin.optString("id", "");
        final JSONObject base;
        try {
            base = isNew ? new JSONObject() : new JSONObject(origin.toString());
        } catch (Throwable t) {
            info("数据异常");
            return;
        }

        ScrollView sv = new ScrollView(ctx);
        final LinearLayout box = Ui.col(ctx);
        int p = Ui.dp(ctx, 16);
        box.setPadding(p, p, p, p);
        sv.addView(box);

        box.addView(Ui.kv(ctx, "ID", id));
        final List<EditText> inputs = new ArrayList<EditText>();
        for (int i = 0; i < spec.fields.length; i++) {
            String[] f = spec.fields[i];
            EditText e = Ui.input(ctx, f[1], "m".equals(f[2]), base.optString(f[0], ""));
            inputs.add(e);
            box.addView(Ui.sub(ctx, f[1]));
            Ui.add(box, e, 4);
        }

        // 子资源上传
        final String[] assetPath = {base.optString(spec.assetKind == null ? "" : (spec.assetKind.equals("image") ? "cover" : "zip"), "")};
        final byte[][] assetData = {null};
        final TextView assetInfo = Ui.tv(ctx, "子资源：" + (assetPath[0].length() == 0 ? "未设置" : assetPath[0]),
                12f, Theme.SUB, false);
        if (spec.assetKind != null) {
            TextView up = Ui.btn(ctx, spec.assetLabel, false);
            up.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String mime = spec.assetKind.equals("image") ? "image/*" : "*/*";
                    act.pickFile(mime, "file", new MainActivity.PickCb() {
                        @Override
                        public void onPicked(String name, byte[] data) {
                            assetData[0] = data;
                            String ext = extOf(name, spec.assetKind.equals("image") ? "png" : "zip");
                            String path = spec.assetKind.equals("image")
                                    ? "prompts/" + id + "." + ext
                                    : "skills/" + slug(origin == null ? "s" + System.currentTimeMillis() : origin.optString("name", "s"), "s") + "." + ext;
                            assetPath[0] = path;
                            setInput(inputs, spec, "zip", path);
                            if (spec.assetKind.equals("image")) setInput(inputs, spec, "cover", path);
                            if (!spec.assetKind.equals("image")) {
                                setInput(inputs, spec, "file", name.replace("\\", "/").replaceAll("^.*/", ""));
                                setInput(inputs, spec, "size", size(data.length));
                            }
                            assetInfo.setText("待上传：" + path + "（" + size(data.length) + "）");
                        }

                        @Override
                        public void onFailed(String reason) {
                            info(reason);
                        }
                    });
                }
            });
            Ui.add(box, up, 10);
            Ui.add(box, assetInfo, 6);
        }
        if (isNew) {
            // 新增时同步生成默认 id 字段
            setInput(inputs, spec, "id", id);
        }

        final TextView state = Ui.tv(ctx, isNew ? "新建条目" : "编辑条目", 12f, Theme.SUB, false);
        Ui.add(box, state, 10);

        LinearLayout ops = Ui.row(ctx);
        final AlertDialog dialog = new AlertDialog.Builder(act).setView(sv).create();
        TextView cancel = Ui.btn(ctx, "取消", false);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        ops.addView(cancel);
        TextView save = Ui.btn(ctx, "保存并发布", true);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = Ui.dp(ctx, 8);
        save.setLayoutParams(slp);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject item = new JSONObject();
                try {
                    JSONObject src = base;
                    java.util.Iterator<String> keys = src.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        item.put(k, src.get(k));
                    }
                    for (int i = 0; i < spec.fields.length; i++) {
                        String name = spec.fields[i][0];
                        String val = inputs.get(i).getText().toString().trim();
                        item.put(name, val);
                    }
                    item.put("id", id);
                } catch (Throwable t) {
                    state.setText("数据组装失败：" + t.getMessage());
                    return;
                }
                if (item.optString("title", item.optString("name", "")).trim().length() == 0) {
                    state.setText("请填写名称 / 标题");
                    return;
                }
                dialog.dismiss();
                saveItem(spec, root, item, index, isNew, assetData[0], assetPath[0]);
            }
        });
        ops.addView(save);
        Ui.add(box, ops, 12);

        dialog.show();
    }

    private void saveItem(final Spec spec, final JSONObject root, final JSONObject item, final int index,
                          final boolean isNew, final byte[] assetData, final String assetPath) {
        act.setText(status, "正在发布 " + spec.filePath + " …");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                StringBuilder sb = new StringBuilder();
                if (assetData != null && assetPath.length() > 0) {
                    Repo.writeBytes(ctx, "data/" + assetPath, assetData, "feat: 更新子资源 " + assetPath);
                    Repo.manifestTouch(ctx, assetPath, assetData);
                    sb.append("子资源已上传：").append(assetPath).append("；");
                }
                JSONArray arr = root.optJSONArray(spec.key);
                if (arr == null) arr = new JSONArray();
                JSONArray out = new JSONArray();
                for (int i = 0; i < arr.length(); i++) {
                    if (!isNew && i == index) out.put(new JSONObject(item.toString()));
                    else out.put(arr.opt(i));
                }
                if (isNew) out.put(new JSONObject(item.toString()));
                JSONObject r = new JSONObject(root.toString());
                r.put(spec.key, out);
                String text = Repo.pretty(r);
                Repo.writeText(ctx, spec.filePath, text, (isNew ? "feat: 新增 " : "feat: 更新 ") + spec.file + " - " + naming(item));
                Repo.manifestTouch(ctx, spec.file, text.getBytes("UTF-8"));
                sb.append(isNew ? "已新增" : "已更新").append("：").append(naming(item))
                        .append("（").append(out.length()).append(" 条）");
                return sb.toString();
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + err.getMessage());
                    log("内容发布失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result + " · " + Repo.today());
                log(spec.file + " " + result);
                act.badge("内容已更新", Theme.OK);
                rebuild();
            }
        });
    }

    private void confirmDelete(final Spec spec, final JSONObject root, final JSONObject it, final int index) {
        final String title = it.optString("title", it.optString("name", "(未命名)"));
        new AlertDialog.Builder(act)
                .setTitle("确认删除")
                .setMessage("将从 " + spec.filePath + " 移除：\n\n" + title
                        + "\n\n同时删除其子资源（封面 / 压缩包，如存在）。删除发布后 App 端将不再显示该条目。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        doDelete(spec, root, it, index);
                    }
                })
                .show();
    }

    private void doDelete(final Spec spec, final JSONObject root, final JSONObject it, final int index) {
        act.setText(status, "正在删除…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                String asset = it.optString(spec.assetKind != null && spec.assetKind.equals("image") ? "cover" : "zip", "");
                if (asset.length() > 0) {
                    try {
                        Repo.remove(ctx, "data/" + asset, "chore: 删除子资源 " + asset);
                        Repo.manifestRemove(ctx, asset);
                    } catch (Throwable ignored) {
                    }
                }
                JSONArray arr = root.optJSONArray(spec.key);
                JSONArray out = new JSONArray();
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        if (i == index) continue;
                        out.put(arr.opt(i));
                    }
                }
                JSONObject r = new JSONObject(root.toString());
                r.put(spec.key, out);
                String text = Repo.pretty(r);
                Repo.writeText(ctx, spec.filePath, text, "chore: 删除 " + spec.file + " - " + naming(it));
                Repo.manifestTouch(ctx, spec.file, text.getBytes("UTF-8"));
                return "已删除：" + naming(it) + "（剩余 " + out.length() + " 条）";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "删除失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result + " · " + Repo.today());
                log(spec.file + " " + result);
                act.badge("内容已更新", Theme.OK);
                rebuild();
            }
        });
    }

    // ---------------- 分类与卡片（resources.json） ----------------

    private void renderCategories(final LinearLayout host) {
        host.removeAllViews();
        act.setText(status, "正在读取 data/resources.json …");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject o = Repo.readJson(ctx, "data/resources.json");
                return o == null ? null : o.toString();
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "读取失败：" + err.getMessage());
                    return;
                }
                final JSONObject root;
                try {
                    root = result == null ? new JSONObject() : new JSONObject(result);
                } catch (Throwable t) {
                    act.setText(status, "数据格式异常");
                    return;
                }
                final JSONArray cats = root.optJSONArray("categories") == null ? new JSONArray() : root.optJSONArray("categories");
                if (currentCat == null) {
                    act.setText(status, "共 " + cats.length() + " 个分类 · " + Repo.today());
                    LinearLayout head = Ui.card(ctx);
                    head.addView(Ui.kv(ctx, "文件", "data/resources.json"));
                    head.addView(Ui.kv(ctx, "分类", cats.length() + " 个"));
                    TextView add = Ui.btn(ctx, "新增分类", true);
                    add.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openCategoryEditor(root, cats, null, -1);
                        }
                    });
                    Ui.add(head, add, 8);
                    Ui.add(host, head, 0);
                    for (int i = 0; i < cats.length(); i++) {
                        final int idx = i;
                        final JSONObject cat = cats.optJSONObject(i);
                        if (cat == null) continue;
                        LinearLayout card = Ui.card(ctx);
                        String name = cat.optString("name", "(未命名)");
                        LinearLayout r1 = Ui.row(ctx);
                        r1.addView(Ui.tv(ctx, name, 15f, Theme.TEXT, true),
                                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                        r1.addView(Ui.chip(ctx, "id " + cat.optString("id", "-"), Theme.SUB));
                        card.addView(r1);
                        JSONArray cards = cat.optJSONArray("cards");
                        card.addView(Ui.sub(ctx, "卡片 " + (cards == null ? 0 : cards.length()) + " 个 · "
                                + cat.optString("desc", "")));
                        LinearLayout ops = Ui.row(ctx);
                        TextView open = Ui.btn(ctx, "卡片管理", false);
                        open.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                currentCat = cat.optString("id", "");
                                rebuild();
                            }
                        });
                        ops.addView(open);
                        TextView edit = Ui.btn(ctx, "编辑", false);
                        ops.addView(edit, mar());
                        edit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                openCategoryEditor(root, cats, cat, idx);
                            }
                        });
                        TextView del = Ui.btn(ctx, "删除", false);
                        ops.addView(del, mar());
                        del.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                confirmDeleteCategory(root, cat, idx);
                            }
                        });
                        Ui.add(card, ops, 10);
                        Ui.add(host, card, 10);
                    }
                } else {
                    JSONObject cat = null;
                    int catIdx = -1;
                    for (int i = 0; i < cats.length(); i++) {
                        JSONObject c = cats.optJSONObject(i);
                        if (c != null && currentCat.equals(c.optString("id", ""))) {
                            cat = c;
                            catIdx = i;
                        }
                    }
                    if (cat == null) {
                        currentCat = null;
                        rebuild();
                        return;
                    }
                    act.setText(status, "分类「" + cat.optString("name", "") + "」 · " + Repo.today());
                    final JSONArray cards = cat.optJSONArray("cards") == null ? new JSONArray() : cat.optJSONArray("cards");
                    final JSONArray catsF = cats;
                    final int catIdxF = catIdx;
                    LinearLayout head = Ui.card(ctx);
                    TextView back = Ui.btn(ctx, "← 返回分类列表", false);
                    back.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            currentCat = null;
                            rebuild();
                        }
                    });
                    head.addView(back);
                    TextView add = Ui.btn(ctx, "新增卡片", true);
                    add.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openCardEditor(root, catsF, catIdxF, cards, null, -1);
                        }
                    });
                    Ui.add(head, add, 8);
                    Ui.add(host, head, 0);
                    for (int i = 0; i < cards.length(); i++) {
                        final int idx = i;
                        final JSONObject cd = cards.optJSONObject(i);
                        if (cd == null) continue;
                        LinearLayout card = Ui.card(ctx);
                        LinearLayout r1 = Ui.row(ctx);
                        r1.addView(Ui.tv(ctx, cd.optString("title", "(未命名)"), 14f, Theme.TEXT, true),
                                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                        String badge = cd.optString("badge", "");
                        if (badge.length() > 0) r1.addView(Ui.chip(ctx, badge, Theme.WARN));
                        card.addView(r1);
                        String url = cd.optString("url", "");
                        card.addView(Ui.sub(ctx, url.length() > 60 ? url.substring(0, 60) + "…" : url));
                        LinearLayout ops = Ui.row(ctx);
                        TextView edit = Ui.btn(ctx, "编辑", false);
                        ops.addView(edit);
                        edit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                openCardEditor(root, catsF, catIdxF, cards, cd, idx);
                            }
                        });
                        TextView del = Ui.btn(ctx, "删除", false);
                        ops.addView(del, mar());
                        del.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                confirmDeleteCard(root, catsF, catIdxF, cards, cd, idx);
                            }
                        });
                        Ui.add(card, ops, 10);
                        Ui.add(host, card, 10);
                    }
                }
            }
        });
    }

    private void openCategoryEditor(final JSONObject root, final JSONArray cats, final JSONObject origin, final int index) {
        final boolean isNew = origin == null;
        ScrollView sv = new ScrollView(ctx);
        LinearLayout box = Ui.col(ctx);
        int p = Ui.dp(ctx, 16);
        box.setPadding(p, p, p, p);
        sv.addView(box);

        final EditText inId = Ui.input(ctx, "分类 id（英文，如 coop）", false, isNew ? "cat" + System.currentTimeMillis() % 10000 : origin.optString("id", ""));
        final EditText inName = Ui.input(ctx, "分类名称", false, origin == null ? "" : origin.optString("name", ""));
        final EditText inIcon = Ui.input(ctx, "图标名（如 Flame，可空）", false, origin == null ? "" : origin.optString("iconName", ""));
        final EditText inDesc = Ui.input(ctx, "分类描述", true, origin == null ? "" : origin.optString("desc", ""));
        final EditText inSubs = Ui.input(ctx, "子分类（格式 id:名称，多条用英文逗号分隔）", true,
                origin == null ? "" : subsToText(origin.optJSONArray("subcategories")));
        box.addView(Ui.sub(ctx, inId.getHint().toString()));
        Ui.add(box, inId, 4);
        box.addView(Ui.sub(ctx, "分类名称"));
        Ui.add(box, inName, 4);
        box.addView(Ui.sub(ctx, "图标名（如 Flame，可空）"));
        Ui.add(box, inIcon, 4);
        box.addView(Ui.sub(ctx, "分类描述"));
        Ui.add(box, inDesc, 4);
        box.addView(Ui.sub(ctx, inSubs.getHint().toString()));
        Ui.add(box, inSubs, 4);

        final AlertDialog dialog = new AlertDialog.Builder(act).setView(sv).create();
        LinearLayout ops = Ui.row(ctx);
        TextView cancel = Ui.btn(ctx, "取消", false);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        ops.addView(cancel);
        TextView save = Ui.btn(ctx, "保存并发布", true);
        ops.addView(save, mar());
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                saveCategory(root, cats, origin, index, inId.getText().toString().trim(),
                        inName.getText().toString().trim(), inIcon.getText().toString().trim(),
                        inDesc.getText().toString().trim(), inSubs.getText().toString().trim());
            }
        });
        Ui.add(box, ops, 12);
        dialog.show();
    }

    private void saveCategory(final JSONObject root, final JSONArray cats, final JSONObject origin, final int index,
                              final String id, final String name, final String icon, final String desc, final String subs) {
        if (name.length() == 0) {
            info("请填写分类名称");
            return;
        }
        act.setText(status, "正在发布分类…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject cat = new JSONObject();
                if (origin != null) {
                    java.util.Iterator<String> ks = origin.keys();
                    while (ks.hasNext()) {
                        String k = ks.next();
                        cat.put(k, origin.get(k));
                    }
                }
                cat.put("id", id.length() == 0 ? ("cat" + System.currentTimeMillis() % 10000) : id);
                cat.put("name", name);
                cat.put("iconName", icon);
                cat.put("desc", desc);
                cat.put("subcategories", parseSubs(subs));
                if (!cat.has("cards")) cat.put("cards", new JSONArray());
                JSONArray out = new JSONArray();
                for (int i = 0; i < cats.length(); i++) {
                    if (i == index) out.put(cat);
                    else out.put(cats.opt(i));
                }
                if (index < 0) out.put(cat);
                JSONObject r = new JSONObject(root.toString());
                r.put("categories", out);
                String text = Repo.pretty(r);
                Repo.writeText(ctx, "data/resources.json", text, "feat: 更新分类 " + name);
                Repo.manifestTouch(ctx, "resources.json", text.getBytes("UTF-8"));
                return "分类已发布：" + name;
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result + " · " + Repo.today());
                log("resources.json " + result);
                act.badge("内容已更新", Theme.OK);
                rebuild();
            }
        });
    }

    private void confirmDeleteCategory(final JSONObject root, final JSONObject cat, final int index) {
        new AlertDialog.Builder(act)
                .setTitle("确认删除分类")
                .setMessage("将删除分类「" + cat.optString("name", "") + "」及其下全部卡片。\n此操作发布后 App 端立即不再显示。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        act.setText(status, "正在删除分类…");
                        Ui.run(act, new Ui.Job() {
                            @Override
                            public String run() throws Exception {
                                JSONArray cats = root.optJSONArray("categories");
                                JSONArray out = new JSONArray();
                                for (int i = 0; i < cats.length(); i++) {
                                    if (i == index) continue;
                                    out.put(cats.opt(i));
                                }
                                JSONObject r = new JSONObject(root.toString());
                                r.put("categories", out);
                                String text = Repo.pretty(r);
                                Repo.writeText(ctx, "data/resources.json", text, "chore: 删除分类 " + cat.optString("name", ""));
                                Repo.manifestTouch(ctx, "resources.json", text.getBytes("UTF-8"));
                                return "分类已删除";
                            }
                        }, new Ui.Done() {
                            @Override
                            public void done(String result, Throwable err) {
                                if (err != null) {
                                    act.setText(status, "删除失败：" + err.getMessage());
                                    return;
                                }
                                act.setText(status, result + " · " + Repo.today());
                                log("resources.json " + result);
                                rebuild();
                            }
                        });
                    }
                })
                .show();
    }

    private void openCardEditor(final JSONObject root, final JSONArray cats, final int catIdx,
                                final JSONArray cards, final JSONObject origin, final int index) {
        ScrollView sv = new ScrollView(ctx);
        LinearLayout box = Ui.col(ctx);
        int p = Ui.dp(ctx, 16);
        box.setPadding(p, p, p, p);
        sv.addView(box);
        final boolean isNew = origin == null;
        String[] names = {"卡片标题", "跳转链接 url", "图标（favicon 或图片地址）", "备用域名 fallbackDomain",
                "备用字段 fallbackText", "角标 badge", "子分类 subcatId"};
        String[] keys = {"title", "url", "icon", "fallbackDomain", "fallbackText", "badge", "subcatId"};
        final List<EditText> inputs = new ArrayList<EditText>();
        for (int i = 0; i < keys.length; i++) {
            EditText e = Ui.input(ctx, names[i], false, origin == null ? "" : origin.optString(keys[i], ""));
            if (keys[i].equals("subcatId")) {
                e.setText(origin == null ? defaultSubcat(cats.optJSONObject(catIdx)) : origin.optString("subcatId", ""));
            }
            inputs.add(e);
            box.addView(Ui.sub(ctx, names[i]));
            Ui.add(box, e, 4);
        }
        final AlertDialog dialog = new AlertDialog.Builder(act).setView(sv).create();
        LinearLayout ops = Ui.row(ctx);
        TextView cancel = Ui.btn(ctx, "取消", false);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        ops.addView(cancel);
        TextView save = Ui.btn(ctx, "保存并发布", true);
        ops.addView(save, mar());
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                saveCard(root, cats, catIdx, cards, origin, index, keys, inputs);
            }
        });
        Ui.add(box, ops, 12);
        dialog.show();
    }

    private void saveCard(final JSONObject root, final JSONArray cats, final int catIdx, final JSONArray cards,
                          final JSONObject origin, final int index, final String[] keys, final List<EditText> inputs) {
        final String title = inputs.get(0).getText().toString().trim();
        if (title.length() == 0) {
            info("请填写卡片标题");
            return;
        }
        act.setText(status, "正在发布卡片…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject cd = new JSONObject();
                if (origin != null) {
                    java.util.Iterator<String> ks = origin.keys();
                    while (ks.hasNext()) {
                        String k = ks.next();
                        cd.put(k, origin.get(k));
                    }
                }
                for (int i = 0; i < keys.length; i++) cd.put(keys[i], inputs.get(i).getText().toString().trim());
                if (!cd.has("id") || cd.optString("id", "").length() == 0) {
                    cd.put("id", "c" + System.currentTimeMillis() % 100000);
                }
                JSONArray outCards = new JSONArray();
                for (int i = 0; i < cards.length(); i++) {
                    if (i == index) outCards.put(cd);
                    else outCards.put(cards.opt(i));
                }
                if (index < 0) outCards.put(cd);
                JSONObject cat = new JSONObject(cats.optJSONObject(catIdx).toString());
                cat.put("cards", outCards);
                JSONArray outCats = new JSONArray();
                for (int i = 0; i < cats.length(); i++) {
                    if (i == catIdx) outCats.put(cat);
                    else outCats.put(cats.opt(i));
                }
                JSONObject r = new JSONObject(root.toString());
                r.put("categories", outCats);
                String text = Repo.pretty(r);
                Repo.writeText(ctx, "data/resources.json", text, "feat: 更新卡片 " + title);
                Repo.manifestTouch(ctx, "resources.json", text.getBytes("UTF-8"));
                return "卡片已发布：" + title;
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result + " · " + Repo.today());
                log("resources.json " + result);
                act.badge("内容已更新", Theme.OK);
                rebuild();
            }
        });
    }

    private void confirmDeleteCard(final JSONObject root, final JSONArray cats, final int catIdx,
                                   final JSONArray cards, final JSONObject cd, final int index) {
        new AlertDialog.Builder(act)
                .setTitle("确认删除卡片")
                .setMessage("将删除卡片「" + cd.optString("title", "") + "」。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        act.setText(status, "正在删除卡片…");
                        Ui.run(act, new Ui.Job() {
                            @Override
                            public String run() throws Exception {
                                JSONArray outCards = new JSONArray();
                                for (int i = 0; i < cards.length(); i++) {
                                    if (i == index) continue;
                                    outCards.put(cards.opt(i));
                                }
                                JSONObject cat = new JSONObject(cats.optJSONObject(catIdx).toString());
                                cat.put("cards", outCards);
                                JSONArray outCats = new JSONArray();
                                for (int i = 0; i < cats.length(); i++) {
                                    if (i == catIdx) outCats.put(cat);
                                    else outCats.put(cats.opt(i));
                                }
                                JSONObject r = new JSONObject(root.toString());
                                r.put("categories", outCats);
                                String text = Repo.pretty(r);
                                Repo.writeText(ctx, "data/resources.json", text, "chore: 删除卡片 " + cd.optString("title", ""));
                                Repo.manifestTouch(ctx, "resources.json", text.getBytes("UTF-8"));
                                return "卡片已删除";
                            }
                        }, new Ui.Done() {
                            @Override
                            public void done(String result, Throwable err) {
                                if (err != null) {
                                    act.setText(status, "删除失败：" + err.getMessage());
                                    return;
                                }
                                act.setText(status, result + " · " + Repo.today());
                                log("resources.json " + result);
                                rebuild();
                            }
                        });
                    }
                })
                .show();
    }

    // ---------------- 工具 ----------------

    private LinearLayout.LayoutParams mar() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Ui.dp(ctx, 8);
        return lp;
    }

    private static void setInput(List<EditText> inputs, Spec spec, String name, String value) {
        for (int i = 0; i < spec.fields.length; i++) {
            if (spec.fields[i][0].equals(name)) {
                inputs.get(i).setText(value);
                return;
            }
        }
    }

    private static String naming(JSONObject o) {
        String t = o.optString("title", o.optString("name", ""));
        return t.length() == 0 ? o.optString("id", "") : t;
    }

    private static String extOf(String fileName, String def) {
        int i = fileName == null ? -1 : fileName.lastIndexOf('.');
        if (i < 0 || i == fileName.length() - 1) return def;
        String e = fileName.substring(i + 1).toLowerCase(Locale.ROOT);
        return e.length() > 5 ? def : e;
    }

    private static String slug(String name, String prefix) {
        StringBuilder sb = new StringBuilder();
        if (name != null) {
            for (char c : name.toLowerCase(Locale.ROOT).toCharArray()) {
                if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) sb.append(c);
                else if (c == ' ' || c == '-' || c == '_') sb.append('-');
            }
        }
        String s = sb.toString().replaceAll("-{2,}", "-");
        if (s.startsWith("-")) s = s.substring(1);
        if (s.endsWith("-")) s = s.substring(0, s.length() - 1);
        if (s.length() == 0) s = prefix + System.currentTimeMillis();
        if (s.length() > 24) s = s.substring(0, 24);
        return s;
    }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return new DecimalFormat("0.0").format(b / 1024.0) + " KB";
        return new DecimalFormat("0.00").format(b / 1048576.0) + " MB";
    }

    private static String subsToText(JSONArray subs) {
        if (subs == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s == null) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(s.optString("id", "")).append(':').append(s.optString("name", ""));
        }
        return sb.toString();
    }

    private static JSONArray parseSubs(String text) {
        JSONArray out = new JSONArray();
        if (text == null || text.trim().length() == 0) return out;
        String[] parts = text.split("[,，]");
        for (String p : parts) {
            String s = p.trim();
            if (s.length() == 0) continue;
            int i = s.indexOf(':');
            String id = i < 0 ? s : s.substring(0, i).trim();
            String nm = i < 0 ? s : s.substring(i + 1).trim();
            try {
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("name", nm);
                out.put(o);
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    private static String defaultSubcat(JSONObject cat) {
        if (cat == null) return "";
        JSONArray subs = cat.optJSONArray("subcategories");
        if (subs != null && subs.length() > 0) {
            JSONObject s = subs.optJSONObject(0);
            return s == null ? "" : s.optString("id", "");
        }
        return cat.optString("id", "");
    }
}
