#!/bin/bash
# 淑婷控制台 · 原生 Android 手工构建脚本（无 Gradle）
# 用法：TOOLS_ROOT=/path/to/tools bash build.sh
#   TOOLS_ROOT 需包含: jdk-17.0.20.1+1/ 与 android-sdk/{build-tools/34.0.0, platforms/android-34, cmdline-tools/latest/lib/r8.jar}
set -e

W="$(cd "$(dirname "$0")" && pwd)"
OUT="${OUT_DIR:-$W/out}"
TOOLS="${TOOLS_ROOT:?请设置 TOOLS_ROOT 指向工具链目录}"
KS="${KS_PATH:-$HOME/chenshuting-release.jks}"
KSPASS="${KS_PASS:-chenshuting2026}"
VER_CODE="${VER_CODE:-1}"
VER_NAME="${VER_NAME:-1.0.0}"

export JAVA_HOME="$TOOLS/jdk-17.0.20.1+1"
export PATH="$JAVA_HOME/bin:$PATH"
BT="$TOOLS/android-sdk/build-tools/34.0.0"
AJAR="$TOOLS/android-sdk/platforms/android-34/android.jar"

echo "=== [1/8] 清理构建目录 ==="
rm -rf "$W/build"
mkdir -p "$W/build/gen" "$W/build/classes" "$W/build/dex"

cd "$W/app"

echo "=== [2/8] aapt2 compile 资源 ==="
"$BT/aapt2" compile --dir res -o "$W/build/res.zip"

echo "=== [3/8] aapt2 link 生成资源 APK ==="
"$BT/aapt2" link -o "$W/build/base.apk" \
  -I "$AJAR" \
  --manifest AndroidManifest.xml \
  -R "$W/build/res.zip" \
  --auto-add-overlay \
  --java "$W/build/gen" \
  --min-sdk-version 21 --target-sdk-version 34 \
  --version-code "$VER_CODE" --version-name "$VER_NAME"

echo "=== [4/8] javac 编译 Java 源码 ==="
javac -encoding UTF-8 -nowarn -cp "$AJAR" --release 8 -d "$W/build/classes" \
  $(find java -name '*.java') \
  "$W/build/gen/com/chenshuting/console/R.java"

echo "=== [5/8] R8 收缩 + 优化 ==="
R8JAR="$TOOLS/android-sdk/cmdline-tools/latest/lib/r8.jar"
java -cp "$R8JAR" com.android.tools.r8.R8 \
  --release --lib "$AJAR" --min-api 21 \
  --output "$W/build/dex" \
  --pg-conf "$W/proguard-rules.pro" \
  $(find "$W/build/classes" -name '*.class')
ls -l "$W/build/dex"

echo "=== [6/8] 合并 dex 进 APK ==="
python3 - "$W/build/base.apk" "$W/build/dex" <<'PY'
import sys, os, glob, zipfile
apk, dexdir = sys.argv[1], sys.argv[2]
dexs = sorted(glob.glob(os.path.join(dexdir, 'classes*.dex')))
assert dexs, 'no dex produced'
with zipfile.ZipFile(apk, 'a', zipfile.ZIP_STORED) as z:
    for p in dexs:
        z.write(p, os.path.basename(p))
print('dex merged into', apk, '->', [os.path.basename(p) for p in dexs])
PY

echo "=== [7/8] zipalign 对齐 ==="
"$BT/zipalign" -f -p 4 "$W/build/base.apk" "$W/build/aligned.apk"

echo "=== [8/8] 签名 ==="
mkdir -p "$OUT"
APK="$OUT/淑婷控制台-v$VER_NAME.apk"
"$BT/apksigner" sign \
  --ks "$KS" --ks-key-alias chenshuting \
  --ks-pass "pass:$KSPASS" --key-pass "pass:$KSPASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v4-signing-enabled false \
  --out "$APK" "$W/build/aligned.apk"

echo "=== 校验 ==="
"$BT/apksigner" verify --print-certs "$APK" | head -8
"$BT/aapt2" dump badging "$APK" | head -6
ls -lh "$APK"
