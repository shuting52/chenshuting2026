package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 开屏页：本体启动开屏（背景 / 文字 / 动效 / 时长）的云端配置。
 *  配置落 data/splash.json，字段与本体 SplashConfig / SplashView 一一对应；
 *  支持 JSON 源码与 CSS 子集两种编辑方式，均可实时预览后发布。 */
public final class PageSplash extends Page {

    public static final String PATH = "data/splash.json";

    public static final String[] FIELDS = {
            "bgTop", "bgBottom", "bgImage", "logoText", "title", "sub", "tip", "footer",
            "titleColor", "subColor", "tipColor", "footerColor",
            "aurora", "star", "ring", "bar", "totalMs"};

    /** 出厂默认：与本体内置 SplashView 默认视觉一致。 */
    public static final String DEFAULTS_JSON =
            "{\"bgTop\":\"#0F2027\",\"bgBottom\":\"#2C5364\",\"bgImage\":\"\","
                    + "\"logoText\":\"陈\",\"title\":\"陈淑婷工具箱\",\"sub\":\"海量资源 · 一站直达\","
                    + "\"tip\":\"加载中...\",\"footer\":\"v1.6.5\","
                    + "\"titleColor\":\"#FFFFFF\",\"subColor\":\"#CCE8F5\",\"tipColor\":\"#8FB7CC\",\"footerColor\":\"#7FA5B8\","
                    + "\"aurora\":true,\"star\":true,\"ring\":true,\"bar\":true,\"totalMs\":2350}";

    private JSONObject cfg;
    private LinearLayout previewBox;
    private TextView previewLogo;
    private TextView previewTitle;
    private TextView previewSub;
    private TextView previewTip;
    private TextView previewFooter;
    private View previewBar;
    private TextView seekVal;

    public PageSplash(MainActivity a) {
        super(a);
        cfg = defaults();
    }

    private static JSONObject defaults() {
        try {
            return new JSONObject(DEFAULTS_JSON);
        } catch (Throwable t) {
            return new JSONObject();
        }
    }

    private JSONObject cfg() {
        return cfg;
    }

    @Override
    protected void build() {
        Tutorial.add(body, ctx, "开屏配置页 · 怎么用", new String[]{
                "改字段：下方各卡片直接改文字 / 颜色 / 动效开关 / 时长，「实时预览」即时刷新，所见即所得。",
                "改代码：点「编辑 JSON」可整包粘贴；点「编辑 CSS」用 background / color 等简单规则快速上色（如 background: linear-gradient(#0F2027, #2C5364)）。",
                "发布：点「发布到线上」，配置写入仓库 data/splash.json，工具箱下次启动生效；用户无需更新 APK。",
                "回滚：点「从线上读取」拉回当前线上配置；点「恢复默认」还原为出厂样式。"});

        LinearLayout bar = Ui.row(ctx);
        TextView b1 = Ui.btn(ctx, "预览开屏", true);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previewFull();
            }
        });
        bar.addView(b1, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b2 = Ui.btn(ctx, "发布到线上", true);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publish();
            }
        });
        bar.addView(b2, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Ui.add(body, bar, 10);

        LinearLayout bar2 = Ui.row(ctx);
        TextView b3 = Ui.btn(ctx, "编辑 JSON", false);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCode();
            }
        });
        bar2.addView(b3, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b4 = Ui.btn(ctx, "编辑 CSS", false);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCss();
            }
        });
        bar2.addView(b4, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b5 = Ui.btn(ctx, "从线上读取", false);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pull();
            }
        });
        bar2.addView(b5, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView b6 = Ui.btn(ctx, "恢复默认", false);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cfg = defaults();
                rebuild();
                info("已恢复为出厂默认开屏样式");
            }
        });
        bar2.addView(b6, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Ui.add(body, bar2, 10);

        // 实时预览
        LinearLayout card = Ui.card(ctx);
        card.addView(Ui.section(ctx, "实时预览"));
        previewBox = buildPreview();
        card.addView(previewBox, lpMatch());
        Ui.add(body, card, 12);

        // 文字
        LinearLayout t = Ui.card(ctx);
        t.addView(Ui.section(ctx, "开屏文字"));
        text(t, cfg(), "logoText", "Logo 单字（圆形徽标里的字）");
        text(t, cfg(), "title", "主标题");
        text(t, cfg(), "sub", "副标题");
        text(t, cfg(), "tip", "底部提示（加载中...）");
        text(t, cfg(), "footer", "底部版本号");
        Ui.add(body, t, 12);

        // 外观
        LinearLayout a = Ui.card(ctx);
        a.addView(Ui.section(ctx, "背景与配色"));
        colorRow(a, cfg(), "bgTop", "背景上色（bgTop）");
        colorRow(a, cfg(), "bgBottom", "背景下色（bgBottom）");
        text(a, cfg(), "bgImage", "背景图 URL（可选，空则不加载）");
        colorRow(a, cfg(), "titleColor", "主标题颜色");
        colorRow(a, cfg(), "subColor", "副标题颜色");
        colorRow(a, cfg(), "tipColor", "提示文字颜色");
        colorRow(a, cfg(), "footerColor", "版本号颜色");
        Ui.add(body, a, 12);

        // 动效
        LinearLayout m = Ui.card(ctx);
        m.addView(Ui.section(ctx, "动效开关"));
        switchRow(m, cfg(), "aurora", "极光（背景渐变光晕）");
        switchRow(m, cfg(), "star", "星空粒子");
        switchRow(m, cfg(), "ring", "光环（Logo 外圈）");
        switchRow(m, cfg(), "bar", "底部加载进度条");
        seek(m, cfg(), "totalMs", "开屏时长（毫秒）", 800, 5000, 2350);
        Ui.add(body, m, 12);

        // 字段对照
        LinearLayout n = Ui.card(ctx);
        n.addView(Ui.section(ctx, "字段对照（splash.json）"));
        n.addView(Ui.kv(ctx, "bgTop / bgBottom", "上下渐变底色，#RRGGBB"));
        n.addView(Ui.kv(ctx, "bgImage", "背景图直链，留空则不加载"));
        n.addView(Ui.kv(ctx, "logoText", "圆形徽标文字（默认「陈」）"));
        n.addView(Ui.kv(ctx, "title / sub / tip / footer", "主标题 / 副标题 / 提示 / 版本"));
        n.addView(Ui.kv(ctx, "aurora / star / ring / bar", "四类动效开关，true/false"));
        n.addView(Ui.kv(ctx, "totalMs", "开屏停留时长（毫秒）"));
        Ui.add(body, n, 12);
    }

    private LinearLayout.LayoutParams lpMatch() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    // ---------------- 实时预览 ----------------

    private LinearLayout buildPreview() {
        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        int h = Ui.dp(ctx, 280);
        box.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        box.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 20), Ui.dp(ctx, 16), Ui.dp(ctx, 16));
        paintPreview(box);
        return box;
    }

    /** 按当前配置重绘预览卡。 */
    private void paintPreview(LinearLayout box) {
        JSONObject s = cfg();
        int top = color(str(s, "bgTop", "#0F2027"), 0xFF0F2027);
        int bot = color(str(s, "bgBottom", "#2C5364"), 0xFF2C5364);
        boolean aurora = bool(s, "aurora", true);
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                aurora ? new int[]{top, bot} : new int[]{top, top});
        g.setCornerRadius(Ui.dp(ctx, 20));
        box.setBackground(g);
        box.removeAllViews();

        // Logo 圆
        LinearLayout logo = new LinearLayout(ctx);
        logo.setOrientation(LinearLayout.VERTICAL);
        logo.setGravity(Gravity.CENTER);
        int ls = Ui.dp(ctx, 64);
        GradientDrawable lg = new GradientDrawable();
        lg.setShape(GradientDrawable.OVAL);
        boolean ring = bool(s, "ring", true);
        int logoFill = (color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF) & 0x00FFFFFF) | 0x33FFFFFF;
        lg.setColor(logoFill);
        lg.setStroke(ring ? Math.max(1, Ui.dp(ctx, 1.6f)) : 0,
                (color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF) & 0x00FFFFFF) | 0x66FFFFFF);
        logo.setBackground(lg);
        previewLogo = Ui.tv(ctx, str(s, "logoText", "陈"), 22f,
                color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF), true);
        logo.addView(previewLogo);
        box.addView(logo, new LinearLayout.LayoutParams(ls, ls));

        previewTitle = Ui.tv(ctx, str(s, "title", "陈淑婷工具箱"), 19f,
                color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF), true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(ctx, 18);
        box.addView(previewTitle, tlp);

        previewSub = Ui.tv(ctx, str(s, "sub", "海量资源 · 一站直达"), 12f,
                color(str(s, "subColor", "#CCE8F5"), 0xFFCCE8F5), false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Ui.dp(ctx, 6);
        box.addView(previewSub, slp);

        // 底部行：tip + bar
        LinearLayout bottom = new LinearLayout(ctx);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER);
        previewTip = Ui.tv(ctx, str(s, "tip", "加载中..."), 10f,
                color(str(s, "tipColor", "#8FB7CC"), 0xFF8FB7CC), false);
        bottom.addView(previewTip);
        if (bool(s, "bar", true)) {
            View bar = new View(ctx);
            GradientDrawable bg2 = new GradientDrawable();
            bg2.setCornerRadius(Ui.dp(ctx, 2));
            int fill = (color(str(s, "tipColor", "#8FB7CC"), 0xFF8FB7CC) & 0x00FFFFFF) | 0x66FFFFFF;
            bg2.setColor(fill);
            bar.setBackground(bg2);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(Ui.dp(ctx, 120), Ui.dp(ctx, 4));
            blp.topMargin = Ui.dp(ctx, 8);
            bottom.addView(bar, blp);
            previewBar = bar;
        } else {
            previewBar = null;
        }
        LinearLayout.LayoutParams bl2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bl2.topMargin = Ui.dp(ctx, 14);
        box.addView(bottom, bl2);

        previewFooter = Ui.tv(ctx, str(s, "footer", "v1.6.5"), 10f,
                color(str(s, "footerColor", "#7FA5B8"), 0xFF7FA5B8), false);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        flp.topMargin = Ui.dp(ctx, 6);
        box.addView(previewFooter, flp);
    }

    /** 全屏预览：模拟本体开屏视觉（静态，不含动效）。 */
    private void previewFull() {
        final FrameLayoutWrap host = new FrameLayoutWrap(ctx);
        final LinearLayout p = new LinearLayout(ctx);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setGravity(Gravity.CENTER);
        JSONObject s = cfg();
        int top = color(str(s, "bgTop", "#0F2027"), 0xFF0F2027);
        int bot = color(str(s, "bgBottom", "#2C5364"), 0xFF2C5364);
        boolean aurora = bool(s, "aurora", true);
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                aurora ? new int[]{top, bot} : new int[]{top, top});
        p.setBackground(g);
        p.setPadding(Ui.dp(ctx, 24), 0, Ui.dp(ctx, 24), 0);

        LinearLayout logo = new LinearLayout(ctx);
        logo.setOrientation(LinearLayout.VERTICAL);
        logo.setGravity(Gravity.CENTER);
        int ls = Ui.dp(ctx, 76);
        GradientDrawable lg = new GradientDrawable();
        lg.setShape(GradientDrawable.OVAL);
        int logoFill = (color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF) & 0x00FFFFFF) | 0x33FFFFFF;
        lg.setColor(logoFill);
        lg.setStroke(bool(s, "ring", true) ? Math.max(1, Ui.dp(ctx, 1.6f)) : 0,
                (color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF) & 0x00FFFFFF) | 0x66FFFFFF);
        logo.setBackground(lg);
        TextView lv = Ui.tv(ctx, str(s, "logoText", "陈"), 26f,
                color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF), true);
        logo.addView(lv);
        p.addView(logo, new LinearLayout.LayoutParams(ls, ls));

        TextView t1 = Ui.tv(ctx, str(s, "title", "陈淑婷工具箱"), 21f,
                color(str(s, "titleColor", "#FFFFFF"), 0xFFFFFFFF), true);
        LinearLayout.LayoutParams t1p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t1p.topMargin = Ui.dp(ctx, 22);
        p.addView(t1, t1p);

        TextView t2 = Ui.tv(ctx, str(s, "sub", "海量资源 · 一站直达"), 13f,
                color(str(s, "subColor", "#CCE8F5"), 0xFFCCE8F5), false);
        LinearLayout.LayoutParams t2p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t2p.topMargin = Ui.dp(ctx, 8);
        p.addView(t2, t2p);

        TextView t3 = Ui.tv(ctx, str(s, "tip", "加载中..."), 11f,
                color(str(s, "tipColor", "#8FB7CC"), 0xFF8FB7CC), false);
        LinearLayout.LayoutParams t3p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t3p.topMargin = Ui.dp(ctx, 34);
        p.addView(t3, t3p);

        if (bool(s, "bar", true)) {
            View bar = new View(ctx);
            GradientDrawable b2 = new GradientDrawable();
            b2.setCornerRadius(Ui.dp(ctx, 3));
            int fill = (color(str(s, "tipColor", "#8FB7CC"), 0xFF8FB7CC) & 0x00FFFFFF) | 0x66FFFFFF;
            b2.setColor(fill);
            bar.setBackground(b2);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(Ui.dp(ctx, 150), Ui.dp(ctx, 5));
            blp.topMargin = Ui.dp(ctx, 12);
            p.addView(bar, blp);
        }

        TextView t4 = Ui.tv(ctx, str(s, "footer", "v1.6.5"), 11f,
                color(str(s, "footerColor", "#7FA5B8"), 0xFF7FA5B8), false);
        LinearLayout.LayoutParams t4p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        t4p.topMargin = Ui.dp(ctx, 26);
        p.addView(t4, t4p);

        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                host.dismiss();
            }
        });
        host.show(p);
    }

    /** 简易全屏浮层（点任意处关闭）。 */
    private static class FrameLayoutWrap extends android.widget.FrameLayout {
        private final android.widget.FrameLayout root;

        FrameLayoutWrap(Context c) {
            super(c);
            root = (android.widget.FrameLayout) ((android.app.Activity) c).getWindow().getDecorView();
        }

        void show(View content) {
            removeAllViews();
            addView(content, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            root.addView(this, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }

        void dismiss() {
            root.removeView(this);
        }
    }

    // ---------------- 参数控件 ----------------

    private void text(LinearLayout card, final JSONObject s, final String key, String label) {
        final EditText e = Ui.input(ctx, label, false, str(s, key, ""));
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable ed) {
                try {
                    s.put(key, ed.toString().trim());
                } catch (Throwable ignored) {
                }
                paintPreview(previewBox);
            }
        });
        Ui.add(card, e, 10);
    }

    private void colorRow(LinearLayout card, final JSONObject s, final String key, String label) {
        LinearLayout row = Ui.row(ctx);
        TextView lab = Ui.tv(ctx, label, 13f, Theme.TEXT, false);
        lab.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(lab);
        final EditText e = Ui.input(ctx, "#RRGGBB", false, str(s, key, ""));
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(Ui.dp(ctx, 120),
                ViewGroup.LayoutParams.WRAP_CONTENT);
        e.setLayoutParams(elp);
        e.setGravity(Gravity.CENTER);
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence cs, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable ed) {
                String v = ed.toString().trim();
                try {
                    s.put(key, v.length() == 0 ? "" : v);
                } catch (Throwable ignored) {
                }
                paintPreview(previewBox);
            }
        });
        row.addView(e);
        Ui.add(card, row, 10);
    }

    private void switchRow(LinearLayout card, final JSONObject s, final String key, String label) {
        LinearLayout row = Ui.row(ctx);
        TextView lab = Ui.tv(ctx, label, 13f, Theme.TEXT, false);
        lab.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(lab);
        final TextView sw = Ui.tv(ctx, bool(s, key, false) ? "开" : "关", 13f,
                bool(s, key, false) ? Theme.OK : Theme.SUB, true);
        sw.setBackground(Ui.soft(ctx, bool(s, key, false) ? Theme.CARD2 : Theme.CARD, 10f));
        sw.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 6), Ui.dp(ctx, 14), Ui.dp(ctx, 6));
        sw.setClickable(true);
        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean now = !bool(s, key, false);
                try {
                    s.put(key, now);
                } catch (Throwable ignored) {
                }
                sw.setText(now ? "开" : "关");
                sw.setTextColor(now ? Theme.OK : Theme.SUB);
                sw.setBackground(Ui.soft(ctx, now ? Theme.CARD2 : Theme.CARD, 10f));
                paintPreview(previewBox);
            }
        });
        row.addView(sw);
        Ui.add(card, row, 8);
    }

    private void seek(LinearLayout card, final JSONObject s, final String key, String label,
                      final int min, final int max, int def) {
        LinearLayout row = Ui.row(ctx);
        TextView lab = Ui.tv(ctx, label, 13f, Theme.TEXT, false);
        lab.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(lab);
        seekVal = Ui.tv(ctx, String.valueOf(i(s, key, def)), 13f, Theme.GOLD, true);
        row.addView(seekVal);
        Ui.add(card, row, 6);
        SeekBar sb = new SeekBar(ctx);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, i(s, key, def) - min)));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int v = min + progress;
                seekVal.setText(String.valueOf(v));
                try {
                    s.put(key, v);
                } catch (Throwable ignored) {
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        Ui.add(card, sb, 2);
    }

    // ---------------- 代码编辑 ----------------

    private void openCss() {
        final EditText et = Ui.codeInputCss(ctx, str(cfg(), "css", ""));
        new AlertDialog.Builder(act)
                .setTitle("编辑开屏 CSS（子集）")
                .setMessage("支持：background: linear-gradient(#A, #B) / background: #hex → 背景上下色；"
                        + "选择器含 title/sub/tip/footer 的 color → 对应文字色。")
                .setView(wrapCode(et))
                .setPositiveButton("校验并应用", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String err = applyCss(et.getText().toString());
                        if (err != null) {
                            info(err);
                        } else {
                            paintPreview(previewBox);
                            info("CSS 已应用，可在预览区核对效果");
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private String applyCss(String cssText) {
        if (cssText == null || cssText.trim().length() == 0) {
            return "CSS 内容为空";
        }
        try {
            JSONObject s = cfg();
            Pattern block = Pattern.compile("([^{}]+)\\{([^{}]*)\\}");
            Matcher m = block.matcher(cssText);
            boolean any = false;
            while (m.find()) {
                applyBlock(m.group(1).trim(), m.group(2), s);
                any = true;
            }
            if (!any) applyBlock("", cssText, s);
            s.put("css", cssText.trim());
            return null;
        } catch (Throwable t) {
            return t.getMessage() == null ? "解析失败" : t.getMessage();
        }
    }

    private void applyBlock(String sel, String body, JSONObject s) throws Exception {
        boolean isTitle = sel.contains("title") || sel.contains("h1");
        boolean isSub = sel.contains("sub");
        boolean isTip = sel.contains("tip");
        boolean isFooter = sel.contains("footer") || sel.contains("ver");
        boolean global = sel.length() == 0 || sel.contains("dialog") || sel.contains("splash") || sel.contains(".root");

        Matcher pm = Pattern.compile("([a-zA-Z-]+)\\s*:\\s*([^;]+);?").matcher(body);
        while (pm.find()) {
            String k = pm.group(1).trim().toLowerCase(Locale.ROOT);
            String v = pm.group(2).trim();
            if (v.length() == 0) continue;
            if ("background".equals(k) || "background-color".equals(k)) {
                if (v.contains("linear-gradient")) {
                    Matcher c2 = Pattern.compile("#[0-9a-fA-F]{3,8}").matcher(v);
                    String[] cols = new String[2];
                    int n = 0;
                    while (c2.find() && n < 2) cols[n++] = c2.group();
                    if (cols[0] != null) s.put("bgTop", cols[0]);
                    if (cols[1] != null) s.put("bgBottom", cols[1]);
                    if (cols[0] != null && cols[1] == null) s.put("bgBottom", cols[0]);
                } else {
                    String col = firstColor(v);
                    if (col != null) {
                        s.put("bgTop", col);
                        s.put("bgBottom", col);
                    }
                }
            } else if ("color".equals(k)) {
                String col = firstColor(v);
                if (col == null) continue;
                if (isTitle) s.put("titleColor", col);
                else if (isSub) s.put("subColor", col);
                else if (isTip) s.put("tipColor", col);
                else if (isFooter) s.put("footerColor", col);
                else {
                    s.put("titleColor", col);
                    s.put("subColor", col);
                    s.put("tipColor", col);
                    s.put("footerColor", col);
                }
            }
        }
    }

    private String firstColor(String v) {
        Matcher hex = Pattern.compile("#[0-9a-fA-F]{3,8}").matcher(v);
        if (hex.find()) return hex.group();
        Matcher rgb = Pattern.compile("rgb\\((\\d+)[^\\d]+(\\d+)[^\\d]+(\\d+)").matcher(v);
        if (rgb.find()) {
            try {
                return String.format(Locale.ROOT, "#%02X%02X%02X",
                        Integer.parseInt(rgb.group(1)), Integer.parseInt(rgb.group(2)), Integer.parseInt(rgb.group(3)));
            } catch (Throwable ignored) {
            }
        }
        return null;
    }

    private void openCode() {
        final EditText et = Ui.codeInput(ctx, Repo.pretty(wrap()));
        new AlertDialog.Builder(act)
                .setTitle("编辑开屏 JSON")
                .setMessage("字段说明见页尾对照卡；发布前可先「校验并应用」。")
                .setView(wrapCode(et))
                .setPositiveButton("校验并应用", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        applyJson(et.getText().toString());
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void applyJson(String text) {
        try {
            JSONObject o = new JSONObject(text);
            JSONObject in = o.optJSONObject("splash") != null ? o.optJSONObject("splash") : o;
            cfg = merge(in);
            paintPreview(previewBox);
            info("JSON 已应用");
        } catch (Throwable t) {
            info("JSON 解析失败：" + t.getMessage());
        }
    }

    private LinearLayout wrapCode(EditText et) {
        LinearLayout box = Ui.col(ctx);
        int pad = Ui.dp(ctx, 12);
        box.setPadding(pad, pad, pad, pad / 2);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 300));
        box.addView(et, elp);
        return box;
    }

    // ---------------- 数据 ----------------

    /** 组装带版本与时间戳的发布结构。 */
    private JSONObject wrap() {
        JSONObject o = new JSONObject();
        try {
            o.put("version", 1);
            o.put("updatedAt", Repo.today());
            o.put("splash", cfg());
        } catch (Throwable ignored) {
        }
        return o;
    }

    private void publish() {
        new AlertDialog.Builder(act)
                .setTitle("发布开屏配置")
                .setMessage("将当前开屏样式写入仓库 data/splash.json，工具箱下次启动生效。继续？")
                .setPositiveButton("发布", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        try {
                            byte[] data = Repo.pretty(wrap()).getBytes("UTF-8");
                            Repo.writeText(ctx, PATH, Repo.pretty(wrap()), "开屏配置已发布");
                            Repo.manifestTouch(ctx, PATH, data);
                            info("已发布，工具箱下次启动生效");
                        } catch (Throwable t) {
                            info("发布失败：" + t.getMessage());
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void pull() {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject remote = Repo.readJson(ctx, PATH);
                JSONObject sp = remote == null ? null
                        : (remote.optJSONObject("splash") != null ? remote.optJSONObject("splash") : remote);
                return sp == null ? null : Repo.pretty(sp);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    info("读取失败：" + err.getMessage());
                    return;
                }
                if (result == null) {
                    info("线上暂无开屏配置（保持当前编辑内容）");
                    return;
                }
                try {
                    cfg = merge(new JSONObject(result));
                    paintPreview(previewBox);
                    info("已读取线上配置");
                } catch (Throwable t) {
                    info("解析失败：" + t.getMessage());
                }
            }
        });
    }

    /** 远端为准，缺字段补默认。 */
    private static JSONObject merge(JSONObject remote) {
        JSONObject def = defaults();
        JSONObject out = defaults();
        if (remote == null) return out;
        for (String k : FIELDS) {
            try {
                if (remote.has(k)) out.put(k, remote.get(k));
                else out.put(k, def.opt(k));
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    // ---------------- 工具 ----------------

    private static String str(JSONObject s, String k, String def) {
        String v = s == null ? null : s.optString(k, def);
        return v == null || v.length() == 0 ? def : v;
    }

    private static boolean bool(JSONObject s, String k, boolean def) {
        return s == null ? def : s.optBoolean(k, def);
    }

    private static int i(JSONObject s, String k, int def) {
        try {
            return s.optInt(k, def);
        } catch (Throwable t) {
            return def;
        }
    }

    private static int color(String s, int def) {
        if (s == null || s.length() == 0) return def;
        try {
            String t = s.trim();
            if (!t.startsWith("#")) t = "#" + t;
            long v = Long.parseLong(t.substring(1), 16);
            if (t.length() == 7) v |= 0xFF000000L;
            return (int) v;
        } catch (Throwable ex) {
            return def;
        }
    }
}
