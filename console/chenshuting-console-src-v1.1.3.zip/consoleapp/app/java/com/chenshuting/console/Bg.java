package com.chenshuting.console;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.util.DisplayMetrics;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.VideoView;

import java.io.File;
import java.io.FileOutputStream;

/** 控制台全局背景：支持图片 / 视频（视频保留原声、循环、按屏幕裁切铺满），
 *  设置后当前界面立即刷新，下次启动自动应用。 */
public final class Bg {

    private static final String SP = "console_bg";
    private static final String K_TYPE = "type";
    private static final String K_NAME = "name";

    private Bg() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(SP, Context.MODE_PRIVATE);
    }

    public static String type(Context c) {
        return sp(c).getString(K_TYPE, "");
    }

    public static String name(Context c) {
        return sp(c).getString(K_NAME, "");
    }

    public static File file(Context c, String type) {
        return new File(c.getFilesDir(), "bg_" + type + ".dat");
    }

    public static boolean has(Context c) {
        String t = type(c);
        return t.length() > 0 && file(c, t).exists();
    }

    /** 选图片作为全局背景。 */
    public static void pickImage(final MainActivity act, final Runnable done) {
        act.pickFile("image/*", "bg_image.jpg", new MainActivity.PickCb() {
            @Override
            public void onPicked(String nm, byte[] data) {
                save(act, "image", nm, data);
                if (done != null) done.run();
            }

            @Override
            public void onFailed(String reason) {
                android.widget.Toast.makeText(act, reason, android.widget.Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** 选视频作为全局背景（带声音）。 */
    public static void pickVideo(final MainActivity act, final Runnable done) {
        act.pickFile("video/*", "bg_video.mp4", new MainActivity.PickCb() {
            @Override
            public void onPicked(String nm, byte[] data) {
                save(act, "video", nm, data);
                if (done != null) done.run();
            }

            @Override
            public void onFailed(String reason) {
                android.widget.Toast.makeText(act, reason, android.widget.Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static void save(Context c, String type, String name, byte[] data) {
        try {
            FileOutputStream out = new FileOutputStream(file(c, type));
            out.write(data);
            out.close();
            sp(c).edit().putString(K_TYPE, type).putString(K_NAME, name == null ? "" : name).apply();
        } catch (Throwable ignored) {
        }
    }

    /** 取消全局背景。 */
    public static void clear(Context c) {
        for (String t : new String[]{"image", "video"}) {
            File f = file(c, t);
            if (f.exists()) f.delete();
        }
        sp(c).edit().clear().apply();
    }

    /** 把背景铺到壳容器最底层（index 0）；未设置背景时不做事。 */
    public static void attach(Activity act, FrameLayout shell) {
        String t = type(act);
        if (t.length() == 0) return;
        File f = file(act, t);
        if (!f.exists()) return;
        if ("video".equals(t)) {
            final VideoView vv = new VideoView(act);
            vv.setVideoPath(f.getAbsolutePath());
            vv.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.setLooping(true);
                    mp.setVolume(1f, 1f);
                    crop(vv, mp);
                    vv.start();
                }
            });
            shell.addView(vv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            ImageView iv = new ImageView(act);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(BitmapFactory.decodeFile(f.getAbsolutePath()));
            shell.addView(iv, 0, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    /** 视频按 center-crop 铺满：等比放大到覆盖屏幕并居中裁切。 */
    private static void crop(VideoView vv, MediaPlayer mp) {
        int vw = mp.getVideoWidth();
        int vh = mp.getVideoHeight();
        if (vw <= 0 || vh <= 0) return;
        DisplayMetrics dm = vv.getResources().getDisplayMetrics();
        int sw = dm.widthPixels;
        int sh = dm.heightPixels;
        float scale = Math.max((float) sw / vw, (float) sh / vh);
        int w = (int) (vw * scale);
        int h = (int) (vh * scale);
        ViewGroup.LayoutParams lp = vv.getLayoutParams();
        lp.width = w;
        lp.height = h;
        vv.setLayoutParams(lp);
        vv.setX((sw - w) / 2f);
        vv.setY((sh - h) / 2f);
    }
}
