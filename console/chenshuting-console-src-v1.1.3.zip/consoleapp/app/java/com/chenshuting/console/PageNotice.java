package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 公告：欢迎语 + 24 小时轮播动态 + 时间/日期/星期/农历时钟 + 定时提醒 + 跑马灯特效。
 *  走独立实时通道（约 1 分钟生效，无需发版）。 */
public class PageNotice extends Page {

    private Switch swEnabled;
    private Switch swLoop;
    private Switch swClock;
    private Switch swFx;
    private EditText inWelcome;
    private LinearLayout itemsHost;
    private LinearLayout timedHost;
    private TextView status;
    private final List<EditText> itemInputs = new ArrayList<EditText>();
    private final List<EditText> timedInputs = new ArrayList<EditText>();

    private int clockStyle = 1;   // 0=仅时分秒 1=日期+时分秒 2=完整(日期/星期/农历/阴历)
    private int fxSpeed = 2;      // 1=慢 2=中 3=快
    private int fxDir = 0;        // 0=右→左 1=左→右

    public PageNotice(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "公告"));
        Tutorial.add(body, ctx, "公告页 · 怎么用", new String[]{
                "开关：顶部总开关关掉后，App 首页不再显示跑马灯（配置仍保留，随时可再开）。",
                "欢迎语：单独一行，显示在跑马灯最前面，适合放节日问候或版本提示。",
                "动态条：每条一行，支持多行新增/删除，顺序即滚动顺序；建议每条不超过 30 字。",
                "24 小时轮播：开启动态按时间无限循环；配合定时提醒可在早八点弹「记得吃早餐哟」。",
                "时钟：开关后跑马灯末尾显示 时:分:秒 / 日期 / 星期 / 农历 / 阴历（由本体计算）。",
                "特效：跑马灯支持开/关、速度（慢/中/快）与方向（左→右 / 右→左）。",
                "发布：点发布即写仓库 data/announcements.json，独立通道约 1 分钟生效。"});
        body.addView(Ui.sub(ctx, "App 首页跑马灯：欢迎语 + 动态 + 时钟 + 定时提醒，支持 24 小时轮播与特效。"));
        Ui.add(body, Ui.sub(ctx, "本通道独立于内容清单，发布后约 1 分钟生效。"), 2);

        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "开关"));
        swEnabled = new Switch(ctx);
        swEnabled.setText("启用滚动动态");
        swEnabled.setTextColor(Theme.TEXT);
        swEnabled.setTextSize(13f);
        swEnabled.setChecked(true);
        c1.addView(swEnabled);
        swLoop = new Switch(ctx);
        swLoop.setText("24 小时不间断轮播");
        swLoop.setTextColor(Theme.TEXT);
        swLoop.setTextSize(13f);
        swLoop.setChecked(false);
        c1.addView(swLoop);
        swClock = new Switch(ctx);
        swClock.setText("显示时钟（时间 / 日期 / 星期 / 农历）");
        swClock.setTextColor(Theme.TEXT);
        swClock.setTextSize(13f);
        swClock.setChecked(false);
        c1.addView(swClock);
        swFx = new Switch(ctx);
        swFx.setText("跑马灯文字特效");
        swFx.setTextColor(Theme.TEXT);
        swFx.setTextSize(13f);
        swFx.setChecked(true);
        c1.addView(swFx);
        Ui.add(body, c1, 12);

        LinearLayout c1b = Ui.card(ctx);
        c1b.addView(Ui.section(ctx, "时钟 / 特效设置"));
        c1b.addView(Ui.sub(ctx, "时钟显示内容"));
        LinearLayout styleRow = Ui.row(ctx);
        TextView[] styleBtns = new TextView[3];
        String[] styleNames = {"时:分:秒", "日期+时分秒", "完整含农历"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView b = Ui.btn(ctx, styleNames[i], i == clockStyle);
            styleRow.addView(b);
            if (i > 0) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.leftMargin = Ui.dp(ctx, 6);
                b.setLayoutParams(lp);
            }
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clockStyle = idx;
                    info("时钟样式：已选「" + styleNames[idx] + "」，发布后生效");
                    act.recreate();
                }
            });
            styleBtns[i] = b;
        }
        Ui.add(c1b, styleRow, 8);
        c1b.addView(Ui.sub(ctx, "跑马灯速度 / 方向"));
        LinearLayout fxRow = Ui.row(ctx);
        final TextView[] speedBtns = new TextView[3];
        String[] speedNames = {"慢", "中", "快"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView b = Ui.btn(ctx, speedNames[i], i + 1 == fxSpeed);
            fxRow.addView(b);
            if (i > 0) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.leftMargin = Ui.dp(ctx, 6);
                b.setLayoutParams(lp);
            }
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    fxSpeed = idx + 1;
                    info("特效速度：已选「" + speedNames[idx] + "」，发布后生效");
                    act.recreate();
                }
            });
            speedBtns[i] = b;
        }
        Ui.add(c1b, fxRow, 8);
        LinearLayout dirRow = Ui.row(ctx);
        TextView bL = Ui.btn(ctx, "右→左", fxDir == 0);
        bL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fxDir = 0;
                info("方向：右→左，发布后生效");
                act.recreate();
            }
        });
        dirRow.addView(bL);
        TextView bR = Ui.btn(ctx, "左→右", fxDir == 1);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.leftMargin = Ui.dp(ctx, 6);
        dirRow.addView(bR, rp);
        bR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fxDir = 1;
                info("方向：左→右，发布后生效");
                act.recreate();
            }
        });
        Ui.add(c1b, dirRow, 8);
        Ui.add(body, c1b, 12);

        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "欢迎语"));
        inWelcome = Ui.input(ctx, "欢迎语", true, "");
        Ui.add(c2, inWelcome, 4);
        Ui.add(body, c2, 10);

        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "滚动动态"));
        itemsHost = Ui.col(ctx);
        c3.addView(itemsHost);
        TextView add = Ui.btn(ctx, "添加一条", false);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> cur = currentItems();
                cur.add("");
                fillItems(cur);
            }
        });
        Ui.add(c3, add, 8);
        Ui.add(body, c3, 10);

        LinearLayout c4 = Ui.card(ctx);
        c4.addView(Ui.section(ctx, "定时提醒（24 小时轮播配合使用）"));
        c4.addView(Ui.sub(ctx, "格式：HH:mm + 文案，如 08:00 早上八点，记得吃早餐哟，上班路上注意安全"));
        timedHost = Ui.col(ctx);
        c4.addView(timedHost);
        TextView addT = Ui.btn(ctx, "添加定时提醒", false);
        addT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> cur = currentTimed();
                cur.add("08:00|");
                fillTimed(cur);
            }
        });
        Ui.add(c4, addT, 8);
        Ui.add(body, c4, 10);

        TextView pub = Ui.btn(ctx, "发布公告", true);
        pub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmPublish();
            }
        });
        Ui.add(body, pub, 12);

        status = Ui.tv(ctx, "正在读取线上公告…", 12f, Theme.SUB, false);
        Ui.add(body, status, 10);
        load();
    }

    private void load() {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                return Repo.readText(ctx, Repo.P_NOTICE);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "读取失败：" + err.getMessage());
                    return;
                }
                boolean enabled = true;
                boolean loop = false;
                boolean clock = false;
                boolean fx = true;
                int cStyle = 1;
                int speed = 2;
                int dir = 0;
                String welcome = "";
                List<String> items = new ArrayList<String>();
                List<String> timed = new ArrayList<String>();
                try {
                    if (result != null && result.trim().length() > 0) {
                        JSONObject o = new JSONObject(result);
                        enabled = o.optBoolean("enabled", true);
                        loop = o.optBoolean("loop24h", false);
                        clock = o.optBoolean("showClock", false);
                        fx = o.optBoolean("marqueeFx", true);
                        cStyle = o.optInt("clockStyle", 1);
                        speed = o.optInt("marqueeSpeed", 2);
                        dir = o.optInt("marqueeDir", 0);
                        welcome = o.optString("welcome", "");
                        JSONArray arr = o.optJSONArray("items");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) items.add(arr.optString(i, ""));
                        }
                        JSONArray ta = o.optJSONArray("timed");
                        if (ta != null) {
                            for (int i = 0; i < ta.length(); i++) {
                                JSONObject to = ta.optJSONObject(i);
                                if (to != null) timed.add(to.optString("time", "") + "|" + to.optString("text", ""));
                            }
                        }
                    }
                } catch (Throwable ignored) {
                }
                if (result == null) {
                    act.setText(status, "线上暂无公告文件，发布后将自动创建");
                } else {
                    act.setText(status, "已载入线上公告 · " + Repo.today());
                }
                swEnabled.setChecked(enabled);
                swLoop.setChecked(loop);
                swClock.setChecked(clock);
                swFx.setChecked(fx);
                clockStyle = cStyle;
                fxSpeed = speed;
                fxDir = dir;
                inWelcome.setText(welcome);
                fillItems(items);
                fillTimed(timed);
            }
        });
    }

    private void fillItems(List<String> items) {
        itemsHost.removeAllViews();
        itemInputs.clear();
        for (int i = 0; i < items.size(); i++) {
            final EditText e = Ui.input(ctx, "第 " + (i + 1) + " 条动态", false, items.get(i));
            itemInputs.add(e);
            LinearLayout r = Ui.row(ctx);
            r.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView del = Ui.btn(ctx, "删除", false);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dp.leftMargin = Ui.dp(ctx, 8);
            del.setLayoutParams(dp);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    List<String> cur = currentItems();
                    int idx = itemInputs.indexOf(e);
                    if (idx >= 0 && idx < cur.size()) cur.remove(idx);
                    fillItems(cur);
                }
            });
            r.addView(del);
            Ui.add(itemsHost, r, 6);
        }
        if (items.isEmpty()) {
            itemsHost.addView(Ui.sub(ctx, "暂无动态条目，点「添加一条」新增"));
        }
    }

    private void fillTimed(List<String> timed) {
        timedHost.removeAllViews();
        timedInputs.clear();
        for (int i = 0; i < timed.size(); i++) {
            String s = timed.get(i);
            int sep = s.indexOf('|');
            String t = sep >= 0 ? s.substring(0, sep) : s;
            String txt = sep >= 0 ? s.substring(sep + 1) : "";
            final EditText eT = Ui.input(ctx, "HH:mm", false, t);
            final EditText eX = Ui.input(ctx, "提醒文案", false, txt);
            timedInputs.add(eT);
            timedInputs.add(eX);
            LinearLayout r = Ui.row(ctx);
            r.addView(eT, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.32f));
            LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            xp.leftMargin = Ui.dp(ctx, 6);
            r.addView(eX, xp);
            TextView del = Ui.btn(ctx, "删除", false);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dp.leftMargin = Ui.dp(ctx, 6);
            del.setLayoutParams(dp);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    List<String> cur = currentTimed();
                    int idx = timedInputs.indexOf(eT);
                    if (idx >= 0) {
                        int pair = idx / 2;
                        if (pair < cur.size()) cur.remove(pair);
                    }
                    fillTimed(cur);
                }
            });
            r.addView(del);
            Ui.add(timedHost, r, 6);
        }
        if (timed.isEmpty()) {
            timedHost.addView(Ui.sub(ctx, "暂无定时提醒，点「添加定时提醒」新增"));
        }
    }

    private List<String> currentItems() {
        List<String> out = new ArrayList<String>();
        for (EditText e : itemInputs) out.add(e.getText().toString().trim());
        return out;
    }

    private List<String> currentTimed() {
        List<String> out = new ArrayList<String>();
        for (int i = 0; i + 1 < timedInputs.size(); i += 2) {
            out.add(timedInputs.get(i).getText().toString().trim() + "|"
                    + timedInputs.get(i + 1).getText().toString().trim());
        }
        return out;
    }

    private void confirmPublish() {
        final boolean enabled = swEnabled.isChecked();
        final boolean loop = swLoop.isChecked();
        final boolean clock = swClock.isChecked();
        final boolean fx = swFx.isChecked();
        final String welcome = inWelcome.getText().toString().trim();
        final List<String> items = new ArrayList<String>();
        for (String s : currentItems()) {
            if (s.length() > 0) items.add(s);
        }
        final List<String> timed = new ArrayList<String>();
        for (String s : currentTimed()) {
            int sep = s.indexOf('|');
            String t = sep >= 0 ? s.substring(0, sep).trim() : "";
            String txt = sep >= 0 ? s.substring(sep + 1).trim() : "";
            if (t.length() > 0 && txt.length() > 0 && t.matches("\\d{1,2}:\\d{2}")) timed.add(t + "|" + txt);
        }
        if (welcome.length() == 0 && items.isEmpty() && timed.isEmpty()) {
            info("欢迎语 / 动态 / 定时提醒不能同时为空");
            return;
        }
        String preview = "启用：" + (enabled ? "是" : "否")
                + "\n24 小时轮播：" + (loop ? "开" : "关")
                + "\n时钟：" + (clock ? "开（" + clockStyleName() + "）" : "关")
                + "\n特效：" + (fx ? "开（" + speedName() + "，" + (fxDir == 0 ? "右→左" : "左→右") + "）" : "关")
                + "\n动态条数：" + items.size()
                + "\n定时提醒：" + timed.size() + " 条"
                + "\n欢迎语：" + (welcome.length() > 40 ? welcome.substring(0, 40) + "…" : welcome);
        new AlertDialog.Builder(act)
                .setTitle("确认发布公告")
                .setMessage(preview + "\n\n发布后约 1 分钟内在 App 首页跑马灯生效。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认发布", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        doPublish(enabled, loop, clock, fx, welcome, items, timed);
                    }
                })
                .show();
    }

    private String clockStyleName() {
        return clockStyle == 0 ? "时:分:秒" : (clockStyle == 1 ? "日期+时分秒" : "完整含农历");
    }

    private String speedName() {
        return fxSpeed == 1 ? "慢" : (fxSpeed == 3 ? "快" : "中");
    }

    private void doPublish(final boolean enabled, final boolean loop, final boolean clock, final boolean fx,
                           final String welcome, final List<String> items, final List<String> timed) {
        act.setText(status, "正在发布公告…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject o = new JSONObject();
                o.put("enabled", enabled);
                o.put("welcome", welcome);
                o.put("loop24h", loop);
                o.put("showClock", clock);
                o.put("clockStyle", clockStyle);
                o.put("marqueeFx", fx);
                o.put("marqueeSpeed", fxSpeed);
                o.put("marqueeDir", fxDir);
                JSONArray arr = new JSONArray();
                for (String s : items) arr.put(s);
                o.put("items", arr);
                JSONArray ta = new JSONArray();
                for (String s : timed) {
                    int sep = s.indexOf('|');
                    JSONObject to = new JSONObject();
                    to.put("time", sep >= 0 ? s.substring(0, sep) : s);
                    to.put("text", sep >= 0 ? s.substring(sep + 1) : "");
                    ta.put(to);
                }
                o.put("timed", ta);
                Repo.publishNotice(ctx, o);
                return "公告已发布（" + items.size() + " 条动态，" + timed.size() + " 条定时提醒）";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + err.getMessage());
                    log("公告发布失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result + " · " + Repo.today());
                log("公告已发布（" + items.size() + " 条动态，" + timed.size() + " 条定时提醒）");
                act.badge("公告已更新", Theme.OK);
            }
        });
    }
}
