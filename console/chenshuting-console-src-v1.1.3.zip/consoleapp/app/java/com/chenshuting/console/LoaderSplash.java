package com.chenshuting.console;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 开屏 Loader（对应 Uiverse.io by SelfMadeSystem 的 SVG dash 动画 + spin）：
 *  新拟态淡粉渐变底 + 双环（外环玫瑰金 2s 扫圈 dash / 内环粉紫 2s dash 呼吸 + 8s 旋转 1080°）+ 品牌字。 */
public final class LoaderSplash extends FrameLayout {

    private static final long TOTAL_MS = 1700L;

    private final DashRing outer;
    private final DashRing inner;

    private LoaderSplash(Context c) {
        super(c);
        setBackground(Ui.softBg(c));

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(android.view.Gravity.CENTER);
        box.setPadding(0, 0, 0, 0);

        FrameLayout rings = new FrameLayout(c);
        outer = new DashRing(c, 46, 3f, Theme.GOLD, false);
        inner = new DashRing(c, 30, 2.5f, 0xFFC9B6F5, true);
        rings.addView(outer, new FrameLayout.LayoutParams(Ui.dp(c, 110), Ui.dp(c, 110)));
        rings.addView(inner, new FrameLayout.LayoutParams(Ui.dp(c, 110), Ui.dp(c, 110)));
        box.addView(rings, new LinearLayout.LayoutParams(Ui.dp(c, 110), Ui.dp(c, 110)));

        TextView title = Ui.tv(c, "淑婷控制台", 19f, Theme.TEXT, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(c, 26);
        box.addView(title, tlp);

        TextView sub = Ui.tv(c, "内容发布 · 云端管理", 12f, Theme.SUB, false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Ui.dp(c, 8);
        box.addView(sub, slp);

        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = android.view.Gravity.CENTER;
        addView(box, lp);
    }

    /** 展示开屏：约 1.7 秒后淡出并回调。 */
    public static void show(final Activity a, final Runnable onDone) {
        final LoaderSplash s = new LoaderSplash(a);
        final FrameLayout root = (FrameLayout) a.getWindow().getDecorView();
        root.addView(s, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        s.postDelayed(new Runnable() {
            @Override
            public void run() {
                s.animate().alpha(0f).setDuration(320).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        root.removeView(s);
                        if (onDone != null) onDone.run();
                    }
                }).start();
            }
        }, TOTAL_MS);
    }

    /** 双环 dash 动画：外环 2s 扫圈，内环 2s dash 呼吸 + 8s 旋转三圈。 */
    private static class DashRing extends View {

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF arc = new RectF();
        private final float r;
        private final boolean spin;
        private final ValueAnimator dash;
        private final ValueAnimator rot;
        private float sweep = 240f;
        private float start = -90f;

        DashRing(Context c, float radiusDp, float strokeDp, int color, boolean spin) {
            super(c);
            r = Ui.dp(c, radiusDp);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(c, strokeDp));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(color);
            this.spin = spin;

            dash = ValueAnimator.ofFloat(0f, 1f);
            dash.setDuration(2000L);
            dash.setRepeatCount(ValueAnimator.INFINITE);
            dash.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    float p = (Float) a.getAnimatedValue();
                    sweep = spin ? 270f + 90f * (0.5f - 0.5f * (float) Math.cos(p * Math.PI * 2))
                            : 50f + 60f * (0.5f - 0.5f * (float) Math.cos(p * Math.PI * 2));
                    if (!spin) {
                        // 外环扫圈：整个 2s 周期转一圈
                        start = -90f + 360f * p;
                    }
                    invalidate();
                }
            });
            dash.start();

            if (spin) {
                rot = ValueAnimator.ofFloat(0f, 1080f);
                rot.setDuration(8000L);
                rot.setRepeatCount(ValueAnimator.INFINITE);
                rot.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator a) {
                        start = -90f + (Float) a.getAnimatedValue();
                        invalidate();
                    }
                });
                rot.start();
            } else {
                rot = null;
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            arc.set(cx - r, cy - r, cx + r, cy + r);
            canvas.drawArc(arc, start, sweep, false, paint);
        }

        @Override
        protected void onDetachedFromWindow() {
            if (dash != null) dash.cancel();
            if (rot != null) rot.cancel();
            super.onDetachedFromWindow();
        }
    }
}
