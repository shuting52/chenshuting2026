package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** 本体全局功能管理：每个功能（应用名 / 图标 / 官网 / 置顶文案 / 首页布局 / 自定义项）都能被
 *  单独识别、定位、修改、删除；图标支持上传本地图片直达仓库直链。
 *  配置写入仓库 data/config.json，本体 1 分钟内自动拉取生效，用户无需更新 APK。 */
public class PageGlobal extends Page {

    private static final String PATH = "data/config.json";
    private static final String ICON_PATH = "data/icon.png";

    /** 单个功能项。 */
    private static class Feature {
        String key;      // 配置键（texts.xxx 归入 texts 节点）
        String label;    // 展示名
        String desc;     // 说明
        String value;    // 当前值
        boolean builtin; // 内置功能删除=恢复默认（不写入）
    }

    private final List<Feature> features = new ArrayList<Feature>();
    private LinearLayout listBox;
    private TextView status;
    private TextView bgNow;

    public PageGlobal(MainActivity a) {
        super(a);
        seedBuiltin();
    }

    /** 内置功能清单（展示顺序即管理顺序）。 */
    private void seedBuiltin() {
        features.clear();
        add("appName", "应用名", "工具箱显示名称（顶栏 / 关于页）", "");
        add("iconUrl", "应用图标", "http 图片直链；可上传本地图片自动生成", "");
        add("officialUrl", "官方网站", "首页官方入口地址", "");
        add("texts.official_title", "官网卡片标题", "首页官方网站卡片标题", "");
        add("texts.official_sub", "官网卡片副标题", "首页官方网站卡片副标题", "");
        add("texts.update_hint", "更新提示文字", "更新弹窗点「立即更新」后的提示语", "");
        add("homeLayout", "首页布局", "card=卡片（默认）/ compact=紧凑", "");
    }

    private void add(String key, String label, String desc, String value) {
        Feature f = new Feature();
        f.key = key;
        f.label = label;
        f.desc = desc;
        f.value = value;
        f.builtin = true;
        features.add(f);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "本体全局 · 功能管理"));
        body.addView(Ui.sub(ctx, "每个功能单独一行，点「修改」调整、点「删除」移除（内置功能删除即恢复默认，不写入线上）；"
                + "支持添加自定义功能项，发布后本体自动同步。"));

        LinearLayout top = Ui.card(ctx);
        top.addView(Ui.section(ctx, "管理操作"));
        LinearLayout r0 = Ui.row(ctx);
        TextView bAdd = Ui.btn(ctx, "新增功能", false);
        bAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFeature();
            }
        });
        r0.addView(bAdd);
        TextView bIcon = Ui.btn(ctx, "上传应用图标", true);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ilp.leftMargin = Ui.dp(ctx, 8);
        r0.addView(bIcon, ilp);
        bIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadIcon();
            }
        });
        Ui.add(top, r0, 10);
        top.addView(Ui.sub(ctx, "图标上传后自动发布到 data/icon.png，并把直链写入「应用图标」功能项"));
        Ui.add(body, top, 12);

        LinearLayout listCard = Ui.card(ctx);
        listCard.addView(Ui.section(ctx, "功能列表"));
        listCard.addView(Ui.sub(ctx, "绿色圆点=已配置，灰色=未配置/默认"));
        listBox = Ui.col(ctx);
        Ui.add(listCard, listBox, 8);
        Ui.add(body, listCard, 12);

        LinearLayout c4 = Ui.card(ctx);
        c4.addView(Ui.section(ctx, "控制台背景（图 / 视频）"));
        c4.addView(Ui.sub(ctx, "界面主题：新拟态（默认）；可用下面的图片 / 视频覆盖为自定义背景"));
        bgNow = Ui.tv(ctx, bgText(), 12f, Theme.SUB, false);
        Ui.add(c4, bgNow, 6);
        LinearLayout r1 = Ui.row(ctx);
        TextView bImg = Ui.btn(ctx, "上传图片背景", false);
        bImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bg.pickImage(act, new Runnable() {
                    @Override
                    public void run() {
                        info("图片背景已应用，界面已刷新");
                        act.recreate();
                    }
                });
            }
        });
        r1.addView(bImg);
        TextView bVid = Ui.btn(ctx, "上传视频背景", false);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        vlp.leftMargin = Ui.dp(ctx, 8);
        r1.addView(bVid, vlp);
        bVid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bg.pickVideo(act, new Runnable() {
                    @Override
                    public void run() {
                        info("视频背景已应用（带声音），界面已刷新");
                        act.recreate();
                    }
                });
            }
        });
        Ui.add(c4, r1, 6);
        TextView bClr = Ui.btn(ctx, "取消背景", false);
        Ui.add(c4, bClr, 6);
        bClr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bg.clear(ctx);
                info("已取消自定义背景");
                act.recreate();
            }
        });
        Ui.add(body, c4, 12);

        LinearLayout bar = Ui.row(ctx);
        TextView pull = Ui.btn(ctx, "从线上读取", false);
        pull.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                load();
            }
        });
        bar.addView(pull);
        TextView push = Ui.btn(ctx, "发布到本体", true);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        plp.leftMargin = Ui.dp(ctx, 8);
        bar.addView(push, plp);
        push.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publish();
            }
        });
        Ui.add(body, bar, 8);

        status = Ui.tv(ctx, "待发布", 12f, Theme.SUB, false);
        Ui.add(body, status, 8);

        rebuildList();
        load();
    }

    private String bgText() {
        if (!Bg.has(ctx)) return "当前未设置自定义背景";
        return "当前背景：" + ("video".equals(Bg.type(ctx)) ? "视频" : "图片") + "（" + Bg.name(ctx) + "）";
    }

    // ---------------- 功能列表 UI ----------------

    private void rebuildList() {
        listBox.removeAllViews();
        for (int i = 0; i < features.size(); i++) {
            final Feature f = features.get(i);
            LinearLayout row = Ui.row(ctx);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6));

            View dot = new View(ctx);
            boolean on = f.value != null && f.value.length() > 0;
            dot.setBackground(Ui.bg(ctx, on ? Theme.OK : Theme.STROKE, 5, 0, 0));
            row.addView(dot, new LinearLayout.LayoutParams(Ui.dp(ctx, 10), Ui.dp(ctx, 10)));

            LinearLayout mid = Ui.col(ctx);
            LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            mlp.leftMargin = Ui.dp(ctx, 8);
            row.addView(mid, mlp);

            TextView name = Ui.tv(ctx, f.label, 13f, Theme.TEXT, true);
            mid.addView(name);
            TextView desc = Ui.tv(ctx, f.desc + "（" + f.key + "）", 11f, Theme.SUB, false);
            Ui.add(mid, desc, 2);
            String summary = f.value == null || f.value.length() == 0 ? "未配置 / 默认"
                    : (f.value.length() > 26 ? f.value.substring(0, 26) + "…" : f.value);
            TextView val = Ui.tv(ctx, "值：" + summary, 11f, on ? Theme.GOLD_LIGHT : Theme.SUB, false);
            Ui.add(mid, val, 2);

            TextView bMod = Ui.btn(ctx, "修改", false);
            row.addView(bMod);
            bMod.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editFeature(f);
                }
            });
            TextView bDel = Ui.btn(ctx, "删除", false);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            dlp.leftMargin = Ui.dp(ctx, 6);
            row.addView(bDel, dlp);
            bDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    removeFeature(f);
                }
            });
            Ui.add(listBox, row, 4);
        }
    }

    private void editFeature(final Feature f) {
        final EditText et = Ui.input(ctx, "输入新值", true, f.value);
        LinearLayout box = Ui.col(ctx);
        int pad = Ui.dp(ctx, 12);
        box.setPadding(pad, pad, pad, pad / 2);
        box.addView(et, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(act)
                .setTitle("修改 · " + f.label)
                .setMessage(f.key)
                .setView(box)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        f.value = et.getText().toString().trim();
                        rebuildList();
                        info("已修改「" + f.label + "」，记得点发布");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void removeFeature(final Feature f) {
        new AlertDialog.Builder(act)
                .setTitle("删除功能 · " + f.label)
                .setMessage(f.builtin
                        ? "内置功能删除=恢复默认：发布后该字段不再写入线上，本体回退出厂默认值。"
                        : "删除后该功能将从线上配置移除（本体回退默认）。确定继续？")
                .setPositiveButton("删除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        if (f.builtin) {
                            f.value = "";
                        } else {
                            features.remove(f);
                        }
                        rebuildList();
                        info(f.builtin ? "已恢复默认（发布后生效）" : "已删除该功能，记得点发布");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void addFeature() {
        LinearLayout box = Ui.col(ctx);
        int pad = Ui.dp(ctx, 12);
        box.setPadding(pad, pad, pad, pad / 2);
        final EditText eKey = Ui.input(ctx, "功能键名（如 github、hotline）", false, "");
        box.addView(eKey, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        final EditText eVal = Ui.input(ctx, "功能值（文本）", false, "");
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        vp.topMargin = Ui.dp(ctx, 8);
        box.addView(eVal, vp);
        new AlertDialog.Builder(act)
                .setTitle("新增功能")
                .setMessage("键名支持字母 / 数字 / 点 / 下划线 / 横线，以 texts. 开头会归入文案节点")
                .setView(box)
                .setPositiveButton("添加", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String k = eKey.getText().toString().trim();
                        String v = eVal.getText().toString().trim();
                        if (k.length() == 0 || !k.matches("[A-Za-z0-9._-]+")) {
                            info("键名不合法：只能使用字母 / 数字 / . _ -");
                            return;
                        }
                        if (v.length() == 0) {
                            info("值为空，未添加");
                            return;
                        }
                        Feature f = new Feature();
                        f.key = k;
                        f.label = k;
                        f.desc = "自定义功能";
                        f.value = v;
                        f.builtin = false;
                        features.add(f);
                        rebuildList();
                        info("已添加「" + k + "」，记得点发布");
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ---------------- 图标上传 ----------------

    private void uploadIcon() {
        act.pickFile("image/*", "icon.png", new MainActivity.PickCb() {
            @Override
            public void onPicked(String name, byte[] data) {
                if (data == null || data.length == 0) {
                    info("读取图片失败：文件为空");
                    return;
                }
                try {
                    Bitmap src = BitmapFactory.decodeByteArray(data, 0, data.length);
                    if (src == null) {
                        info("不是可识别的图片格式");
                        return;
                    }
                    int size = Math.max(src.getWidth(), src.getHeight());
                    int target = 256;
                    if (size > target) {
                        float scale = target / (float) size;
                        Bitmap small = Bitmap.createScaledBitmap(src,
                                Math.max(1, Math.round(src.getWidth() * scale)),
                                Math.max(1, Math.round(src.getHeight() * scale)), true);
                        if (small != src) src.recycle();
                        src = small;
                    }
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    src.compress(Bitmap.CompressFormat.PNG, 100, bos);
                    final byte[] png = bos.toByteArray();
                    src.recycle();
                    if (png.length == 0) {
                        info("图片压缩失败");
                        return;
                    }
                    act.setText(status, "正在上传图标…");
                    Ui.run(act, new Ui.Job() {
                        @Override
                        public String run() throws Exception {
                            Repo.writeBytes(ctx, ICON_PATH, png, "icon: 上传应用图标");
                            return Repo.rawUrl(ctx, ICON_PATH);
                        }
                    }, new Ui.Done() {
                        @Override
                        public void done(String result, Throwable err) {
                            if (err != null) {
                                act.setText(status, "图标上传失败：" + (err.getMessage() == null ? "" : err.getMessage()));
                                return;
                            }
                            for (Feature f : features) {
                                if ("iconUrl".equals(f.key)) {
                                    f.value = result;
                                    break;
                                }
                            }
                            rebuildList();
                            act.setText(status, "图标已上传（" + (png.length / 1024) + "KB），直链已写入「应用图标」，点发布生效");
                        }
                    });
                } catch (Throwable t) {
                    info("图标处理失败：" + t.getMessage());
                }
            }

            @Override
            public void onFailed(String reason) {
                info("图标上传未完成：" + reason);
            }
        });
    }

    // ---------------- 数据操作 ----------------

    private void load() {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                return Repo.readText(ctx, PATH);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "读取失败：" + (err.getMessage() == null ? "" : err.getMessage()));
                    return;
                }
                try {
                    seedBuiltin();
                    JSONObject o = new JSONObject(result == null ? "{}" : result);
                    for (Feature f : features) {
                        if (f.key.startsWith("texts.")) {
                            JSONObject t = o.optJSONObject("texts");
                            f.value = t == null ? "" : t.optString(f.key.substring(6), "");
                        } else {
                            f.value = o.optString(f.key, "");
                        }
                    }
                    // 未知字段作为自定义功能列出，便于识别与管理
                    Iterator<String> it = o.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        if ("texts".equals(k) || "version".equals(k) || "updatedAt".equals(k)) continue;
                        if (hasKey(k)) continue;
                        Object v = o.opt(k);
                        Feature f = new Feature();
                        f.key = k;
                        f.label = k;
                        f.desc = "线上已有功能";
                        f.value = v == null ? "" : String.valueOf(v);
                        f.builtin = false;
                        features.add(f);
                    }
                    JSONObject t = o.optJSONObject("texts");
                    if (t != null) {
                        Iterator<String> it2 = t.keys();
                        while (it2.hasNext()) {
                            String k = it2.next();
                            if (hasKey("texts." + k)) continue;
                            Object v = t.opt(k);
                            Feature f = new Feature();
                            f.key = "texts." + k;
                            f.label = k;
                            f.desc = "线上已有文案功能";
                            f.value = v == null ? "" : String.valueOf(v);
                            f.builtin = false;
                            features.add(f);
                        }
                    }
                    rebuildList();
                    act.setText(status, "已读取线上配置");
                } catch (Throwable e) {
                    act.setText(status, "线上配置解析失败：" + e.getMessage());
                }
            }
        });
    }

    private boolean hasKey(String k) {
        for (Feature f : features) {
            if (f.key.equals(k)) return true;
        }
        return false;
    }

    private void publish() {
        final JSONObject o = new JSONObject();
        try {
            JSONObject t = new JSONObject();
            for (Feature f : features) {
                if (f.value == null || f.value.length() == 0) continue; // 空值=删除/恢复默认
                if (f.key.startsWith("texts.")) {
                    t.put(f.key.substring(6), f.value);
                } else {
                    o.put(f.key, f.value);
                }
            }
            if (t.length() > 0) o.put("texts", t);
        } catch (Throwable e) {
            info("配置组装失败：" + e.getMessage());
            return;
        }
        act.setText(status, "开始发布…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                Repo.writeText(ctx, PATH, Repo.pretty(o), "config: 本体全局配置更新");
                return Repo.readText(ctx, PATH);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + (err.getMessage() == null ? "" : err.getMessage()));
                    return;
                }
                act.setText(status, "已发布，本体 1 分钟内同步生效");
                act.badge("本体配置已发布", Theme.OK);
                log("本体全局配置发布完成");
            }
        });
    }
}
