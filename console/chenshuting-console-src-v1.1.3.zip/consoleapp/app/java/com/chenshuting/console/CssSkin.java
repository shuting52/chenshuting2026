package com.chenshuting.console;

import org.json.JSONObject;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 弹窗 CSS 子集解析器：把用户粘贴的 CSS 代码翻译成 dialogs.json 皮肤字段。
 *  支持常见属性：background(-color)、color、border-radius、padding、border(-color/-width)、
 *  font-size、width(%)、text-align、box-shadow 简化；选择器含 title/body 的块分别映射标题/正文色。
 *  解析结果同时保留原始 CSS 到场景的 css 字段（供回显与再编辑）。 */
public final class CssSkin {

    private CssSkin() {
    }

    /** 把一段 CSS 应用到场景 JSON；成功返回 null，失败返回原因。 */
    public static String apply(String cssText, JSONObject scene) {
        if (cssText == null || cssText.trim().length() == 0) {
            return "CSS 内容为空";
        }
        try {
            applyInner(cssText, scene);
            scene.put("css", cssText.trim());
            return null;
        } catch (Throwable t) {
            return t.getMessage() == null ? "解析失败" : t.getMessage();
        }
    }

    private static void applyInner(String css, JSONObject s) throws Exception {
        // 逐块解析 selector { ... }
        Pattern block = Pattern.compile("([^{}]+)\\{([^{}]*)\\}");
        Matcher m = block.matcher(css);
        boolean any = false;
        while (m.find()) {
            String sel = m.group(1).trim().toLowerCase(Locale.ROOT);
            String body = m.group(2);
            applyBlock(sel, body, s);
            any = true;
        }
        if (!any) {
            // 没有标准块：当作整体规则体直接解析
            applyBlock("", css, s);
        }
    }

    private static void applyBlock(String sel, String body, JSONObject s) throws Exception {
        boolean isTitle = sel.contains("title") || sel.contains("h1") || sel.contains("h2");
        boolean isBody = sel.contains("body") || sel.contains("p") || sel.contains("text") || sel.contains("content");
        boolean isBtn = sel.contains("button") || sel.contains("btn") || sel.contains("ok");
        boolean global = sel.length() == 0 || sel.contains("dialog") || sel.contains("card") || sel.contains(".root");

        Matcher pm = Pattern.compile("([a-zA-Z-]+)\\s*:\\s*([^;]+);?").matcher(body);
        while (pm.find()) {
            String k = pm.group(1).trim().toLowerCase(Locale.ROOT);
            String v = pm.group(2).trim();
            if (v.length() == 0) continue;
            if ("background".equals(k) || "background-color".equals(k)) {
                String col = firstColor(v);
                if (col != null) {
                    s.put("bgStyle", "solid");
                    s.put("bgColor", col);
                }
            } else if ("color".equals(k)) {
                String col = firstColor(v);
                if (col == null) continue;
                if (isBtn) {
                    s.put("btnPrimaryTextColor", col);
                } else if (isTitle) {
                    s.put("titleColor", col);
                } else if (isBody) {
                    s.put("bodyColor", col);
                } else {
                    s.put("titleColor", col);
                    s.put("bodyColor", col);
                }
            } else if ("border-radius".equals(k)) {
                Float f = firstNum(v);
                if (f != null) s.put("radiusDp", f);
            } else if ("padding".equals(k)) {
                Float f = firstNum(v);
                if (f != null) s.put("padDp", f);
            } else if ("border".equals(k)) {
                String col = firstColor(v);
                if (col != null) s.put("strokeColor", col);
                Float f = firstNum(v);
                if (f != null) s.put("strokeWidthDp", f);
            } else if ("border-color".equals(k)) {
                String col = firstColor(v);
                if (col != null) s.put("strokeColor", col);
            } else if ("border-width".equals(k)) {
                Float f = firstNum(v);
                if (f != null) s.put("strokeWidthDp", f);
            } else if ("font-size".equals(k)) {
                Float f = firstNum(v);
                if (f != null) {
                    if (isTitle) s.put("titleSizeSp", f);
                    else if (isBody) s.put("bodySizeSp", f);
                    else {
                        s.put("titleSizeSp", f);
                        s.put("bodySizeSp", f);
                    }
                }
            } else if ("width".equals(k) && v.contains("%")) {
                try {
                    float pct = Float.parseFloat(v.replace("%", "").trim());
                    s.put("widthRatio", Math.max(0.4f, Math.min(1f, pct / 100f)));
                } catch (Throwable ignored) {
                }
            } else if ("background-image".equals(k) || "background".equals(k)) {
                // 已有 background 处理；这里兜底线性渐变等忽略
            }
        }
    }

    /** 从值里提取第一个颜色（#hex / rgb() 简化）。 */
    private static String firstColor(String v) {
        Matcher hex = Pattern.compile("#[0-9a-fA-F]{3,8}").matcher(v);
        if (hex.find()) {
            String t = hex.group();
            if (t.length() == 4) {
                StringBuilder sb = new StringBuilder("#");
                for (int i = 1; i < 4; i++) {
                    char c = t.charAt(i);
                    sb.append(c).append(c);
                }
                return sb.toString();
            }
            return t;
        }
        Matcher rgb = Pattern.compile("rgb[a]?\\(([^)]+)\\)").matcher(v);
        if (rgb.find()) {
            String[] p = rgb.group(1).split(",");
            if (p.length >= 3) {
                int r = (int) Math.max(0, Math.min(255, parseF(p[0])));
                int g = (int) Math.max(0, Math.min(255, parseF(p[1])));
                int b = (int) Math.max(0, Math.min(255, parseF(p[2])));
                int a = 255;
                if (p.length >= 4 && p[3].trim().endsWith("%")) {
                    a = (int) (255 * Math.max(0, Math.min(1, parseF(p[3].replace("%", "")) / 100f)));
                } else if (p.length >= 4) {
                    a = (int) (255 * Math.max(0, Math.min(1, parseF(p[3]))));
                }
                return String.format(Locale.ROOT, "#%02X%02X%02X%02X", a, r, g, b);
            }
        }
        return null;
    }

    /** 从值里提取第一个数值（去 px/dp/rem 等后缀）。 */
    private static Float firstNum(String v) {
        Matcher m = Pattern.compile("-?\\d+(\\.\\d+)?").matcher(v);
        if (m.find()) {
            try {
                return Float.parseFloat(m.group());
            } catch (Throwable t) {
                return null;
            }
        }
        return null;
    }

    private static float parseF(String s) {
        try {
            return Float.parseFloat(s.trim());
        } catch (Throwable t) {
            return 0f;
        }
    }

    /** 由当前皮肤字段生成可编辑 CSS 文本（首次打开 CSS 编辑器时的默认内容）。 */
    public static String toCss(JSONObject s) {
        StringBuilder sb = new StringBuilder();
        sb.append("/* 弹窗整体 */\n");
        sb.append(".dialog {\n");
        sb.append("  background: ").append(Skin.str(s, "bgColor", "#1A0F14")).append(";\n");
        sb.append("  border-radius: ").append(Skin.i(s, "radiusDp", 28)).append("px;\n");
        sb.append("  padding: ").append(Skin.i(s, "padDp", 20)).append("px;\n");
        float stroke = Skin.f(s, "strokeWidthDp", 1.4f);
        if (stroke > 0f) {
            sb.append("  border: ").append(trim1(stroke)).append("px solid ")
                    .append(Skin.str(s, "strokeColor", "#66E0A85A")).append(";\n");
        }
        float wr = Skin.f(s, "widthRatio", 0.9f);
        sb.append("  width: ").append(Math.round(wr * 100)).append("%;\n");
        sb.append("}\n\n");
        sb.append("/* 标题（title） */\n");
        sb.append(".title {\n");
        sb.append("  color: ").append(Skin.str(s, "titleColor", "#F5EDE3")).append(";\n");
        sb.append("  font-size: ").append(trim1(Skin.f(s, "titleSizeSp", 17))).append("px;\n");
        sb.append("}\n\n");
        sb.append("/* 正文（body） */\n");
        sb.append(".body {\n");
        sb.append("  color: ").append(Skin.str(s, "bodyColor", "#A6978C")).append(";\n");
        sb.append("  font-size: ").append(trim1(Skin.f(s, "bodySizeSp", 12.5f))).append("px;\n");
        sb.append("}\n\n");
        sb.append("/* 主按钮（button） */\n");
        sb.append(".button {\n");
        sb.append("  background: ").append(Skin.str(s, "btnPrimaryColor", "#F5C044")).append(";\n");
        sb.append("  color: ").append(Skin.str(s, "btnPrimaryTextColor", "#3A2405")).append(";\n");
        sb.append("}\n");
        return sb.toString();
    }

    private static String trim1(float f) {
        if (f == Math.round(f)) return String.valueOf(Math.round(f));
        return String.valueOf(f);
    }
}
