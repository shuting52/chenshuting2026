# 淑婷控制台 · 源码包 v1.1.1（脱敏）

> 本包为公开版源码，**不含签名私钥、不含任何 GitHub 令牌**。

## 目录
- `app/`：Android 源码（java / res / AndroidManifest.xml）
- `build.sh`：手工构建链（aapt2 → javac → R8 → zipalign → apksigner）
- `proguard-rules.pro`：R8 规则

## 构建
```bash
export KS_PATH=/path/to/your-release.jks   # 自行准备的签名库
export KS_PASS=你的签名库口令
export KS_ALIAS=chenshuting
bash build.sh          # 产物：output/淑婷控制台-v1.1.1.apk
```

## 令牌约定（重要）
- `Prefs.java` 中保留 `__TOKEN__` 源码占位，构建期由 `$TEMP/.tok_use` 注入、构建结束自动还原；
- **公开分发包务必不要内置真实令牌**：令牌随 APK 进公开仓库会被 GitHub 密钥扫描自动吊销；
- 对外发布包请保持占位符（App 内「设置」页手动粘贴令牌即可），内置令牌版仅限本机安装。

## v1.1.1 更新
1. UI 内核换为「少女拟态」Soft-UI：奶油粉底 + 玫瑰主色，凸起/凹槽拟态控件、页面渐变背景、写实阴影
2. 弹窗编辑器新增「编辑 JSON 代码」（单场景 / 整套切换）、「上传 JSON 文件」、「复制当前配置」、「从剪贴板导入」
3. 令牌体检：本地形状预检（空格/换行、ghp_ 位数、前缀合法性）+ 联网核验 + 权限检查；状态栏显示 mask 与位数
4. 401/403/404/409/422 错误中文翻译，401 明确提示"令牌无效或已被吊销（曾打进公开 APK 会被自动吊销）"
5. `app/` 版本号对齐 1.1.1（versionCode 3），`Repo.APP_VER` 同步 1.1.1

## v1.1.0 功能
1. 图标三态：内置图标 / 填网址自动识别站点图标 / 上传本地图片
2. 弹窗样式编辑器：通用 / 更新 / 置顶 / 我的 四场景，实时预览，发布即生效（`data/dialogs.json`）
3. 全功能页「怎么用」分步教程
4. 图标直链带时间戳破 CDN 缓存
