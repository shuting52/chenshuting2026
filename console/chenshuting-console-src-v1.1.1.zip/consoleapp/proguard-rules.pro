# ============================================================
# 淑婷控制台 · R8 规则（无 Gradle 手工构建链）
# ============================================================

-keep class com.chenshuting.console.MainActivity { *; }
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}
-keepclassmembers class **.R$* { public static <fields>; }
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

-dontwarn **
-dontnote **
