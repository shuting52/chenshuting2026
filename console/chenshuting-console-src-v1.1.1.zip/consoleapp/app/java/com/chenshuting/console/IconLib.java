package com.chenshuting.console;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 图标中心：内置图标库 + 跟随网址自动识别(favicon/apple-touch-icon) + 上传自定义图片。 */
public final class IconLib {

    /** 内置图标：名称 → emoji（与本体 CategoryIcons 兜底表一致，可选后直接写 iconName/iconEmoji）。 */
    public static final String[][] BUILTIN = {
            {"Flame", "🔥"}, {"Sparkles", "✨"}, {"Palette", "🎨"}, {"Terminal", "⌨️"},
            {"Wrench", "🔧"}, {"Tv", "📺"}, {"BadgePercent", "🏷️"}, {"FolderArchive", "🗂️"},
            {"Headphones", "🎧"}, {"BookOpen", "📖"}, {"Gamepad2", "🎮"}, {"Laptop", "💻"},
            {"Compass", "🧭"}, {"Package", "📦"}, {"Music", "🎵"}, {"Film", "🎬"},
            {"ShoppingCart", "🛒"}, {"Globe", "🌐"}, {"Robot", "🤖"}, {"Coin", "💰"},
            {"Video", "🎬"}, {"Novel", "📕"}, {"Tool", "🧰"}, {"Setup", "🛠️"},
            {"Explore", "🧭"}, {"Apps", "📱"}, {"Handshake", "🤝"}, {"Brush", "🖌️"}};

    private IconLib() {
    }

    public static String[] names() {
        String[] a = new String[BUILTIN.length];
        for (int i = 0; i < BUILTIN.length; i++) a[i] = BUILTIN[i][0];
        return a;
    }

    public static String emojiOf(String name) {
        for (String[] o : BUILTIN) if (o[0].equalsIgnoreCase(name)) return o[1];
        return "";
    }

    /** 生成本地文件名（英文小写 + 连字符）。 */
    public static String slug(String s) {
        if (s == null) return "icon";
        StringBuilder sb = new StringBuilder();
        String t = s.trim().toLowerCase();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) sb.append(c);
            else if (c == '.' || c == '-' || c == '_' || c == '/') sb.append('-');
        }
        String r = sb.toString().replaceAll("-+", "-");
        while (r.startsWith("-")) r = r.substring(1);
        while (r.endsWith("-")) r = r.substring(0, r.length() - 1);
        if (r.length() > 40) r = r.substring(0, 40);
        return r.length() == 0 ? "icon" : r;
    }

    /** 图片扩展名判断。 */
    public static String extOf(String url, String fallback) {
        String u = url == null ? "" : url.toLowerCase();
        if (u.contains(".png")) return "png";
        if (u.contains(".jpg") || u.contains(".jpeg")) return "jpg";
        if (u.contains(".webp")) return "webp";
        if (u.contains(".gif")) return "gif";
        if (u.contains(".svg")) return "svg";
        if (u.contains(".ico")) return "ico";
        return fallback;
    }

    /** 下载任意 URL 字节（带浏览器 UA，跟随重定向）。 */
    public static byte[] download(String url) throws Exception {
        return download(url, 8 * 1024 * 1024);
    }

    public static byte[] download(String url, int maxBytes) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            conn.setRequestProperty("Accept", "*/*");
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            InputStream in = conn.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    bo.write(buf, 0, n);
                    if (bo.size() > maxBytes) throw new Exception("文件过大（>" + (maxBytes / 1048576) + "MB）");
                }
            } finally {
                in.close();
            }
            return bo.toByteArray();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static final Pattern LINK = Pattern.compile(
            "<link[^>]+>", Pattern.CASE_INSENSITIVE);
    private static final Pattern HREF = Pattern.compile(
            "href\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern REL = Pattern.compile(
            "rel\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);

    /**
     * 跟随网址自动识别图标：解析 HTML 的 link[rel=icon / apple-touch-icon]，
     * 依次回退 /favicon.ico 与常用图标路径。返回去重后的候选直链列表（可能为空）。
     */
    public static List<String> discover(String pageUrl) throws Exception {
        String url = pageUrl == null ? "" : pageUrl.trim();
        if (url.length() == 0) throw new Exception("网址为空");
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        URL u = new URL(url);
        String origin = u.getProtocol() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
        List<String> out = new ArrayList<String>();

        String html = "";
        try {
            byte[] b = download(url, 2 * 1024 * 1024);
            html = new String(b, "UTF-8");
        } catch (Throwable ignored) {
            // 页面打不开时仍尝试 favicon 兜底
        }
        Matcher m = LINK.matcher(html);
        while (m.find()) {
            String tag = m.group();
            Matcher r = REL.matcher(tag);
            if (!r.find()) continue;
            String rel = r.group(1).toLowerCase();
            if (rel.contains("icon")) {
                Matcher h = HREF.matcher(tag);
                if (h.find()) add(out, abs(origin, h.group(1)));
            }
        }
        add(out, origin + "/favicon.ico");
        add(out, origin + "/apple-touch-icon.png");
        add(out, origin + "/favicon.png");
        return out;
    }

    private static void add(List<String> list, String s) {
        if (s == null || s.length() == 0) return;
        if (!list.contains(s)) list.add(s);
    }

    private static String abs(String origin, String href) {
        String h = href.trim();
        if (h.startsWith("//")) return "https:" + h;
        if (h.startsWith("http://") || h.startsWith("https://")) return h;
        if (h.startsWith("/")) return origin + h;
        return origin + "/" + h;
    }
}
