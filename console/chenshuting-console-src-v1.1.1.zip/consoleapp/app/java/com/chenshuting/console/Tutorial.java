package com.chenshuting.console;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 教程卡：每个功能页统一挂载「怎么用」的分步拆解，默认收起，点击展开/收起。 */
public final class Tutorial {

    private Tutorial() {
    }

    /** 在本页顶部插入教程卡。steps 支持 "步骤标题|说明" 两段式。 */
    public static void add(LinearLayout body, final Context c, String title, final String[] steps) {
        final LinearLayout card = Ui.card(c);
        LinearLayout headRow = Ui.row(c);

        TextView ic = Ui.chip(c, "📘", Theme.GOLD);
        headRow.addView(ic);

        TextView t = Ui.tv(c, title, 14f, Theme.GOLD_LIGHT, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tlp.leftMargin = Ui.dp(c, 8);
        headRow.addView(t, tlp);

        final TextView arrow = Ui.tv(c, "展开", 12f, Theme.SUB, false);
        headRow.addView(arrow);
        card.addView(headRow);

        final LinearLayout detail = Ui.col(c);
        detail.setVisibility(View.GONE);
        card.addView(detail);

        for (int i = 0; i < steps.length; i++) {
            String s = steps[i];
            String no = "①";
            if (i == 1) no = "②";
            else if (i == 2) no = "③";
            else if (i == 3) no = "④";
            else if (i == 4) no = "⑤";
            else if (i == 5) no = "⑥";
            else if (i == 6) no = "⑦";
            else if (i == 7) no = "⑧";
            else if (i == 8) no = "⑨";
            else if (i == 9) no = "⑩";

            LinearLayout row = Ui.row(c);
            row.setGravity(Gravity.TOP);
            TextView idx = Ui.tv(c, no, 12.5f, Theme.GOLD, true);
            row.addView(idx);
            TextView txt = Ui.tv(c, s, 12.5f, Theme.TEXT, false);
            txt.setLineSpacing(Ui.dp(c, 3), 1f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.leftMargin = Ui.dp(c, 6);
            row.addView(txt, lp);
            Ui.add(detail, row, i == 0 ? 10 : 8);
        }

        headRow.setClickable(true);
        headRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean open = detail.getVisibility() == View.VISIBLE;
                detail.setVisibility(open ? View.GONE : View.VISIBLE);
                arrow.setText(open ? "展开" : "收起");
            }
        });
        Ui.add(body, card, 0);
    }
}
