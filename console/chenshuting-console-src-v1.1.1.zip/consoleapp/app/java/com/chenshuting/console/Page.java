package com.chenshuting.console;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** 页面基类：懒构建 + 可重建。 */
public abstract class Page {

    protected final MainActivity act;
    protected final Context ctx;
    protected LinearLayout body;
    private ScrollView root;

    protected Page(MainActivity a) {
        this.act = a;
        this.ctx = a;
    }

    public View view() {
        if (root == null) {
            body = Ui.page(ctx);
            root = Ui.scroller(ctx, body);
            build();
        }
        return root;
    }

    /** 构建页面内容（可被 rebuild 重复调用）。 */
    protected abstract void build();

    /** 每次切到该页时调用。 */
    protected void onShow() {
    }

    /** 清空并重建页面内容。 */
    protected void rebuild() {
        if (body == null) return;
        body.removeAllViews();
        build();
    }

    protected void log(String s) {
        Prefs.log(ctx, s);
    }

    protected void info(String s) {
        Ui.toast(ctx, s);
    }
}
