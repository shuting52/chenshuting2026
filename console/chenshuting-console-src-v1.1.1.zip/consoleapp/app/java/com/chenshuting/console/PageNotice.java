package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 公告：欢迎语 + 滚动动态，走独立实时通道（约 1 分钟生效，无需发版）。 */
public class PageNotice extends Page {

    private Switch swEnabled;
    private EditText inWelcome;
    private LinearLayout itemsHost;
    private TextView status;
    private final List<EditText> itemInputs = new ArrayList<EditText>();

    public PageNotice(MainActivity a) {
        super(a);
    }

    @Override
    protected void build() {
        body.addView(Ui.title(ctx, "公告"));
        Tutorial.add(body, ctx, "公告页 · 怎么用", new String[]{
                "开关：顶部总开关关掉后，App 首页不再显示跑马灯（配置仍保留，随时可再开）。",
                "欢迎语：单独一行，显示在跑马灯最前面，适合放节日问候或版本提示。",
                "动态条：每条一行，支持多行新增/删除，顺序即滚动顺序；建议每条不超过 30 字，念起来更顺。",
                "发布：点发布即写仓库 data/announcements.json，这是独立通道，约 1 分钟生效，不影响内容清单。",
                "验证：发布后杀掉 App 重开首页，跑马灯应能看到新内容；若没变，检查是否误关了总开关。"});
        body.addView(Ui.sub(ctx, "App 首页跑马灯：欢迎语 + 若干条滚动动态。"));
        Ui.add(body, Ui.sub(ctx, "本通道独立于内容清单，发布后约 1 分钟生效。"), 2);

        LinearLayout c1 = Ui.card(ctx);
        c1.addView(Ui.section(ctx, "开关"));
        swEnabled = new Switch(ctx);
        swEnabled.setText("启用滚动动态");
        swEnabled.setTextColor(Theme.TEXT);
        swEnabled.setTextSize(13f);
        swEnabled.setChecked(true);
        c1.addView(swEnabled);
        Ui.add(body, c1, 12);

        LinearLayout c2 = Ui.card(ctx);
        c2.addView(Ui.section(ctx, "欢迎语"));
        inWelcome = Ui.input(ctx, "欢迎语", true, "");
        Ui.add(c2, inWelcome, 4);
        Ui.add(body, c2, 10);

        LinearLayout c3 = Ui.card(ctx);
        c3.addView(Ui.section(ctx, "滚动动态"));
        itemsHost = Ui.col(ctx);
        c3.addView(itemsHost);
        TextView add = Ui.btn(ctx, "添加一条", false);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> cur = currentItems();
                cur.add("");
                fillItems(cur);
            }
        });
        Ui.add(c3, add, 8);
        Ui.add(body, c3, 10);

        TextView pub = Ui.btn(ctx, "发布公告", true);
        pub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmPublish();
            }
        });
        Ui.add(body, pub, 12);

        status = Ui.tv(ctx, "正在读取线上公告…", 12f, Theme.SUB, false);
        Ui.add(body, status, 10);
        load();
    }

    private void load() {
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                return Repo.readText(ctx, Repo.P_NOTICE);
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "读取失败：" + err.getMessage());
                    return;
                }
                boolean enabled = true;
                String welcome = "";
                List<String> items = new ArrayList<String>();
                try {
                    if (result != null && result.trim().length() > 0) {
                        JSONObject o = new JSONObject(result);
                        enabled = o.optBoolean("enabled", true);
                        welcome = o.optString("welcome", "");
                        JSONArray arr = o.optJSONArray("items");
                        if (arr != null) {
                            for (int i = 0; i < arr.length(); i++) items.add(arr.optString(i, ""));
                        }
                    }
                } catch (Throwable ignored) {
                }
                if (result == null) {
                    act.setText(status, "线上暂无公告文件，发布后将自动创建");
                } else {
                    act.setText(status, "已载入线上公告 · " + Repo.today());
                }
                swEnabled.setChecked(enabled);
                inWelcome.setText(welcome);
                fillItems(items);
            }
        });
    }

    private void fillItems(List<String> items) {
        itemsHost.removeAllViews();
        itemInputs.clear();
        for (int i = 0; i < items.size(); i++) {
            final EditText e = Ui.input(ctx, "第 " + (i + 1) + " 条动态", false, items.get(i));
            itemInputs.add(e);
            LinearLayout r = Ui.row(ctx);
            r.addView(e, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView del = Ui.btn(ctx, "删除", false);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dp.leftMargin = Ui.dp(ctx, 8);
            del.setLayoutParams(dp);
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    List<String> cur = currentItems();
                    int idx = itemInputs.indexOf(e);
                    if (idx >= 0 && idx < cur.size()) cur.remove(idx);
                    fillItems(cur);
                }
            });
            r.addView(del);
            Ui.add(itemsHost, r, 6);
        }
        if (items.isEmpty()) {
            itemsHost.addView(Ui.sub(ctx, "暂无动态条目，点「添加一条」新增"));
        }
    }

    private List<String> currentItems() {
        List<String> out = new ArrayList<String>();
        for (EditText e : itemInputs) out.add(e.getText().toString().trim());
        return out;
    }

    private void confirmPublish() {
        final boolean enabled = swEnabled.isChecked();
        final String welcome = inWelcome.getText().toString().trim();
        final List<String> items = new ArrayList<String>();
        for (String s : currentItems()) {
            if (s.length() > 0) items.add(s);
        }
        if (welcome.length() == 0 && items.isEmpty()) {
            info("欢迎语与动态不能同时为空");
            return;
        }
        String preview = "启用：" + (enabled ? "是" : "否")
                + "\n动态条数：" + items.size()
                + "\n欢迎语：" + (welcome.length() > 40 ? welcome.substring(0, 40) + "…" : welcome);
        new AlertDialog.Builder(act)
                .setTitle("确认发布公告")
                .setMessage(preview + "\n\n发布后约 1 分钟内在 App 首页跑马灯生效。")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认发布", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        doPublish(enabled, welcome, items);
                    }
                })
                .show();
    }

    private void doPublish(final boolean enabled, final String welcome, final List<String> items) {
        act.setText(status, "正在发布公告…");
        Ui.run(act, new Ui.Job() {
            @Override
            public String run() throws Exception {
                JSONObject o = new JSONObject();
                o.put("enabled", enabled);
                o.put("welcome", welcome);
                JSONArray arr = new JSONArray();
                for (String s : items) arr.put(s);
                o.put("items", arr);
                Repo.publishNotice(ctx, o);
                return "公告已发布（" + items.size() + " 条动态）";
            }
        }, new Ui.Done() {
            @Override
            public void done(String result, Throwable err) {
                if (err != null) {
                    act.setText(status, "发布失败：" + err.getMessage());
                    log("公告发布失败：" + err.getMessage());
                    return;
                }
                act.setText(status, result + " · " + Repo.today());
                log("公告已发布（" + items.size() + " 条动态）");
                act.badge("公告已更新", Theme.OK);
            }
        });
    }
}
