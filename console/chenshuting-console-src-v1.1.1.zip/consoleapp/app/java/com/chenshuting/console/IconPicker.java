package com.chenshuting.console;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** 图标选择器：三选一 —— 内置图标库 / 跟随网址自动识别 / 上传自定义图片。
 *  内置返回图标名（如 Flame），后两者会把图片传到仓库 data/icons/ 并返回可直链图片地址。 */
public final class IconPicker {

    /** 选择结果：iconName（内置图标名）或图片直链 URL，同时给出展示用 emoji 预览。 */
    public interface OnPick {
        void pick(String value, String note);
    }

    private IconPicker() {
    }

    public static void show(final MainActivity act, final String current, final OnPick cb) {
        final Context c = act;
        final LinearLayout box = Ui.col(c);
        box.setPadding(Ui.dp(c, 16), Ui.dp(c, 16), Ui.dp(c, 16), Ui.dp(c, 16));
        box.addView(Ui.section(c, "选择图标"));
        box.addView(Ui.sub(c, "当前：" + (current == null || current.length() == 0 ? "（未设置）" : current)));

        // 1. 内置图标库
        LinearLayout c1 = Ui.card(c);
        c1.addView(Ui.section(c, "① 内置图标"));
        c1.addView(Ui.sub(c, "点一下直接套用，无需上传，离线也能显示"));
        LinearLayout grid = Ui.col(c);
        LinearLayout row = null;
        for (int i = 0; i < IconLib.BUILTIN.length; i++) {
            if (i % 4 == 0) {
                row = Ui.row(c);
                Ui.add(grid, row, 6);
            }
            final String name = IconLib.BUILTIN[i][0];
            TextView chip = Ui.tv(c, IconLib.BUILTIN[i][1] + " " + name, 11.5f, Theme.TEXT, false);
            chip.setGravity(Gravity.CENTER);
            chip.setBackground(Ui.bg(c, Theme.CARD2, 14, 1, Theme.STROKE));
            chip.setPadding(Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8));
            chip.setClickable(true);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cb.pick(name, "内置图标 · " + IconLib.emojiOf(name));
                    dismiss();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.rightMargin = Ui.dp(c, 6);
            row.addView(chip, lp);
        }
        Ui.add(c1, grid, 4);
        Ui.add(box, c1, 12);

        // 2. 跟随网址自动识别
        LinearLayout c2 = Ui.card(c);
        c2.addView(Ui.section(c, "② 跟随网址自动识别"));
        c2.addView(Ui.sub(c, "填官网/任意网页地址，自动抓取站点图标（favicon / apple-touch-icon）并上传仓库"));
        final EditText inUrl = Ui.input(c, "如 https://www.example.com", false, "");
        Ui.add(c2, inUrl, 6);
        TextView go = Ui.btn(c, "识别并采用", true);
        Ui.add(c2, go, 8);
        final TextView st = Ui.sub(c, "首次识别约 5~15 秒，取决于站点响应");
        Ui.add(c2, st, 6);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String u = inUrl.getText().toString().trim();
                if (u.length() == 0) {
                    st.setText("请先填写网址");
                    return;
                }
                st.setText("正在识别…");
                Ui.run(act, new Ui.Job() {
                    @Override
                    public String run() throws Exception {
                        List<String> cands = IconLib.discover(u);
                        if (cands.isEmpty()) throw new Exception("该站点未找到可用图标");
                        String last = "";
                        for (String cand : cands) {
                            try {
                                byte[] data = IconLib.download(cand, 3 * 1024 * 1024);
                                if (data == null || data.length < 32) continue;
                                String ext = IconLib.extOf(cand, "png");
                                String name = IconLib.slug(hostOf(u)) + "-icon";
                                String path = "data/icons/" + name + "." + ext;
                                Repo.writeBytes(act, path, data, "console: 图标自动识别 " + hostOf(u));
                                // 同名图片重复上传时 jsdelivr 会命中旧缓存，这里加时间戳破缓存
                                return bust(Repo.jsdelivr(act, path)) + "|" + ext + "|" + data.length;
                            } catch (Throwable t) {
                                last = t.getMessage();
                            }
                        }
                        throw new Exception("图标下载失败：" + last);
                    }
                }, new Ui.Done() {
                    @Override
                    public void done(String result, Throwable err) {
                        if (err != null) {
                            st.setText("识别失败：" + err.getMessage());
                            return;
                        }
                        String[] parts = String.valueOf(result).split("\\|");
                        String url = parts[0];
                        String ext = parts.length > 1 ? parts[1] : "png";
                        String note = "已上传：" + url;
                        if ("ico".equals(ext)) note += "\n注意：.ico 在部分安卓机可能不显示，建议改用上传 PNG";
                        st.setText(note);
                        cb.pick(url, "网址图标（" + ext + "）");
                        dismiss();
                    }
                });
            }
        });
        Ui.add(box, c2, 12);

        // 3. 上传自定义图片
        LinearLayout c3 = Ui.card(c);
        c3.addView(Ui.section(c, "③ 上传自定义图片"));
        c3.addView(Ui.sub(c, "从手机相册/文件里选一张图（建议 512×512 以内 PNG），自动上传到仓库并回填直链"));
        TextView up = Ui.btn(c, "选择本地图片上传", false);
        Ui.add(c3, up, 8);
        final TextView st2 = Ui.sub(c, "上传完成后，App 端会用这张图替换 emoji 图标");
        Ui.add(c3, st2, 6);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                act.pickFile("image/*", "icon", new MainActivity.PickCb() {
                    @Override
                    public void onPicked(final String name, final byte[] data) {
                        st2.setText("正在上传…");
                        Ui.run(act, new Ui.Job() {
                            @Override
                            public String run() throws Exception {
                                String ext = IconLib.extOf(name, "png");
                                String path = "data/icons/" + IconLib.slug(name) + "." + ext;
                                Repo.writeBytes(act, path, data, "console: 上传自定义图标");
                                return bust(Repo.jsdelivr(act, path));
                            }
                        }, new Ui.Done() {
                            @Override
                            public void done(String result, Throwable err) {
                                if (err != null) {
                                    st2.setText("上传失败：" + err.getMessage());
                                    return;
                                }
                                st2.setText("已上传：" + result);
                                cb.pick(result, "自定义上传图片");
                                dismiss();
                            }
                        });
                    }

                    @Override
                    public void onFailed(String reason) {
                        st2.setText("未选择文件：" + reason);
                    }
                });
            }
        });
        Ui.add(box, c3, 12);

        ScrollView sv = new ScrollView(c);
        sv.setBackgroundColor(Theme.BG);
        sv.addView(box, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        dialog = new AlertDialog.Builder(act)
                .setView(sv)
                .setNegativeButton("取消", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        d.dismiss();
                    }
                })
                .create();
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#12080B")));
        }
    }

    private static AlertDialog dialog;

    private static void dismiss() {
        if (dialog != null) {
            try {
                dialog.dismiss();
            } catch (Throwable ignored) {
            }
            dialog = null;
        }
    }

    /** 给直链追加时间戳，避免同名图片被 CDN 旧缓存覆盖。 */
    private static String bust(String url) {
        if (url == null || url.length() == 0) return url;
        return url + (url.indexOf('?') < 0 ? "?v=" : "&v=") + (System.currentTimeMillis() / 1000L);
    }

    private static String hostOf(String url) {
        try {
            String u = url.trim();
            if (!u.startsWith("http")) u = "https://" + u;
            return new java.net.URL(u).getHost();
        } catch (Throwable t) {
            return "site";
        }
    }

    /** 判断一个值是否图片直链（本体按此决定用图片还是 emoji 渲染）。 */
    public static boolean isImage(String v) {
        return v != null && (v.startsWith("http://") || v.startsWith("https://"));
    }

    /** 图标值对应的预览色块。 */
    public static GradientDrawable previewBg(Context c, String value) {
        return Ui.bg(c, Theme.CARD2, 12, 1, Theme.STROKE);
    }
}
