package com.chenshuting.console;

import android.graphics.Color;

/** 少女拟态（Soft-UI / Neumorphism）主题配色：奶油粉底 + 白高光 + 粉紫阴影 + 玫瑰主色。
 *  视觉要点：背景与卡片同色系，靠一亮一暗的双向阴影塑造「软塑凸起」质感。 */
public final class Theme {

    /** 底色（页面渐变上下端）。 */
    public static final int BG_TOP = Color.parseColor("#FDF3F9");
    public static final int BG_BOTTOM = Color.parseColor("#F4E9FB");
    public static final int BG = Color.parseColor("#FBF0F7");
    /** 顶栏（比底色略粉一点）。 */
    public static final int BAR = Color.parseColor("#FBE4F1");

    /** 卡片 / 次级底。 */
    public static final int CARD = Color.parseColor("#FDF7FB");
    public static final int CARD2 = Color.parseColor("#F6E7F1");
    /** 柔和描边（拟态里描边只做极淡的轮廓提示）。 */
    public static final int STROKE = Color.parseColor("#EFD8E7");

    /** 主色：玫瑰粉 → 蜜桃粉。 */
    public static final int GOLD = Color.parseColor("#E86BA8");
    public static final int GOLD_LIGHT = Color.parseColor("#F79BC6");

    public static final int TEXT = Color.parseColor("#5A3B4E");
    public static final int SUB = Color.parseColor("#9A8093");
    public static final int OK = Color.parseColor("#4FB98A");
    public static final int WARN = Color.parseColor("#E2A03C");
    public static final int ERR = Color.parseColor("#DE5C72");
    public static final int BTN_TXT = Color.parseColor("#FFFFFF");

    /** 拟态阴影：暗侧（粉灰）/ 亮侧（近白）。 */
    public static final int SHADOW_DARK = Color.parseColor("#D9AFC6");
    public static final int SHADOW_LIGHT = Color.parseColor("#FFFFFF");

    private Theme() {
    }
}
