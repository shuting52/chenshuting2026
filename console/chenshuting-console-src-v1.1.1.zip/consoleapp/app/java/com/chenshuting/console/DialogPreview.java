package com.chenshuting.console;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** 弹窗样式预览器：完全按场景配置渲染一枚真实弹窗（与本体 CuteDialog 视觉口径一致），
 *  用于「改完立刻看效果」。 */
public final class DialogPreview {

    private DialogPreview() {
    }

    public static void show(MainActivity act, JSONObject s, String emoji, String title, String body) {
        final Dialog d = new Dialog(act);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout holder = new FrameLayout(act);
        holder.setClipChildren(false);

        LinearLayout card = Ui.col(act);
        card.setBackground(Skin.cardBg(act, s));
        card.setElevation(Ui.dp(act, 14));
        int padH = Skin.i(s, "padDp", 20);
        card.setPadding(Ui.dp(act, padH), Ui.dp(act, padH), Ui.dp(act, padH), Ui.dp(act, padH));

        // emoji 徽标
        TextView ic = Ui.tv(act, emoji, 22f, 0xFFFFFFFF, true);
        ic.setGravity(Gravity.CENTER);
        GradientDrawable badge = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Skin.color(Skin.str(s, "btnPrimaryColor", "#F5C044"), 0xFFF5C044),
                        Skin.color(Skin.str(s, "strokeColor", "#66E0A85A"), 0x66E0A85A) | 0xFF000000});
        badge.setShape(GradientDrawable.OVAL);
        ic.setBackground(badge);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(Ui.dp(act, 54), Ui.dp(act, 54));
        ilp.gravity = Gravity.CENTER_HORIZONTAL;
        card.addView(ic, ilp);

        // 标题
        TextView t = Ui.tv(act, title, Skin.f(s, "titleSizeSp", 17f), 
                Skin.color(Skin.str(s, "titleColor", "#F5EDE3"), 0xFFF5EDE3), true);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(act, 12);
        card.addView(t, tlp);

        // 正文
        TextView b = Ui.tv(act, body, Skin.f(s, "bodySizeSp", 12.5f),
                Skin.color(Skin.str(s, "bodyColor", "#A6978C"), 0xFFA6978C), false);
        b.setGravity(Gravity.CENTER);
        b.setLineSpacing(Ui.dp(act, 3), 1f);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = Ui.dp(act, 12);
        card.addView(b, blp);

        // 分隔线 + 主按钮
        View line = new View(act);
        line.setBackgroundColor(0x4DFFFFFF);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.height = Math.max(1, Ui.dp(act, 0.8f));
        llp.topMargin = Ui.dp(act, 16);
        card.addView(line, llp);

        TextView ok = Ui.tv(act, Skin.str(s, "okText", "我知道了"), 13.5f,
                Skin.color(Skin.str(s, "btnPrimaryTextColor", "#3A2405"), 0xFF3A2405), true);
        ok.setGravity(Gravity.CENTER);
        GradientDrawable okBg = new GradientDrawable();
        okBg.setCornerRadius(Ui.dp(act, 24));
        okBg.setColor(Skin.color(Skin.str(s, "btnPrimaryColor", "#F5C044"), 0xFFF5C044));
        ok.setBackground(okBg);
        ok.setPadding(Ui.dp(act, 18), Ui.dp(act, 12), Ui.dp(act, 18), Ui.dp(act, 12));
        ok.setClickable(true);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        LinearLayout row = Ui.row(act);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.addView(ok, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Ui.dp(act, 12);
        card.addView(row, rlp);

        int inset = Ui.dp(act, 16);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.setMargins(inset, inset, inset, inset);
        holder.addView(card, clp);

        d.setContentView(holder);
        d.setCancelable(true);
        d.setCanceledOnTouchOutside(true);
        Window w = d.getWindow();
        boolean bottom = "bottom".equals(Skin.str(s, "position", "center"));
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0x00000000));
            float ratio = Skin.f(s, "widthRatio", 0.90f);
            int width = (int) (act.getResources().getDisplayMetrics().widthPixels * ratio);
            w.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(bottom ? Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL : Gravity.CENTER);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.dimAmount = Skin.f(s, "dimAmount", 0.5f);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        d.show();

        String anim = Skin.str(s, "enterAnim", "overshoot");
        holder.setAlpha(0f);
        if ("fade".equals(anim)) {
            holder.animate().alpha(1f).setDuration(220).start();
        } else if ("slideUp".equals(anim)) {
            holder.setTranslationY(Ui.dp(act, 60));
            holder.animate().alpha(1f).translationY(0f).setDuration(280).start();
        } else {
            holder.setScaleX(0.84f);
            holder.setScaleY(0.84f);
            holder.setTranslationY(Ui.dp(act, 28));
            holder.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                    .setDuration(340).setInterpolator(new OvershootInterpolator(1.1f)).start();
        }
    }

    /** 便捷预览：用于页面内的样式实时预览入口。 */
    public static void sample(MainActivity act, JSONObject s, int sceneIndex) {
        show(act, s, "✨", Skin.SCENE_SAMPLE_TITLE[sceneIndex], Skin.SCENE_SAMPLE_BODY[sceneIndex]);
    }

    /** 空实现的空引用保护。 */
    public static Context ctxOf(MainActivity act) {
        return act;
    }
}
